// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s321998fa37fe89be: `© Direction de l'instruction publique et de la culture`,
  s3ba73c36f5c5710f: `Bienvenue chez Evento`,
  s66fb201578f6f6c2: `Tutoriels vidéo`,
  s67749057edb2586b: `Logout`,
  s6d8b7baee47fca15: `Menu`,
  s784d82bd15c49b4a: `Paramètres`,
  s79382e84e0818a6e: `Profil`,
  sc874744fb4632e62: `Mentions légales`,
  sd11a46c2e7022f58: `Impressum`,
  sc265a7e29e120db0: `Evento`,
  sc42d48a091dc3230: `Evento Startseite`,
  s1a8b197f436e88ab: `Menü Benutzereinstellungen`,
};
