// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s321998fa37fe89be: `© Direction de l'instruction publique et de la culture`,
  s3ba73c36f5c5710f: `Bienvenue chez Evento`,
  sc874744fb4632e62: `Mentions légales`,
  sd11a46c2e7022f58: `Impressum`,
  sc265a7e29e120db0: `Evento`,
  s6d8b7baee47fca15: `Menü`,
};
