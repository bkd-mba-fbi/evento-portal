// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s005058d82b713689: `Notes`,
  s23fc13291a6e1563: `Remplacement`,
  s2ccb1c31fa62fea1: `Absences`,
  s30329742fbb01b71: `Contrôle des présences`,
  s321998fa37fe89be: `© Direction de l’instruction publique et de la culture`,
  s364e8548a3193773: `Horaire`,
  s41d88871e0b18f8b: `Cours et manifestations`,
  s4c575b80febcc990: `Gérer les remplacements`,
  s66fb201578f6f6c2: `Tutoriels vidéo`,
  s67749057edb2586b: `Logout`,
  s6ab9bf010cfc8931: `Enseignement`,
  s6d8b7baee47fca15: `Menu`,
  s7459bbd6ff0ec70a: `Prestations`,
  s784d82bd15c49b4a: `Paramètres`,
  s79382e84e0818a6e: `Profil`,
  s805a26293333f4d7: `Évaluer les absences`,
  s928e9e6a6a843b1a: `Formation (continue)`,
  s9b0191032da1cf5e: `Traiter les absences`,
  sa37b83f4c60e63d3: `Excuser les absences en suspens`,
  saac6cc64d5c17b4f: `Administration`,
  sac1056b6664675ca: `Réserver des salles et des appareils`,
  sb5ffc0faf2cf16da: `Formation continue interne`,
  sc202079fc13ee45a: `Disciplines actuelles`,
  sc265a7e29e120db0: `Evento`,
  sc42d48a091dc3230: `Page d'accueil Evento`,
  sc42d48a091dc3230: `Page d'accueil Evento`,
  sc874744fb4632e62: `Mentions légales`,
  scfa1631260cdd84a: `Tests et évalution`,
  sd11a46c2e7022f58: `Impressum`,
  sec148f76974d9b06: `Rechercher des personnes et des institutions`,
  s1a8b197f436e88ab: `Menü Benutzereinstellungen`,
};
