
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's005058d82b713689': `Notes`,
's05ec46839b2c45c3': `Supprimer la notification`,
's0755fb794c2b9b3d': `Cette application contient des liens hypertextes menant à des offres proposées par des tiers. Vous utilisez ces liens à vos propres risques. Nous ne répondons pas du contenu publié sur ces autres sites Internet. Sont notamment exclus de notre responsabilité la garantie que notre application soit disponible en permanence ainsi que les dommages liés à son utilisation (p. ex. en raison d’une interruption de la connexion ou d’un logiciel malveillant).`,
's0ae8b0f434f47faa': `Les contenus de cette application informatique sont mis à disposition par l’établissement concerné. Bien qu’ils soient régulièrement vérifiés et mis à jour, nous déclinons toute responsabilité, pour autant que la loi le permette, en cas de conséquence indésirable liée à leur utilisation.`,
's1381f1fa0b3ddb62': `En utilisant cette application, vous acceptez le traitement des données citées, dans la mesure de ce qui est nécessaire. Voici des informations détaillées relatives au traitement des données :`,
's17b1ac4c36efd642': `Contact`,
's1a8b197f436e88ab': `Menu paramètres`,
's269516fd03223694': `https://www.be.ch/omp`,
's2a5cc7e40948ddad': `Procédure d'admission`,
's2ccb1c31fa62fea1': `Absences`,
's2e7964a3ed3ff4b2': `Saisir un remplacement`,
's2f3ed4ae7b042337': `Fournisseur de prestations`,
's2faf4f61874da789': `Rechercher des personnes et des institutions`,
's30329742fbb01b71': `Contrôle des présences`,
's30c3ae3fb64d10bd': `Si vous avez des questions sur la protection des données en lien avec la présente application, vous pouvez vous adresser au service responsable de l’application, dont les coordonnées figurent dans l’impressum.`,
's321998fa37fe89be': `© Direction de l'instruction publique et de la culture`,
's3490946cb9fc3368': `Réseaux sociaux`,
's41d88871e0b18f8b': `Cours et manifestations`,
's41ff2c74cc56bc8f': `En cas de message d’erreur dans Evento Web ou de questions au sujet de cette application, les élèves, les membres du corps enseignant et les collaboratrices et collaborateurs des écoles peuvent contacter le service compétent de leur établissement. L’école indique le service concerné. En cas de doute, veuillez contacter le secrétariat de l’école.`,
's44d2798b4a925e79': `Propriété intellectuelle`,
's4c575b80febcc990': `Gérer les remplacements`,
's53f771f096f6dee7': `Adresse IP, données techniques relatives au système d’exploitation et au navigateur web, URL référent, nom d’hôte et heure`,
's6083633db7f4cf90': `La présente application n’utilise pas de cookies.`,
's63e457bc703a3030': `Courriel`,
's64629ecd4900e6de': `Le fournisseur de prestations du canton de Berne qui assure l’exploitation de cette application traite l’adresse IP ou les données techniques des appareils des personnes qui l’utilisent. Le degré de protection des données prévu par la législation que ce fournisseur est tenu de respecter équivaut à celui prévu dans le droit bernois. Avant traitement, l’adresse IP est transmise de manière cryptée et anonymisée.`,
's66a8ea9d4609abf8': `Politique de confidentialité`,
's66fb201578f6f6c2': `Tutoriels vidéo`,
's676022c035fe65f5': `Effectuer un remplacement`,
's67749057edb2586b': `Se déconnecter`,
's6ab9bf010cfc8931': `Enseignement`,
's6d8b7baee47fca15': `Menu`,
's71d64f3daba42f69': `Exploitation et questions techniques`,
's7459bbd6ff0ec70a': `Prestations`,
's751e73928c2bd1b0': `Raison du traitement`,
's784d82bd15c49b4a': `Paramètres`,
's79382e84e0818a6e': `Mon profil`,
's805a26293333f4d7': `Évaluer les absences`,
's8218de939c80532c': `Responsabilité du contenu`,
's84044e9a5f99c170': `Données du journal du serveur web du canton de Berne afin d’identifier et de traiter des problèmes techniques et des attaques.`,
's885970c4ee8d21cc': `Fermer`,
's8bb0b618bf59b96e': `Détails de l'événement`,
's8e7e1013bc071156': `Saisie des notes`,
's918230658d993873': `Navigation mobile`,
's9b0191032da1cf5e': `Traiter les absences`,
'sa37b83f4c60e63d3': `Excuser les absences en suspens`,
'sa981ad28edcf81e5': `Il se peut que des éléments figurant dans l’application (images, icônes) soient la propriété de tiers. Leur utilisation est donc interdite. Sur demande, le canton de Berne peut cependant autoriser l’utilisation, en dehors du site web, des éléments dont il détient les droits. Veuillez adresser vos demandes à cet effet au service responsable de l’application, dont les coordonnées figurent dans l’impressum.`,
'saac6cc64d5c17b4f': `Administration`,
'sac1056b6664675ca': `Réserver des salles et des appareils`,
'safad117145e83ae0': `Importer des données`,
'sb5ffc0faf2cf16da': `Formation continue interne`,
'sb993cc3240e32971': `Aucune notification`,
'sbd4575edfbf5c84f': `Navigation principale`,
'sc202079fc13ee45a': `Disciplines actuelles`,
'sc217172426ab34d5': `Formation (continue)`,
'sc265a7e29e120db0': `Evento`,
'sc354c34c1a7cbcc4': `Cookies`,
'sc42d48a091dc3230': `Page d'accueil Evento`,
'sc874744fb4632e62': `Mentions légales`,
'sccb118772784d38c': `Bedag Informatique SA
Engehaldenstrasse 12
3012 Berne`,
'sccb8c6ab6c0cf3e6': `Terminer le remplacement`,
'scde3342a428aaee8': `Hors ligne`,
'scfa1631260cdd84a': `Tests et évalution`,
'scff9b2b73fc9a17f': `Notifications`,
'sd0195378eb1d12a7': `Erreur lors du chargement des notifications`,
'sd10fcf5b06af72f6': `Navigation service`,
'sd11a46c2e7022f58': `Impressum`,
'sd58f707de5fe6c23': `Exclusion de la responsabilité`,
'sd79be54b222abcae': `Aucune connexion disponible.`,
'sda7b78ee4d822af5': `Traitement des données`,
'sda82f4406693e77c': `Tout effacer`,
'se33353371b3ee38b': `Données traitées`,
'sea31a3191cc166f8': `École compétente, voir Contact`,
'seae9439e8d8e58e7': `La présente application renvoie uniquement vers des réseaux sociaux tels que YouTube au moyen de liens et non via l’exécution de programmes (plug-in). Ainsi, aucune donnée personnelle n’est transmise aux réseaux sociaux lorsque vous utilisez l’application.`,
'sef3cc5f0adf7abc3': `Application`,
'sf49fc5f227269877': `Le service responsable de l’application au sens de la législation sur la protection des données, et notamment du règlement général de l’UE sur la protection des données (RGPD), est :`,
'sf4fb738671432c9c': `Direction de l’instruction publique et de la culture du canton de Berne
Office des écoles moyennes et de la formation professionnelle
Unité Applications informatiques
Kasernenstrasse 27
3013 Berne`,
'sf6588ea1b5ceacff': `Office des écoles moyennes et de la formation professionnelle
Kasernenstrasse 27
3013 Berne`,
'sfb4410b48e95fa73': `Contact`,
    };
  