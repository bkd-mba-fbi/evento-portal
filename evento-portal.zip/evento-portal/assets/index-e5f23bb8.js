var gn=Object.defineProperty;var vn=(n,e,t)=>e in n?gn(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var O=(n,e,t)=>(vn(n,typeof e!="symbol"?e+"":e,t),t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))r(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function t(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(i){if(i.ep)return;i.ep=!0;const s=t(i);fetch(i.href,s)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ge=window,Je=ge.ShadowRoot&&(ge.ShadyCSS===void 0||ge.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Ze=Symbol(),ut=new WeakMap;let Rt=class{constructor(e,t,r){if(this._$cssResult$=!0,r!==Ze)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(Je&&e===void 0){const r=t!==void 0&&t.length===1;r&&(e=ut.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),r&&ut.set(t,e))}return e}toString(){return this.cssText}};const bn=n=>new Rt(typeof n=="string"?n:n+"",void 0,Ze),E=(n,...e)=>{const t=n.length===1?n[0]:e.reduce((r,i,s)=>r+(o=>{if(o._$cssResult$===!0)return o.cssText;if(typeof o=="number")return o;throw Error("Value passed to 'css' function must be a 'css' function result: "+o+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+n[s+1],n[0]);return new Rt(t,n,Ze)},mn=(n,e)=>{Je?n.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet):e.forEach(t=>{const r=document.createElement("style"),i=ge.litNonce;i!==void 0&&r.setAttribute("nonce",i),r.textContent=t.cssText,n.appendChild(r)})},pt=Je?n=>n:n=>n instanceof CSSStyleSheet?(e=>{let t="";for(const r of e.cssRules)t+=r.cssText;return bn(t)})(n):n;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Oe;const be=window,ft=be.trustedTypes,yn=ft?ft.emptyScript:"",gt=be.reactiveElementPolyfillSupport,Ue={toAttribute(n,e){switch(e){case Boolean:n=n?yn:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,e){let t=n;switch(e){case Boolean:t=n!==null;break;case Number:t=n===null?null:Number(n);break;case Object:case Array:try{t=JSON.parse(n)}catch{t=null}}return t}},Lt=(n,e)=>e!==n&&(e==e||n==n),Te={attribute:!0,type:String,converter:Ue,reflect:!1,hasChanged:Lt};let W=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(e){var t;this.finalize(),((t=this.h)!==null&&t!==void 0?t:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((t,r)=>{const i=this._$Ep(r,t);i!==void 0&&(this._$Ev.set(i,r),e.push(i))}),e}static createProperty(e,t=Te){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const r=typeof e=="symbol"?Symbol():"__"+e,i=this.getPropertyDescriptor(e,r,t);i!==void 0&&Object.defineProperty(this.prototype,e,i)}}static getPropertyDescriptor(e,t,r){return{get(){return this[t]},set(i){const s=this[e];this[t]=i,this.requestUpdate(e,s,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||Te}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),e.h!==void 0&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const t=this.properties,r=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const i of r)this.createProperty(i,t[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const r=new Set(e.flat(1/0).reverse());for(const i of r)t.unshift(pt(i))}else e!==void 0&&t.push(pt(e));return t}static _$Ep(e,t){const r=t.attribute;return r===!1?void 0:typeof r=="string"?r:typeof e=="string"?e.toLowerCase():void 0}u(){var e;this._$E_=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(e=this.constructor.h)===null||e===void 0||e.forEach(t=>t(this))}addController(e){var t,r;((t=this._$ES)!==null&&t!==void 0?t:this._$ES=[]).push(e),this.renderRoot!==void 0&&this.isConnected&&((r=e.hostConnected)===null||r===void 0||r.call(e))}removeController(e){var t;(t=this._$ES)===null||t===void 0||t.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((e,t)=>{this.hasOwnProperty(t)&&(this._$Ei.set(t,this[t]),delete this[t])})}createRenderRoot(){var e;const t=(e=this.shadowRoot)!==null&&e!==void 0?e:this.attachShadow(this.constructor.shadowRootOptions);return mn(t,this.constructor.elementStyles),t}connectedCallback(){var e;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$ES)===null||e===void 0||e.forEach(t=>{var r;return(r=t.hostConnected)===null||r===void 0?void 0:r.call(t)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$ES)===null||e===void 0||e.forEach(t=>{var r;return(r=t.hostDisconnected)===null||r===void 0?void 0:r.call(t)})}attributeChangedCallback(e,t,r){this._$AK(e,r)}_$EO(e,t,r=Te){var i;const s=this.constructor._$Ep(e,r);if(s!==void 0&&r.reflect===!0){const o=(((i=r.converter)===null||i===void 0?void 0:i.toAttribute)!==void 0?r.converter:Ue).toAttribute(t,r.type);this._$El=e,o==null?this.removeAttribute(s):this.setAttribute(s,o),this._$El=null}}_$AK(e,t){var r;const i=this.constructor,s=i._$Ev.get(e);if(s!==void 0&&this._$El!==s){const o=i.getPropertyOptions(s),l=typeof o.converter=="function"?{fromAttribute:o.converter}:((r=o.converter)===null||r===void 0?void 0:r.fromAttribute)!==void 0?o.converter:Ue;this._$El=s,this[s]=l.fromAttribute(t,o.type),this._$El=null}}requestUpdate(e,t,r){let i=!0;e!==void 0&&(((r=r||this.constructor.getPropertyOptions(e)).hasChanged||Lt)(this[e],t)?(this._$AL.has(e)||this._$AL.set(e,t),r.reflect===!0&&this._$El!==e&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(e,r))):i=!1),!this.isUpdatePending&&i&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((i,s)=>this[s]=i),this._$Ei=void 0);let t=!1;const r=this._$AL;try{t=this.shouldUpdate(r),t?(this.willUpdate(r),(e=this._$ES)===null||e===void 0||e.forEach(i=>{var s;return(s=i.hostUpdate)===null||s===void 0?void 0:s.call(i)}),this.update(r)):this._$Ek()}catch(i){throw t=!1,this._$Ek(),i}t&&this._$AE(r)}willUpdate(e){}_$AE(e){var t;(t=this._$ES)===null||t===void 0||t.forEach(r=>{var i;return(i=r.hostUpdated)===null||i===void 0?void 0:i.call(r)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){this._$EC!==void 0&&(this._$EC.forEach((t,r)=>this._$EO(r,this[r],t)),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}};W.finalized=!0,W.elementProperties=new Map,W.elementStyles=[],W.shadowRootOptions={mode:"open"},gt==null||gt({ReactiveElement:W}),((Oe=be.reactiveElementVersions)!==null&&Oe!==void 0?Oe:be.reactiveElementVersions=[]).push("1.6.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Ie;const me=window,Q=me.trustedTypes,vt=Q?Q.createPolicy("lit-html",{createHTML:n=>n}):void 0,De="$lit$",j=`lit$${(Math.random()+"").slice(9)}$`,zt="?"+j,wn=`<${zt}>`,F=document,re=()=>F.createComment(""),ie=n=>n===null||typeof n!="object"&&typeof n!="function",Mt=Array.isArray,kn=n=>Mt(n)||typeof(n==null?void 0:n[Symbol.iterator])=="function",Re=`[ 	
\f\r]`,ee=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,bt=/-->/g,mt=/>/g,V=RegExp(`>|${Re}(?:([^\\s"'>=/]+)(${Re}*=${Re}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),yt=/'/g,wt=/"/g,jt=/^(?:script|style|textarea|title)$/i,_n=n=>(e,...t)=>({_$litType$:n,strings:e,values:t}),k=_n(1),U=Symbol.for("lit-noChange"),_=Symbol.for("lit-nothing"),kt=new WeakMap,q=F.createTreeWalker(F,129,null,!1),$n=(n,e)=>{const t=n.length-1,r=[];let i,s=e===2?"<svg>":"",o=ee;for(let a=0;a<t;a++){const c=n[a];let p,d,u=-1,v=0;for(;v<c.length&&(o.lastIndex=v,d=o.exec(c),d!==null);)v=o.lastIndex,o===ee?d[1]==="!--"?o=bt:d[1]!==void 0?o=mt:d[2]!==void 0?(jt.test(d[2])&&(i=RegExp("</"+d[2],"g")),o=V):d[3]!==void 0&&(o=V):o===V?d[0]===">"?(o=i??ee,u=-1):d[1]===void 0?u=-2:(u=o.lastIndex-d[2].length,p=d[1],o=d[3]===void 0?V:d[3]==='"'?wt:yt):o===wt||o===yt?o=V:o===bt||o===mt?o=ee:(o=V,i=void 0);const f=o===V&&n[a+1].startsWith("/>")?" ":"";s+=o===ee?c+wn:u>=0?(r.push(p),c.slice(0,u)+De+c.slice(u)+j+f):c+j+(u===-2?(r.push(void 0),a):f)}const l=s+(n[t]||"<?>")+(e===2?"</svg>":"");if(!Array.isArray(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return[vt!==void 0?vt.createHTML(l):l,r]};class se{constructor({strings:e,_$litType$:t},r){let i;this.parts=[];let s=0,o=0;const l=e.length-1,a=this.parts,[c,p]=$n(e,t);if(this.el=se.createElement(c,r),q.currentNode=this.el.content,t===2){const d=this.el.content,u=d.firstChild;u.remove(),d.append(...u.childNodes)}for(;(i=q.nextNode())!==null&&a.length<l;){if(i.nodeType===1){if(i.hasAttributes()){const d=[];for(const u of i.getAttributeNames())if(u.endsWith(De)||u.startsWith(j)){const v=p[o++];if(d.push(u),v!==void 0){const f=i.getAttribute(v.toLowerCase()+De).split(j),h=/([.?@])?(.*)/.exec(v);a.push({type:1,index:s,name:h[2],strings:f,ctor:h[1]==="."?En:h[1]==="?"?xn:h[1]==="@"?Pn:xe})}else a.push({type:6,index:s})}for(const u of d)i.removeAttribute(u)}if(jt.test(i.tagName)){const d=i.textContent.split(j),u=d.length-1;if(u>0){i.textContent=Q?Q.emptyScript:"";for(let v=0;v<u;v++)i.append(d[v],re()),q.nextNode(),a.push({type:2,index:++s});i.append(d[u],re())}}}else if(i.nodeType===8)if(i.data===zt)a.push({type:2,index:s});else{let d=-1;for(;(d=i.data.indexOf(j,d+1))!==-1;)a.push({type:7,index:s}),d+=j.length-1}s++}}static createElement(e,t){const r=F.createElement("template");return r.innerHTML=e,r}}function Y(n,e,t=n,r){var i,s,o,l;if(e===U)return e;let a=r!==void 0?(i=t._$Co)===null||i===void 0?void 0:i[r]:t._$Cl;const c=ie(e)?void 0:e._$litDirective$;return(a==null?void 0:a.constructor)!==c&&((s=a==null?void 0:a._$AO)===null||s===void 0||s.call(a,!1),c===void 0?a=void 0:(a=new c(n),a._$AT(n,t,r)),r!==void 0?((o=(l=t)._$Co)!==null&&o!==void 0?o:l._$Co=[])[r]=a:t._$Cl=a),a!==void 0&&(e=Y(n,a._$AS(n,e.values),a,r)),e}class An{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var t;const{el:{content:r},parts:i}=this._$AD,s=((t=e==null?void 0:e.creationScope)!==null&&t!==void 0?t:F).importNode(r,!0);q.currentNode=s;let o=q.nextNode(),l=0,a=0,c=i[0];for(;c!==void 0;){if(l===c.index){let p;c.type===2?p=new he(o,o.nextSibling,this,e):c.type===1?p=new c.ctor(o,c.name,c.strings,this,e):c.type===6&&(p=new Sn(o,this,e)),this._$AV.push(p),c=i[++a]}l!==(c==null?void 0:c.index)&&(o=q.nextNode(),l++)}return q.currentNode=F,s}v(e){let t=0;for(const r of this._$AV)r!==void 0&&(r.strings!==void 0?(r._$AI(e,r,t),t+=r.strings.length-2):r._$AI(e[t])),t++}}class he{constructor(e,t,r,i){var s;this.type=2,this._$AH=_,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=r,this.options=i,this._$Cp=(s=i==null?void 0:i.isConnected)===null||s===void 0||s}get _$AU(){var e,t;return(t=(e=this._$AM)===null||e===void 0?void 0:e._$AU)!==null&&t!==void 0?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Y(this,e,t),ie(e)?e===_||e==null||e===""?(this._$AH!==_&&this._$AR(),this._$AH=_):e!==this._$AH&&e!==U&&this._(e):e._$litType$!==void 0?this.g(e):e.nodeType!==void 0?this.$(e):kn(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==_&&ie(this._$AH)?this._$AA.nextSibling.data=e:this.$(F.createTextNode(e)),this._$AH=e}g(e){var t;const{values:r,_$litType$:i}=e,s=typeof i=="number"?this._$AC(e):(i.el===void 0&&(i.el=se.createElement(i.h,this.options)),i);if(((t=this._$AH)===null||t===void 0?void 0:t._$AD)===s)this._$AH.v(r);else{const o=new An(s,this),l=o.u(this.options);o.v(r),this.$(l),this._$AH=o}}_$AC(e){let t=kt.get(e.strings);return t===void 0&&kt.set(e.strings,t=new se(e)),t}T(e){Mt(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let r,i=0;for(const s of e)i===t.length?t.push(r=new he(this.k(re()),this.k(re()),this,this.options)):r=t[i],r._$AI(s),i++;i<t.length&&(this._$AR(r&&r._$AB.nextSibling,i),t.length=i)}_$AR(e=this._$AA.nextSibling,t){var r;for((r=this._$AP)===null||r===void 0||r.call(this,!1,!0,t);e&&e!==this._$AB;){const i=e.nextSibling;e.remove(),e=i}}setConnected(e){var t;this._$AM===void 0&&(this._$Cp=e,(t=this._$AP)===null||t===void 0||t.call(this,e))}}class xe{constructor(e,t,r,i,s){this.type=1,this._$AH=_,this._$AN=void 0,this.element=e,this.name=t,this._$AM=i,this.options=s,r.length>2||r[0]!==""||r[1]!==""?(this._$AH=Array(r.length-1).fill(new String),this.strings=r):this._$AH=_}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,t=this,r,i){const s=this.strings;let o=!1;if(s===void 0)e=Y(this,e,t,0),o=!ie(e)||e!==this._$AH&&e!==U,o&&(this._$AH=e);else{const l=e;let a,c;for(e=s[0],a=0;a<s.length-1;a++)c=Y(this,l[r+a],t,a),c===U&&(c=this._$AH[a]),o||(o=!ie(c)||c!==this._$AH[a]),c===_?e=_:e!==_&&(e+=(c??"")+s[a+1]),this._$AH[a]=c}o&&!i&&this.j(e)}j(e){e===_?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class En extends xe{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===_?void 0:e}}const Cn=Q?Q.emptyScript:"";class xn extends xe{constructor(){super(...arguments),this.type=4}j(e){e&&e!==_?this.element.setAttribute(this.name,Cn):this.element.removeAttribute(this.name)}}class Pn extends xe{constructor(e,t,r,i,s){super(e,t,r,i,s),this.type=5}_$AI(e,t=this){var r;if((e=(r=Y(this,e,t,0))!==null&&r!==void 0?r:_)===U)return;const i=this._$AH,s=e===_&&i!==_||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,o=e!==_&&(i===_||s);s&&this.element.removeEventListener(this.name,this,i),o&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t,r;typeof this._$AH=="function"?this._$AH.call((r=(t=this.options)===null||t===void 0?void 0:t.host)!==null&&r!==void 0?r:this.element,e):this._$AH.handleEvent(e)}}class Sn{constructor(e,t,r){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=r}get _$AU(){return this._$AM._$AU}_$AI(e){Y(this,e)}}const _t=me.litHtmlPolyfillSupport;_t==null||_t(se,he),((Ie=me.litHtmlVersions)!==null&&Ie!==void 0?Ie:me.litHtmlVersions=[]).push("2.7.4");const On=(n,e,t)=>{var r,i;const s=(r=t==null?void 0:t.renderBefore)!==null&&r!==void 0?r:e;let o=s._$litPart$;if(o===void 0){const l=(i=t==null?void 0:t.renderBefore)!==null&&i!==void 0?i:null;s._$litPart$=o=new he(e.insertBefore(re(),l),l,void 0,t??{})}return o._$AI(n),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Le,ze;class A extends W{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,t;const r=super.createRenderRoot();return(e=(t=this.renderOptions).renderBefore)!==null&&e!==void 0||(t.renderBefore=r.firstChild),r}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=On(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!1)}render(){return U}}A.finalized=!0,A._$litElement$=!0,(Le=globalThis.litElementHydrateSupport)===null||Le===void 0||Le.call(globalThis,{LitElement:A});const $t=globalThis.litElementPolyfillSupport;$t==null||$t({LitElement:A});((ze=globalThis.litElementVersions)!==null&&ze!==void 0?ze:globalThis.litElementVersions=[]).push("3.3.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const x=n=>e=>typeof e=="function"?((t,r)=>(customElements.define(t,r),r))(n,e):((t,r)=>{const{kind:i,elements:s}=r;return{kind:i,elements:s,finisher(o){customElements.define(t,o)}}})(n,e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Tn=(n,e)=>e.kind==="method"&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(t){t.createProperty(e.key,n)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){typeof e.initializer=="function"&&(this[e.key]=e.initializer.call(this))},finisher(t){t.createProperty(e.key,n)}};function D(n){return(e,t)=>t!==void 0?((r,i,s)=>{i.constructor.createProperty(s,r)})(n,e,t):Tn(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function In(n){return D({...n,state:!0})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const et=({finisher:n,descriptor:e})=>(t,r)=>{var i;if(r===void 0){const s=(i=t.originalKey)!==null&&i!==void 0?i:t.key,o=e!=null?{kind:"method",placement:"prototype",key:s,descriptor:e(t.key)}:{...t,key:s};return n!=null&&(o.finisher=function(l){n(l,s)}),o}{const s=t.constructor;e!==void 0&&Object.defineProperty(t,r,e(r)),n==null||n(s,r)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Rn(n){return et({descriptor:e=>({get(){var t,r;return(r=(t=this.renderRoot)===null||t===void 0?void 0:t.querySelectorAll(n))!==null&&r!==void 0?r:[]},enumerable:!0,configurable:!0})})}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Me;((Me=window.HTMLSlotElement)===null||Me===void 0?void 0:Me.prototype.assignedElements)!=null;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ln=n=>typeof n!="string"&&"strTag"in n,Nt=(n,e,t)=>{let r=n[0];for(let i=1;i<n.length;i++)r+=e[t?t[i-1]:i-1],r+=n[i];return r};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ut=n=>Ln(n)?Nt(n.strings,n.values):n;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const He="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class zn{constructor(e){this.__litLocalizeEventHandler=t=>{t.detail.status==="ready"&&this.host.requestUpdate()},this.host=e}hostConnected(){window.addEventListener(He,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(He,this.__litLocalizeEventHandler)}}const Mn=n=>n.addController(new zn(n)),Dt=Mn;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const jn=()=>n=>typeof n=="function"?Un(n):Nn(n),P=jn,Nn=({kind:n,elements:e})=>({kind:n,elements:e,finisher(t){t.addInitializer(Dt)}}),Un=n=>(n.addInitializer(Dt),n);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Ht{constructor(){this.settled=!1,this.promise=new Promise((e,t)=>{this._resolve=e,this._reject=t})}resolve(e){this.settled=!0,this._resolve(e)}reject(e){this.settled=!0,this._reject(e)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */const L=[];for(let n=0;n<256;n++)L[n]=(n>>4&15).toString(16)+(n&15).toString(16);function Dn(n){let e=0,t=8997,r=0,i=33826,s=0,o=40164,l=0,a=52210;for(let c=0;c<n.length;c++)t^=n.charCodeAt(c),e=t*435,r=i*435,s=o*435,l=a*435,s+=t<<8,l+=i<<8,r+=e>>>16,t=e&65535,s+=r>>>16,i=r&65535,a=l+(s>>>16)&65535,o=s&65535;return L[a>>8]+L[a&255]+L[o>>8]+L[o&255]+L[i>>8]+L[i&255]+L[t>>8]+L[t&255]}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Hn="",Kn="h",Vn="s";function Bn(n,e){return(e?Kn:Vn)+Dn(typeof n=="string"?n:n.join(Hn))}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const At=new WeakMap,Et=new Map;function qn(n,e,t){var r;if(n){const i=(r=t==null?void 0:t.id)!==null&&r!==void 0?r:Gn(e),s=n[i];if(s){if(typeof s=="string")return s;if("strTag"in s)return Nt(s.strings,e.values,s.values);{let o=At.get(s);return o===void 0&&(o=s.values,At.set(s,o)),{...s,values:o.map(l=>e.values[l])}}}}return Ut(e)}function Gn(n){const e=typeof n=="string"?n:n.strings;let t=Et.get(e);return t===void 0&&(t=Bn(e,typeof n!="string"&&!("strTag"in n)),Et.set(e,t)),t}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function je(n){window.dispatchEvent(new CustomEvent(He,{detail:n}))}let ye="",te,Kt,we,Ke,Vt,B=new Ht;B.resolve();let fe=0;const Fn=n=>(Qn((e,t)=>qn(Vt,e,t)),ye=Kt=n.sourceLocale,we=new Set(n.targetLocales),we.add(n.sourceLocale),Ke=n.loadLocale,{getLocale:Wn,setLocale:Xn}),Wn=()=>ye,Xn=n=>{if(n===(te??ye))return B.promise;if(!we||!Ke)throw new Error("Internal error");if(!we.has(n))throw new Error("Invalid locale code");fe++;const e=fe;return te=n,B.settled&&(B=new Ht),je({status:"loading",loadingLocale:n}),(n===Kt?Promise.resolve({templates:void 0}):Ke(n)).then(r=>{fe===e&&(ye=n,te=void 0,Vt=r.templates,je({status:"ready",readyLocale:n}),B.resolve())},r=>{fe===e&&(je({status:"error",errorLocale:n,errorMessage:r.toString()}),B.reject(r))}),B.promise};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let m=Ut,Ct=!1;function Qn(n){if(Ct)throw new Error("lit-localize can only be configured once");m=n,Ct=!0}const Bt=E`
  /* Brand Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm1) */
  --bkd-brand-white: rgba(255, 255, 255, 0.42);
  --bkd-brand-red: rgba(234, 22, 31, 1);
  --bkd-brand-black: rgba(0, 0, 0, 1);
  --bkd-brand-light-sand: rgba(252, 248, 243, 1);
  --bkd-brand-sand: rgba(250, 241, 227, 1);
  --bkd-brand-dark-sand: rgba(247, 233, 210, 1);
  --bkd-brand-sand-hover: rgba(242, 224, 195, 1);
  --bkd-brand-cappuchino: rgba(235, 211, 174, 1);

  /* Functional Foreground Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-fg-black: rgba(0, 0, 0, 1);
  --bkd-func-fg-grey: rgba(112, 112, 112, 1);
  --bkd-func-fg-light-grey: rgba(112, 112, 112, 0.68);
  --bkd-func-fg-white: rgba(255, 255, 255, 1);

  /* Functional Background Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-bg-anthrazit-hover: rgba(64, 64, 64, 1);
  --bkd-func-bg-anthrazit: rgba(78, 78, 78, 0.95);
  --bkd-func-bg-dark-grey: rgba(112, 112, 112, 1);
  --bkd-func-bg-line-grey: rgba(112, 112, 112, 0.5);
  --bkd-func-bg-grey: rgba(222, 222, 222, 1);
  --bkd-func-bg-light-grey: rgba(242, 242, 242, 1);
  --bkd-func-bg-very-light-grey: rgba(248, 248, 248, 1);
  --bkd-func-bg-white: rgba(255, 255, 255, 1);
  --bkd-func-bg-red: rgba(208, 16, 24, 1);
  --bkd-func-bg-green: rgba(61, 134, 8, 1);

  /* Component-specific Colors */
  --bkd-language-switcher-active-border: rgba(234, 22, 31, 0.77);
  --bkd-footer-border: rgba(238, 238, 238, 1);
  --bkd-mobile-nav-shadow: rgba(0, 0, 0, 0.16);

  /* Dropdowns */
  --bkd-z-index-dropdown: 1;

  /* Fonts */
  --bkd-font-family: "Roboto", sans-serif;
  --bkd-font-size-base: 16px;
  --bkd-font-weight-base: 300;
  --bkd-line-height-base: 1.625;

  /* Spacings */
  --bkd-margin-horizontal-large: 40px;
  --bkd-margin-horizontal-medium: 30px;
  --bkd-margin-horizontal-small: 20px;
`,Yn=E`
  /* See https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm3 */

  /* Thin */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 100;
    src: url("/fonts/roboto-v30-latin-ext_latin-100.woff") format("woff");
  }

  /* Light */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 300;
    src: url("/fonts/roboto-v30-latin-ext_latin-300.woff") format("woff");
  }

  /* Regular */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: url("/fonts/roboto-v30-latin-ext_latin-400.woff") format("woff");
  }

  /* Medium */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: url("/fonts/roboto-v30-latin-ext_latin-500.woff") format("woff");
  }

  /* Bold */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: url("/fonts/roboto-v30-latin-ext_latin-700.woff") format("woff");
  }
`,S=E`
  :host {
    ${Bt}
    ${Yn}
  }

  /* Reset */
  * {
    box-sizing: border-box;

    font-family: var(--bkd-font-family);
    font-size: var(--bkd-font-size-base);
    font-weight: var(--bkd-font-weight-base);
    line-height: var(--bkd-line-height-base);

    font-synthesis: none;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
  }
  img,
  svg {
    display: block;
  }
`;function Jn(n){var t;const e=document.createElement("style");e.innerText=n,(t=document.querySelector("body"))==null||t.appendChild(e)}function qt(n){return typeof n=="function"?n():n}const ht=class extends Event{constructor(t,r,i){super(ht.eventName,{cancelable:!1});O(this,"key");O(this,"state");O(this,"value");this.key=t,this.value=r,this.state=i}};let N=ht;O(N,"eventName","lit-state-changed");const Zn=(n,e)=>e!==n&&(e===e||n===n);class ve extends EventTarget{constructor(){super();O(this,"hookMap",new Map);this.constructor.finalize(),this.propertyMap&&[...this.propertyMap].forEach(([t,r])=>{if(r.initialValue!==void 0){const i=qt(r.initialValue);this[t]=i,r.value=i}})}get propertyMap(){return this.constructor.propertyMap}get stateValue(){return Object.fromEntries([...this.propertyMap].map(([t])=>[t,this[t]]))}static finalize(){if(this.finalized)return!1;this.finalized=!0;const t=Object.keys(this.properties||{});for(const r of t)this.createProperty(r,this.properties[r]);return!0}static createProperty(t,r){this.finalize();const i=typeof t=="symbol"?Symbol():`__${t}`,s=this.getPropertyDescriptor(t,i,r);Object.defineProperty(this.prototype,t,s)}static getPropertyDescriptor(t,r,i){const s=(i==null?void 0:i.hasChanged)||Zn;return{get(){return this[r]},set(o){const l=this[t];this[r]=o,s(o,l)===!0&&this.dispatchStateEvent(t,o,this)},configurable:!0,enumerable:!0}}reset(){this.hookMap.forEach(t=>t.reset()),[...this.propertyMap].filter(([t,r])=>!(r.skipReset===!0||r.resetValue===void 0)).forEach(([t,r])=>{this[t]=r.resetValue})}subscribe(t,r,i){r&&!Array.isArray(r)&&(r=[r]);const s=o=>{(!r||r.includes(o.key))&&t(o.key,o.value,this)};return this.addEventListener(N.eventName,s,i),()=>this.removeEventListener(N.eventName,s)}dispatchStateEvent(t,r,i){this.dispatchEvent(new N(t,r,i))}}O(ve,"propertyMap"),O(ve,"properties"),O(ve,"finalized",!1);class z{constructor(e,t,r){O(this,"host");O(this,"state");O(this,"callback");this.host=e,this.state=t,this.host.addController(this),this.callback=r||(()=>this.host.requestUpdate())}hostConnected(){this.state.addEventListener(N.eventName,this.callback),this.callback()}hostDisconnected(){this.state.removeEventListener(N.eventName,this.callback)}}function H(n){return et({finisher:(e,t)=>{if(Object.getOwnPropertyDescriptor(e.prototype,t))throw new Error("@property must be called before all state decorators");return e.propertyMap||(e.propertyMap=new Map),e.propertyMap.set(t,{...n,initialValue:n==null?void 0:n.value,resetValue:n==null?void 0:n.value}),e.createProperty(t,n)}})}function er(n,e){if(n!==null&&(e===Boolean||e===Number||e===Array||e===Object))try{n=JSON.parse(n)}catch{console.warn("cannot parse value",n)}return n}const tr=new URL(window.location.href);function Gt(n){return et({finisher:(e,t)=>{if(!Object.getOwnPropertyDescriptor(e.prototype,t))throw new Error("@local-storage decorator need to be called after @property");const i=`${(n==null?void 0:n.parameter)||String(t)}`,s=e.propertyMap.get(t),o=s==null?void 0:s.type;if(s){const l=s.initialValue,a=tr.searchParams.get(i);a!==null&&(s.skipAsync=!0),s.initialValue=()=>er(a,o)??qt(l),e.propertyMap.set(t,{...s,...n})}}})}const nr="modulepreload",rr=function(n){return"/"+n},xt={},ir=function(e,t,r){if(!t||t.length===0)return e();const i=document.getElementsByTagName("link");return Promise.all(t.map(s=>{if(s=rr(s),s in xt)return;xt[s]=!0;const o=s.endsWith(".css"),l=o?'[rel="stylesheet"]':"";if(!!r)for(let p=i.length-1;p>=0;p--){const d=i[p];if(d.href===s&&(!o||d.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${s}"]${l}`))return;const c=document.createElement("link");if(c.rel=o?"stylesheet":nr,o||(c.as="script",c.crossOrigin=""),c.href=s,document.head.appendChild(c),o)return new Promise((p,d)=>{c.addEventListener("load",p),c.addEventListener("error",()=>d(new Error(`Unable to preload CSS for ${s}`)))})})).then(()=>e())},sr="de",or=["fr"],ar=["de","fr"],{getLocale:Ft,setLocale:lr}=Fn({sourceLocale:sr,targetLocales:or,loadLocale:n=>ir(()=>import(`/locales/${n}.js`),[])});async function cr(n){await lr(n),document.documentElement.lang=n}const $={api:{server:"https://eventoapp-test.erz.be.ch/restApi"},oauth:{server:"https://eventoapp-test.erz.be.ch",clientId:"dev3000"},apps:[{key:"schulverwaltung",scope:"Tutoring",root:"Apps/webapp-schulverwaltung/index.html"},{key:"anmeldedetailsEinlesen",scope:"NG",root:"Apps/EmberApps/AnmeldedetailsEinlesen/index.html"},{key:"schulleiterPersonen",scope:"NG",root:"Apps/EmberApps/SchulleiterPersonen/index.html"},{key:"kursausschreibung",scope:"Public",root:"Apps/Kursausschreibung/index.html"},{key:"stellvertretung",scope:"Tutoring",root:"Apps/Stellvertretung/index.html"},{key:"reservation",scope:"NG",root:"Apps/Raumreservation/index.html"}],navigationHome:{key:"home",label:"Home",allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/portal-home"},get navigationMyProfile(){return{key:"myProfile",label:m("Mein Profil"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-profile"}},get navigationMySettings(){return{key:"mySettings",label:m("Einstellungen"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-settings"}},get navigation(){return[{label:m("Unterricht"),items:[{key:"presenceControl",label:m("Präsenzkontrolle"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/presence-control"},{key:"currentEvents",label:m("Aktuelle Fächer"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/current-events"},{key:"tests",label:m("Tests und Bewertung"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/tests"},{key:"substitutionsAssign",label:m("Stellvertretung"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"stellvertretung",appPath:"#/substitutions/assign"}]},{label:m("Absenzen"),items:[{key:"openAbsences",label:m("Offene Absenzen entschuldigen"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/open-absences"},{key:"editAbsences",label:m("Absenzen bearbeiten"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/edit-absences"},{key:"evaluateAbsences",label:m("Absenzen auswerten"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/evaluate-absences"}]},{label:m("Angebote"),items:[{key:"coursesAndEvents",label:m("Kurse und Veranstaltungen"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"kursausschreibung",appPath:"#/"},{key:"internalTraining",label:m("Schulinterne Weiterbildung"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole","SubstituteAdministratorRole"],deniedInstanceIds:null,appKey:"kursausschreibung",appPath:"#/"},{key:"reservations",label:m("Räume und Geräte reservieren"),allowedRolesOrPermissions:["Reservations"],deniedInstanceIds:null,appKey:"reservation",appPath:"#/"}]},{label:m("Aus-/Weiterbildungen"),items:[{key:"myAbsences",label:m("Absenzen"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-absences"},{key:"myGrades",label:m("Noten"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/"},{key:"schedule",label:m("Stundenplan"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/"}]},{label:m("Administration"),items:[{key:"substitutionsAdmin",label:m("Stellvertretungen administrieren"),allowedRolesOrPermissions:["SubstituteAdministratorRole"],deniedInstanceIds:null,appKey:"stellvertretung",appPath:"#/substitutions/admin"},{key:"personSearch",label:"Personen und Institutionen suchen",allowedRolesOrPermissions:["PersonRight"],deniedInstanceIds:null,appKey:"schulleiterPersonen",appPath:"#/persons"},{key:"eventRegistration",label:m("Anmeldedetails einlesen"),allowedRolesOrPermissions:["PersonRight","RegistrationRightWeiterbildungModulanlass","RegistrationRightWeiterbildungKurs"],deniedInstanceIds:null,appKey:"anmeldedetailsEinlesen",appPath:"#/input/"}]}]}};function tt(n,e){switch(e){case $.navigationMyProfile.key:return{item:$.navigationMyProfile,group:null};case $.navigationMySettings.key:return{item:$.navigationMySettings,group:null};default:{for(const t of n){const r=t.items.find(({key:i})=>i===e);if(r)return{item:r,group:t}}return{item:$.navigationHome,group:null}}}}function Pe(n){const e=$.apps.find(t=>t.key===n.appKey);if(!e)throw new Error(`Invalid app: ${n.appKey}`);return e}function dr(n,e){const{item:t}=tt(n,e);return Pe(t).scope}function hr(n,e,t){return n.reduce((r,i)=>{const s=i.items.filter(o=>ur(o,e)&&pr(o,t));return s.length>0?[...r,{...i,items:s}]:r},[])}function ur(n,e){return n.deniedInstanceIds===null||n.deniedInstanceIds.includes(e)}function pr(n,e){return n.allowedRolesOrPermissions===null||n.allowedRolesOrPermissions.some(t=>e.includes(t))}function fr(n){const e=new URL(location.href);Array.from(e.searchParams.keys()).forEach(r=>{n.includes(r)||e.searchParams.delete(r)}),history.replaceState({},"",e)}function Pt(n,e,t=!1){const r=new URL(location.href);r.searchParams.set(n,e),t?history.replaceState({},"",r):history.pushState({},"",r)}function gr(){const e=new URL(location.href).searchParams.get(J);return e?dr($.navigation,e):Pe($.navigationHome).scope}function oe(n){const e=typeof n=="string"?tt(b.navigation,n).item:n;return vr(e).toString()}function vr(n){const e=new URL(location.origin);return e.searchParams.set(ae,b.locale),e.searchParams.set(J,n.key),e.hash=n.appPath,e}const Wt="bkdInstance",Ve="bkdCodeVerifier",ke="bkdRedirectUrl",nt="bkdAccessToken",rt="bkdRefreshToken",it="CLX.LoginToken";function Xt(){return localStorage.getItem(Wt)}function br(n){localStorage.setItem(Wt,n)}function mr(n){return localStorage.getItem(`${nt}_${n}`)}function st(){return localStorage.getItem(rt)}function yr(n,e){const{refreshToken:t,accessToken:r}=e;localStorage.setItem(`${nt}_${n}`,r),t&&localStorage.setItem(rt,t)}function wr(){new Array(localStorage.length).fill(void 0).forEach((n,e)=>{const t=localStorage.key(e);t&&(t.startsWith(nt)||t===rt)&&localStorage.removeItem(t)}),sessionStorage.removeItem(it)}function G(){return sessionStorage.getItem(it)}function Qt(n){sessionStorage.setItem(it,n)}function kr(){const n=sessionStorage.getItem(Ve),e=sessionStorage.getItem(ke)??void 0;return sessionStorage.removeItem(ke),sessionStorage.removeItem(Ve),n?{redirectUri:e,codeVerifier:n}:null}function _r(n,e){sessionStorage.setItem(Ve,n),e?sessionStorage.setItem(ke,e):sessionStorage.removeItem(ke)}function ue(n){const{instance_id:e,scope:t,nbf:r,exp:i}=$r(n);return{instanceId:e,scope:t,issueTime:r,expirationTime:i}}function Yt(n){if(!n)return!0;const{expirationTime:e}=ue(n),t=Math.floor(Date.now()/1e3);return e<t}function St(n){if(!n)return!0;const{issueTime:e,expirationTime:t}=typeof n=="string"?ue(n):n,r=t-e,i=Math.floor(Date.now()/1e3);return t<=i+r/2}function $r(n){const t=n.split(".")[1].replace("-","+").replace("_","/"),r=decodeURIComponent(window.atob(t).split("").map(function(i){return"%"+("00"+i.charCodeAt(0).toString(16)).slice(-2)}).join(""));return JSON.parse(r)}async function Ar(){var t,r;const n=`${$.api.server}/UserSettings/?expand=AccessInfo`,e=await Jt(n);return{roles:((t=e==null?void 0:e.AccessInfo)==null?void 0:t.Roles)??[],permissions:((r=e==null?void 0:e.AccessInfo)==null?void 0:r.Permissions)??[]}}async function Er(){const n=`${$.api.server}/Configurations/SchoolAppNavigation`,e=await Jt(n);return(e==null?void 0:e.instanceName)||null}async function Jt(n,{method:e="GET"}={}){const t=G();if(!t)throw new Error("No token available");const r=new Headers({"CLX-Authorization":`token_type=urn:ietf:params:oauth:token-type:jwt-bearer, access_token=${t}`,"Content-Type":"application/json"});return await(await fetch(n,{method:e,headers:r})).json()}var Cr=Object.defineProperty,xr=Object.getOwnPropertyDescriptor,K=(n,e,t,r)=>{for(var i=r>1?void 0:r?xr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Cr(e,t,i),i};const ae="locale",J="module",Pr=[ae,J];class M extends ve{constructor(){super(...arguments),this.setInitialized=()=>{},this.initialized=new Promise(e=>this.setInitialized=()=>e(null))}async init(){this.handleStateChange("locale",this.locale),this.subscribe(this.handleStateChange.bind(this)),await this.loadRolesAndPermissions(),this.setInitialized()}subscribeLocale(e){return e(this.locale),this.subscribe((t,r)=>e(r),"locale")}subscribeInstanceName(e){return this.subscribe((t,r)=>e(r),"instanceName")}subscribeNavigationItemKey(e){return e(this.navigationItemKey),this.subscribe((t,r)=>e(r),"navigationItemKey")}subscribeNavigationItem(e){return e(this.navigationItem),this.subscribe((t,r)=>e(r),"navigationItem")}subscribeScope(e,t=!1){return t||e(this.app.scope),this.subscribe((r,i)=>e(i.scope),"app")}navigate(e){this.initialized.then(()=>{fr(Pr),this.locale=e.searchParams.get(ae)||Ft(),this.navigationItemKey=e.searchParams.get(J)??$.navigationHome.key})}handleStateChange(e,t){e==="locale"&&(this.updateLocale(t),this.loadInstanceName()),(e==="rolesAndPermissions"||e==="locale")&&this.updateNavigation(),(e==="navigationItemKey"||e==="navigation")&&(this.updateNavigationItemAndGroup(this.navigationItemKey),this.updateApp(this.navigationItem))}async updateLocale(e){await cr(e),Pt(ae,e)}updateNavigation(){const e=G();if(!e)return;const{instanceId:t}=ue(e);this.navigation=hr($.navigation,t,this.rolesAndPermissions)}updateNavigationItemAndGroup(e){if(this.navigation.length>0){const{item:t,group:r}=tt(this.navigation,e);this.navigationItem=t,this.navigationGroup=r,t.key===$.navigationHome.key&&t.key!==e&&(this.navigationItemKey=t.key)}Pt(J,this.navigationItemKey)}updateApp(e){this.app=Pe(e)}async loadRolesAndPermissions(){if(!G())return;const{roles:t,permissions:r}=await Ar();this.rolesAndPermissions=[...t,...r]}async loadInstanceName(){if(!G())return;const t=await Er();this.instanceName=[m("Evento"),t].filter(Boolean).join(" | ")}}K([Gt({parameter:ae}),H({value:Ft()})],M.prototype,"locale",2);K([H({value:[]})],M.prototype,"rolesAndPermissions",2);K([H({value:""})],M.prototype,"instanceName",2);K([H({value:[]})],M.prototype,"navigation",2);K([Gt({parameter:J}),H({value:null})],M.prototype,"navigationItemKey",2);K([H({value:null})],M.prototype,"navigationGroup",2);K([H({value:$.navigationHome})],M.prototype,"navigationItem",2);K([H({value:Pe($.navigationHome)})],M.prototype,"app",2);const b=new M;var Sr=Object.defineProperty,Or=Object.getOwnPropertyDescriptor,Tr=(n,e,t,r)=>{for(var i=r>1?void 0:r?Or(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Sr(e,t,i),i};let Be=class extends A{constructor(){super(),new z(this,b)}render(){return k`
      <main>
        <h1>${b.navigationItem.label}</h1>
      </main>
    `}};Be.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        margin: 0 var(--bkd-header-margin-horizontal);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];Be=Tr([x("bkd-content"),P()],Be);var Ir=Object.defineProperty,Rr=Object.getOwnPropertyDescriptor,Lr=(n,e,t,r)=>{for(var i=r>1?void 0:r?Rr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Ir(e,t,i),i};let qe=class extends A{constructor(){super(),new z(this,b)}render(){return k`
      <footer>
        <div class="copyright">${m("© Bildungs- und Kulturdirektion")}</div>
        <div class="footer-nav">
          <a
            href=${`https://www.bkd.be.ch/${b.locale}/tools/rechtliches.html`}
            target="_blank"
            >${m("Rechtliche Hinweise")}</a
          >
          <a
            href=${`https://www.bkd.be.ch/${b.locale}/tools/impressum.html`}
            target="_blank"
            >${m("Impressum")}</a
          >
        </div>
      </footer>
    `}};qe.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-large);
        --bkd-footer-padding-vertical: 18px;

        padding: var(--bkd-footer-padding-vertical)
          var(--bkd-footer-padding-horizontal);
        border-top: 1px solid var(--bkd-footer-border);
        background-color: var(--bkd-brand-light-sand);
        color: var(--bkd-func-fg-black);
      }

      footer {
        display: flex;
        justify-content: space-between;
      }

      .copyright {
        font-size: 0.8125rem;
        font-weight: 300;
        letter-spacing: 0.02rem;
        word-spacing: 0.05rem;
      }

      .footer-nav {
        display: flex;
        gap: 2.5rem;
      }

      a {
        font-size: 0.875rem;
        font-weight: 400;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        line-height: 1.5;
        color: var(--bkd-func-fg-black);
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-medium);
        }

        footer {
          flex-direction: column-reverse;
          gap: 2.25rem;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];qe=Lr([x("bkd-footer"),P()],qe);class ot{constructor(e,t,r){this.host=e,this.toggleButtonId=t,this.menuId=r,this.open=!1,this.handleClick=i=>{this.targetMatchesId(i,[this.toggleButtonId,this.menuId])||this.close()},this.handleKeydown=i=>{i.key==="Escape"&&this.close()},this.handleCloseOthers=i=>{const{source:s}=i.detail;s!==this&&this.close()},this.host.addController(this)}hostDisconnected(){this.removeListeners()}toggle(){this.open=!this.open,this.host.requestUpdate(),this.open?(this.closeOthers(),this.addListeners()):this.removeListeners()}close(){this.open&&this.toggle()}addListeners(){document.addEventListener("click",this.handleClick,!0),document.addEventListener("keydown",this.handleKeydown,!0),document.addEventListener("bkddropdowntoggleclose",this.handleCloseOthers)}removeListeners(){document.removeEventListener("click",this.handleClick,!0),document.removeEventListener("keydown",this.handleKeydown,!0),document.removeEventListener("bkddropdowntoggleclose",this.handleCloseOthers)}closeOthers(){document.dispatchEvent(new CustomEvent("bkddropdowntoggleclose",{detail:{source:this}}))}targetMatchesId(e,t){return e.composedPath().some(r=>t.includes(r.id))}}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Zt(n,e,t){return n?e():t==null?void 0:t()}var zr=Object.defineProperty,Mr=Object.getOwnPropertyDescriptor,jr=(n,e,t,r)=>{for(var i=r>1?void 0:r?Mr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&zr(e,t,i),i};let Ge=class extends A{constructor(){super(),this.mobileNav=new ot(this,"mobile-nav-toggle","mobile-nav-menu"),new z(this,b)}handleLogoClick(n){n.preventDefault(),b.navigationItemKey="home"}handleNavItemClick(n){const{item:e}=n.detail;b.navigationItemKey=e.key,this.mobileNav.close()}handleSettingsItemClick(n){const{item:e,event:t}=n.detail;e.external||(t.preventDefault(),e.key==="logout"?this.dispatchEvent(new CustomEvent("bkdlogout",{composed:!0,bubbles:!0})):b.navigationItemKey=e.key),this.mobileNav.close()}render(){return k`
      <header>
        <bkd-service-nav
          .mobileNavOpen=${this.mobileNav.open}
          @bkdhamburgertoggle=${()=>this.mobileNav.toggle()}
          @bkdsettingsitemclick=${this.handleSettingsItemClick.bind(this)}
        ></bkd-service-nav>
        <a class="logo" href=${oe("home")}
          ><img
            src="logo.svg"
            alt=${m("Evento Startseite")}
            @click=${this.handleLogoClick.bind(this)}
        /></a>
        <div class="logo-caption">${b.instanceName}</div>
        <bkd-nav
          @bkdnavitemclick=${this.handleNavItemClick.bind(this)}
        ></bkd-nav>
        ${Zt(this.mobileNav.open,()=>k`<bkd-mobile-nav
              id="mobile-nav-menu"
              @bkdnavitemclick=${this.handleNavItemClick.bind(this)}
              @bkdsettingsitemclick=${this.handleSettingsItemClick.bind(this)}
            ></bkd-mobile-nav>`)}
      </header>
    `}};Ge.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-header-margin-top: 12px;
        --bkd-header-margin-bottom: calc(2 * var(--bkd-header-margin-top));
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        position: relative;
        padding: var(--bkd-header-margin-top)
          var(--bkd-header-margin-horizontal) var(--bkd-header-margin-bottom)
          var(--bkd-header-margin-horizontal);
        border-bottom: 1px solid var(--bkd-func-bg-grey);
      }

      header {
        display: grid;
        grid-template-columns: max-content auto;
        grid-template-areas:
          "service-nav service-nav"
          "logo ."
          "logo-caption nav";
      }

      bkd-service-nav {
        grid-area: service-nav;
        justify-self: end;
      }

      .logo {
        grid-area: logo;
      }

      .logo > img {
        width: 150px;
      }

      .logo-caption {
        grid-area: logo-caption;
        align-self: baseline;
        max-width: 21rem;
      }

      bkd-nav {
        grid-area: nav;
        align-self: baseline;
        justify-self: end;
      }

      /* Hide mobile nav on large screens */
      @media screen and (min-width: 1201px) {
        bkd-mobile-nav {
          display: none;
        }
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }

        header {
          grid-template-areas:
            "logo service-nav"
            "logo-caption logo-caption";
        }

        bkd-service-nav {
          align-self: center;
        }

        .logo > img {
          width: 110px;
        }

        .logo-caption {
          margin-top: 12px;
          font-size: 0.75rem;
          line-height: 0.75rem;
          max-width: 13.125rem;
        }

        bkd-nav {
          display: none;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }

        bkd-service-nav {
          align-self: start;
          margin-top: 2px; /* Align with logo text */
        }
      }
    `];Ge=jr([x("bkd-header"),P()],Ge);var Nr=Object.defineProperty,Ur=Object.getOwnPropertyDescriptor,en=(n,e,t,r)=>{for(var i=r>1?void 0:r?Ur(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Nr(e,t,i),i};let _e=class extends A{constructor(){super(...arguments),this.open=!1}toggle(){this.dispatchEvent(new CustomEvent("bkdhamburgertoggle",{bubbles:!0,composed:!0}))}render(){const n=this.open?"/icons/close.svg":"/icons/hamburger.svg";return k`
      <button
        class="hamburger"
        aria-expanded=${this.open}
        aria-label=${m("Menü")}
        @click=${this.toggle.bind(this)}
      >
        <img src=${n} alt="" width="32" height="32" />
      </button>
    `}};_e.styles=[S,E`
      :host {
        display: flex;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }
    `];en([D()],_e.prototype,"open",2);_e=en([x("bkd-hamburger"),P()],_e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const tn={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},nn=n=>(...e)=>({_$litDirective$:n,values:e});class rn{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,r){this._$Ct=e,this._$AM=t,this._$Ci=r}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const le=nn(class extends rn{constructor(n){var e;if(super(n),n.type!==tn.ATTRIBUTE||n.name!=="class"||((e=n.strings)===null||e===void 0?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(n){return" "+Object.keys(n).filter(e=>n[e]).join(" ")+" "}update(n,[e]){var t,r;if(this.it===void 0){this.it=new Set,n.strings!==void 0&&(this.nt=new Set(n.strings.join(" ").split(/\s/).filter(s=>s!=="")));for(const s in e)e[s]&&!(!((t=this.nt)===null||t===void 0)&&t.has(s))&&this.it.add(s);return this.render(e)}const i=n.element.classList;this.it.forEach(s=>{s in e||(i.remove(s),this.it.delete(s))});for(const s in e){const o=!!e[s];o===this.it.has(s)||!((r=this.nt)===null||r===void 0)&&r.has(s)||(o?(i.add(s),this.it.add(s)):(i.remove(s),this.it.delete(s)))}return U}});var Dr=Object.defineProperty,Hr=Object.getOwnPropertyDescriptor,Kr=(n,e,t,r)=>{for(var i=r>1?void 0:r?Hr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Dr(e,t,i),i};let Fe=class extends A{constructor(){super(),new z(this,b)}handleLocaleChange(n,e){n.preventDefault(),b.locale=e}render(){return k`<ul>
      ${ar.map(n=>k`<li>
            <a
              href="#"
              class=${le({active:n===b.locale})}
              aria-current=${n===b.locale}
              @click=${e=>this.handleLocaleChange(e,n)}
            >
              ${n}
            </a>
          </li>`)}
    </ul>`}};Fe.styles=[S,E`
      :host {
        font-size: 0.875rem;
      }

      ul {
        display: flex;
        align-items: baseline;
        margin: 0;
        padding: 0;
        list-style: none;
      }

      li {
        display: flex;
        align-items: baseline;
        margin-left: 0.75rem;
      }

      li + li:before {
        content: "|";
        margin-right: 0.75rem;
      }

      a {
        display: block;
        letter-spacing: 0.025rem;
        text-decoration: none;
        text-transform: uppercase;
        color: var(--bkd-func-fg-black);
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a.active {
        border-bottom: 2px solid var(--bkd-language-switcher-active-border);
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      a.active:hover::after,
      a.active:focus::after,
      a.active:active::after {
        transform: scaleX(0);
      }
    `];Fe=Kr([x("bkd-language-switcher"),P()],Fe);/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function*X(n,e){if(n!==void 0){let t=0;for(const r of n)yield e(r,t++)}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class We extends rn{constructor(e){if(super(e),this.et=_,e.type!==tn.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===_||e==null)return this.ft=void 0,this.et=e;if(e===U)return e;if(typeof e!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.et)return this.ft;this.et=e;const t=[e];return t.raw=t,this.ft={_$litType$:this.constructor.resultType,strings:t,values:[]}}}We.directiveName="unsafeHTML",We.resultType=1;const Vr=nn(We),Br=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"><path fill="currentColor" d="m22 15.975-1.775 1.775L12 9.525 3.775 17.75 2 15.975l10-10 10 10Z"/></svg>
`,qr=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"><path fill="currentColor" d="M2 8.025 3.775 6.25 12 14.475l8.225-8.225L22 8.025l-10 10-10-10Z"/></svg>
`;function sn(n){return[{key:"myProfile",label:m("Mein Profil"),href:oe("myProfile")},{key:"mySettings",label:m("Einstellungen"),href:oe("mySettings")},{key:"videos",label:m("Video-Tutorials"),href:n==="de"?"https://www.youtube.com/playlist?list=PLLDtLiOuctbx-_EQWgWqTO1MRbX845OEf":"https://www.youtube.com/playlist?list=PLLDtLiOuctbyEegnquAkaW4u8cm62lFAU",img:"/icons/external-link.svg",external:!0},{key:"logout",label:m("Logout"),href:"#",img:"/icons/logout.svg"}]}var Gr=Object.defineProperty,Fr=Object.getOwnPropertyDescriptor,on=(n,e,t,r)=>{for(var i=r>1?void 0:r?Fr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Gr(e,t,i),i};let $e=class extends A{constructor(){super(),this.openGroup=null,new z(this,b)}connectedCallback(){super.connectedCallback(),this.openGroupOfCurrentItem()}openGroupOfCurrentItem(){this.openGroup||(this.openGroup=b.navigationGroup)}handleGroupClick(n,e){var t;n.preventDefault(),this.openGroup=e.label!==((t=this.openGroup)==null?void 0:t.label)?e:null}handleNavItemClick(n,e){n.preventDefault(),this.dispatchEvent(new CustomEvent("bkdnavitemclick",{detail:{item:e},composed:!0,bubbles:!0}))}handleSettingsItemClick(n,e){this.dispatchEvent(new CustomEvent("bkdsettingsitemclick",{detail:{item:e,event:n},composed:!0,bubbles:!0}))}renderGroup(n){var t;const e=n.label===((t=this.openGroup)==null?void 0:t.label);return k`
      <li
        class=${le({group:!0,open:e})}
        aria-expanded=${e}
      >
        <button
          class="group-header"
          @click=${r=>this.handleGroupClick(r,n)}
        >
          <label> ${n.label} </label>
          ${Vr(e?qr:Br)}
        </button>
        <ul class="items">
          ${X(n.items,this.renderNavItem.bind(this))}
        </ul>
      </li>
    `}renderNavItem(n){const e=n.key===b.navigationItemKey;return k`
      <li
        class=${le({item:!0,active:e})}
      >
        <a
          href=${oe(n)}
          @click=${t=>this.handleNavItemClick(t,n)}
        >
          ${n.label}
        </a>
      </li>
    `}renderSettingsItem(n){return k`<li>
      <a
        href=${n.href}
        target=${n.external?"_blank":"_self"}
        @click=${e=>this.handleSettingsItemClick(e,n)}
      >
        ${n.label}
      </a>
      ${n.img?k`<img src=${n.img} alt="" width="24" height="24" />`:_}
    </li>`}render(){return k`
      <ul class="nav">
        ${X(b.navigation,this.renderGroup.bind(this))}
      </ul>
      <div class="service-nav">
        <ul>
          ${X(sn(b.locale),this.renderSettingsItem.bind(this))}
        </ul>
        <bkd-language-switcher></bkd-language-switcher>
      </div>
    `}};$e.styles=[S,E`
      :host {
        position: absolute;
        width: 100vw;
        padding: 1.25rem;
        left: 0;
        top: calc(100% + 1px); /* Place right below header */
        max-height: calc(100vh - 100% - 1px);
        display: flex;
        gap: 5rem;
        flex-direction: column;
        background-color: var(--bkd-func-bg-white);
        box-shadow: 0 2px 6px -1px var(--bkd-mobile-nav-shadow);
      }

      a {
        color: var(--bkd-brand-black);
        text-decoration: none;
      }

      ul {
        list-style: none;
        margin: 0;
        padding: 0;
      }

      li.group {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .group-header {
        display: flex;
        justify-content: space-between;
        width: 100%;
        padding: 0.5rem 1rem;
        cursor: pointer;
        border: none;
        background: transparent;
      }

      .group-header label {
        font-weight: 600;
        cursor: pointer;
      }

      ul.items {
        height: 0;
      }

      .open ul.items {
        height: auto;
      }

      li.item {
        display: flex; /* Animated bottom border should only be as wide as the link */
        border-left: 4px solid transparent;
        padding: 0.5rem 1.25rem;
      }

      li.item a {
        font-weight: 400;
      }

      li.item a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-brand-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      li.item a:hover::after,
      li.item a:focus::after,
      li.item a:active::after {
        transform: scaleX(1);
      }

      li.item.active {
        border-color: var(--bkd-brand-red);
        background-color: var(--bkd-brand-sand);
      }

      li.item.active a {
        font-weight: 600;
        color: var(--bkd-brand-red);
      }

      li.item.active a:after {
        border-color: transparent;
      }

      .service-nav {
        background: var(--bkd-brand-sand);
        padding: 1.5rem 2rem;
        display: flex;
        flex-direction: column;
        gap: 2rem;
      }

      .service-nav li {
        display: flex;
        gap: 0.5rem;
        align-items: center;
        height: 36px;
        line-height: 1.5;
      }

      .service-nav a {
        font-size: 0.875rem;
        font-weight: 400;
        color: var(--bkd-func-fg-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
        margin-top: 2px;
      }

      .service-nav a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      .service-nav a:hover::after,
      .service-nav a:focus::after {
        transform: scaleX(1);
      }

      bkd-language-switcher {
        margin-left: -0.75rem;
      }
    `];on([In()],$e.prototype,"openGroup",2);$e=on([x("bkd-mobile-nav"),P()],$e);var Wr=Object.defineProperty,Xr=Object.getOwnPropertyDescriptor,Qr=(n,e,t,r)=>{for(var i=r>1?void 0:r?Xr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Wr(e,t,i),i};let Xe=class extends A{constructor(){super(),new z(this,b)}renderGroupToggle(n,e){return k`
      <bkd-nav-group-toggle
        .group=${n}
        ?active=${e}
      ></bkd-nav-group-toggle>
    `}render(){return X(b.navigation,n=>{var e;return this.renderGroupToggle(n,n.label===((e=b.navigationGroup)==null?void 0:e.label))})}};Xe.styles=[S,E`
      /* Large screen */

      :host {
        display: flex;
        justify-content: end;
        gap: 4.375rem;
      }

      /* Medium screen */

      @media screen and (max-width: 1500px) {
        :host {
          gap: 3rem;
        }
      }
    `];Xe=Qr([x("bkd-nav"),P()],Xe);var Yr=Object.defineProperty,Jr=Object.getOwnPropertyDescriptor,at=(n,e,t,r)=>{for(var i=r>1?void 0:r?Jr(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Yr(e,t,i),i};let ce=class extends A{constructor(){super(),this.open=!1,new z(this,b)}handleItemClick(n,e){n.preventDefault(),this.dispatchEvent(new CustomEvent("bkdnavitemclick",{detail:{item:e},composed:!0,bubbles:!0}))}renderItem(n){const e=n.key===b.navigationItemKey;return k`
      <li role="presentation" class=${le({active:e})}>
        <a
          role="menuitem"
          href=${oe(n)}
          @click=${t=>this.handleItemClick(t,n)}
          >${n.label}</a
        >
      </li>
    `}render(){if(!(!this.group||!this.open))return k`
      <ul role="menu" id="group-menu">
        ${X(this.group.items,this.renderItem.bind(this))}
      </ul>
    `}};ce.styles=[S,E`
      :host {
        position: relative;
      }

      ul {
        position: absolute;
        right: 0;
        border: 1px solid var(--bkd-func-bg-grey);
        padding: 1rem 0;
        margin: 0.5rem 0;
        list-style-type: none;
        background: var(--bkd-func-bg-white);
        z-index: var(--bkd-z-index-dropdown);
        min-width: max-content;
      }

      li {
        padding: 0 1.5rem;
        height: 100%;
        line-height: 2.5;
      }

      li.active {
        background: var(--bkd-brand-sand);
        border-left: 6px solid var(--bkd-brand-red);
        padding: 0 calc(1.5rem - 6px);
      }

      li.active a {
        font-weight: 600;
        color: var(--bkd-brand-red);
      }

      li.active a:after {
        background-color: transparent;
      }

      a {
        font-size: 1.125rem;
        font-weight: 300;
        color: var(--bkd-brand-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a.active:after {
        background-color: var(--bkd-brand-red);
      }

      a:hover::after,
      a:focus::after,
      a:active::after,
      a.active:after {
        transform: scaleX(1);
      }
    `];at([D()],ce.prototype,"group",2);at([D()],ce.prototype,"open",2);ce=at([x("bkd-nav-group-dropdown"),P()],ce);var Zr=Object.defineProperty,ei=Object.getOwnPropertyDescriptor,lt=(n,e,t,r)=>{for(var i=r>1?void 0:r?ei(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&Zr(e,t,i),i};let de=class extends A{constructor(){super(...arguments),this.groupMenu=new ot(this,"group-toggle","group-menu")}toggle(n){n.preventDefault(),this.groupMenu.toggle()}handleItemClick(){this.groupMenu.close()}render(){if(this.group)return k`
      <a
        id="group-toggle"
        href="#"
        @click=${this.toggle.bind(this)}
        class=${le({active:!!this.active})}
        aria-expanded=${this.groupMenu.open}
        aria-haspopup="menu"
      >
        ${this.group.label}
      </a>
      <bkd-nav-group-dropdown
        .group=${this.group}
        .open=${this.groupMenu.open}
        @bkdnavitemclick=${this.handleItemClick.bind(this)}
      ></bkd-nav-group-dropdown>
    `}};de.styles=[S,E`
      a {
        font-size: 1.5rem;
        font-weight: 300;
        color: var(--bkd-brand-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a.active:after {
        background-color: var(--bkd-brand-red);
      }

      a:hover::after,
      a:focus::after,
      a:active::after,
      a.active:after {
        transform: scaleX(1);
      }
    `];lt([D()],de.prototype,"group",2);lt([D({type:Boolean})],de.prototype,"active",2);de=lt([x("bkd-nav-group-toggle"),P()],de);var ti=Object.defineProperty,ni=Object.getOwnPropertyDescriptor,an=(n,e,t,r)=>{for(var i=r>1?void 0:r?ni(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&ti(e,t,i),i};let Ae=class extends A{handleClick(n){n.preventDefault(),console.log("clicked",this.item)}render(){if(this.item)return k`<a href="#" @click=${this.handleClick.bind(this)}
      >${this.item.label}</a
    >`}};Ae.styles=[S,E``];an([D()],Ae.prototype,"item",2);Ae=an([x("bkd-nav-item-link"),P()],Ae);var ri=Object.defineProperty,ii=Object.getOwnPropertyDescriptor,ln=(n,e,t,r)=>{for(var i=r>1?void 0:r?ii(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&ri(e,t,i),i};let Ee=class extends A{constructor(){super(...arguments),this.mobileNavOpen=!1}render(){return k`
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <bkd-user-settings></bkd-user-settings>
      <bkd-language-switcher></bkd-language-switcher>
      <bkd-hamburger
        id="mobile-nav-toggle"
        .open=${this.mobileNavOpen}
      ></bkd-hamburger>
    `}};Ee.styles=[S,E`
      /* Large screen */

      :host {
        display: flex;
        align-items: center;
        gap: 2.5rem;
        margin-left: 1rem;
      }

      bkd-hamburger {
        display: none;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        bkd-user-settings {
          display: none;
        }

        bkd-language-switcher {
          display: none;
        }

        bkd-hamburger {
          display: inherit;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          gap: 1.5rem;
        }
      }
    `];ln([D()],Ee.prototype,"mobileNavOpen",2);Ee=ln([x("bkd-service-nav"),P()],Ee);var si=Object.defineProperty,oi=Object.getOwnPropertyDescriptor,cn=(n,e,t,r)=>{for(var i=r>1?void 0:r?oi(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&si(e,t,i),i};let Ce=class extends A{constructor(){super(),this.settingsMenu=new ot(this,"settings-toggle","settings-menu"),this.handleKeydown=n=>{if(this.menuLinks)switch(n.key){case"ArrowDown":{const e=this.nextLinkIndex(1);this.menuLinks[e].focus();break}case"ArrowUp":{const e=this.nextLinkIndex(-1);this.menuLinks[e].focus();break}}},new z(this,b)}handleSettingsItemClick(n,e){this.settingsMenu.close(),this.dispatchEvent(new CustomEvent("bkdsettingsitemclick",{detail:{item:e,event:n},composed:!0,bubbles:!0}))}toggle(){this.settingsMenu.toggle(),this.settingsMenu.open?document.addEventListener("keydown",this.handleKeydown):document.removeEventListener("keydown",this.handleKeydown)}activeLinkIndex(){var t;const n=((t=this.shadowRoot)==null?void 0:t.activeElement)??null,e=n?Array.from(this.menuLinks??[]).indexOf(n):-1;return e===-1?null:e}nextLinkIndex(n){const e=this.activeLinkIndex(),t=0,r=this.menuLinks?this.menuLinks.length-1:0;if(e===null)return n>0?t:r;const i=e+n;return i>r?t:i<t?r:i}renderSettingsItem(n){return k`<li role="presentation">
      <a
        role="menuitem"
        href=${n.href}
        target=${n.external?"_blank":"_self"}
        @click=${e=>this.handleSettingsItemClick(e,n)}
      >
        ${n.label}</a
      >
      ${n.img?k`<img src=${n.img} alt="" width="24" height="24" />`:_}
    </li>`}render(){return k`
      <button
        type="button"
        id="settings-toggle"
        @click=${this.toggle.bind(this)}
        aria-label=${m("Menü Benutzereinstellungen")}
        aria-expanded=${this.settingsMenu.open}
        aria-haspopup="menu"
      >
        <img src="/icons/settings.svg" alt="" width="32" height="32" />
      </button>
      <ul id="settings-menu" role="menu" ?hidden=${!this.settingsMenu.open}>
        ${X(sn(b.locale),this.renderSettingsItem.bind(this))}
      </ul>
    `}};Ce.styles=[S,E`
      :host {
        display: flex;
        position: relative;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }

      ul {
        position: absolute;
        right: 0;
        border: 1px solid var(--bkd-func-bg-grey);
        padding: 1rem 0;
        list-style-type: none;
        margin-top: calc(32px + 0.5rem);
        background: var(--bkd-func-bg-white);
        z-index: var(--bkd-z-index-dropdown);
        min-width: max-content;
      }

      li {
        padding: 0 1.5rem;
        display: flex;
        gap: 0.5rem;
        align-items: center;
        height: 36px;
      }

      li.selected {
        color: var(--bkd-brand-red);
        background: var(--bkd-brand-sand);
        border-left: 6px solid var(--bkd-brand-red);
        font-weight: 700;
        padding: 0 calc(1.5rem - 6px);
      }

      a {
        font-size: 0.875rem;
        font-weight: 400;
        color: var(--bkd-func-fg-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
        margin-top: 2px;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a:hover::after,
      a:focus::after {
        transform: scaleX(1);
      }
    `];cn([Rn("a")],Ce.prototype,"menuLinks",2);Ce=cn([x("bkd-user-settings"),P()],Ce);function ai(n){if(n.__esModule)return n;var e=n.default;if(typeof e=="function"){var t=function r(){if(this instanceof r){var i=[null];i.push.apply(i,arguments);var s=Function.bind.apply(e,i);return new s}return e.apply(this,arguments)};t.prototype=e.prototype}else t={};return Object.defineProperty(t,"__esModule",{value:!0}),Object.keys(n).forEach(function(r){var i=Object.getOwnPropertyDescriptor(n,r);Object.defineProperty(t,r,i.get?i:{enumerable:!0,get:function(){return n[r]}})}),t}var dn={exports:{}};(function(n,e){(function(t,r){n.exports=r()})(self,()=>(()=>{var t={934:(o,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.generateQueryString=l.tokenResponseToOAuth2Token=l.OAuth2Client=void 0;const c=a(443),p=a(618);function d(f,h){return new URL(f,h).toString()}function u(f){return f.then(h=>{var g;return{accessToken:h.access_token,expiresAt:h.expires_in?Date.now()+1e3*h.expires_in:null,refreshToken:(g=h.refresh_token)!==null&&g!==void 0?g:null}})}function v(f){return new URLSearchParams(Object.fromEntries(Object.entries(f).filter(([h,g])=>g!==void 0))).toString()}l.OAuth2Client=class{constructor(f){this.discoveryDone=!1,this.serverMetadata=null,f!=null&&f.fetch||(f.fetch=fetch),this.settings=f}async refreshToken(f){if(!f.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const h={grant_type:"refresh_token",refresh_token:f.refreshToken};return this.settings.clientSecret||(h.client_id=this.settings.clientId),u(this.request("tokenEndpoint",h))}async clientCredentials(f){var h;const g=["client_id","client_secret","grant_type","scope"];if(f!=null&&f.extraParams&&Object.keys(f.extraParams).filter(y=>g.includes(y)).length>0)throw new Error(`The following extraParams are disallowed: '${g.join("', '")}'`);const w={grant_type:"client_credentials",scope:(h=f==null?void 0:f.scope)===null||h===void 0?void 0:h.join(" "),...f==null?void 0:f.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return u(this.request("tokenEndpoint",w))}async password(f){var h;const g={grant_type:"password",...f,scope:(h=f.scope)===null||h===void 0?void 0:h.join(" ")};return u(this.request("tokenEndpoint",g))}get authorizationCode(){return new p.OAuth2AuthorizationCodeClient(this)}async introspect(f){const h={token:f.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",h)}async getEndpoint(f){if(this.settings[f]!==void 0)return d(this.settings[f],this.settings.server);if(f!=="discoveryEndpoint"&&(await this.discover(),this.settings[f]!==void 0))return d(this.settings[f],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${f}. Either specify ${f} in the settings, or the "server" endpoint to let the client discover it.`);switch(f){case"authorizationEndpoint":return d("/authorize",this.settings.server);case"tokenEndpoint":return d("/token",this.settings.server);case"discoveryEndpoint":return d("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return d("/introspect",this.settings.server)}}async discover(){var f;if(this.discoveryDone)return;let h;this.discoveryDone=!0;try{h=await this.getEndpoint("discoveryEndpoint")}catch{return void console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint')}const g=await this.settings.fetch(h,{headers:{Accept:"application/json"}});if(!g.ok)return;if(!(!((f=g.headers.get("Content-Type"))===null||f===void 0)&&f.startsWith("application/json")))return void console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");this.serverMetadata=await g.json();const w=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[y,C]of w)this.serverMetadata[y]&&(this.settings[C]=d(this.serverMetadata[y],h));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(f,h){const g=await this.getEndpoint(f),w={"Content-Type":"application/x-www-form-urlencoded"};let y=this.settings.authenticationMethod;switch(y||(y=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),y){case"client_secret_basic":w.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":h.client_id=this.settings.clientId,this.settings.clientSecret&&(h.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+y+". Open a feature request if you want this!")}const C=await this.settings.fetch(g,{method:"POST",body:v(h),headers:w});if(C.ok)return await C.json();let T,Z,Se;throw C.headers.has("Content-Type")&&C.headers.get("Content-Type").startsWith("application/json")&&(T=await C.json()),T!=null&&T.error?(Z="OAuth2 error "+T.error+".",T.error_description&&(Z+=" "+T.error_description),Se=T.error):(Z="HTTP Error "+C.status+" "+C.statusText,C.status===401&&this.settings.clientSecret&&(Z+=". It's likely that the clientId and/or clientSecret was incorrect"),Se=null),new c.OAuth2Error(Z,Se,C.status)}},l.tokenResponseToOAuth2Token=u,l.generateQueryString=v},618:(o,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.getCodeChallenge=l.generateCodeVerifier=l.OAuth2AuthorizationCodeClient=void 0;const c=a(934),p=a(443);async function d(h){const g=u();if(g!=null&&g.subtle)return["S256",f(await g.subtle.digest("SHA-256",v(h)))];{const w=a(212).createHash("sha256");return w.update(v(h)),["S256",w.digest("base64url")]}}function u(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const h=a(212);return h.webcrypto?h.webcrypto:null}function v(h){const g=new Uint8Array(h.length);for(let w=0;w<h.length;w++)g[w]=255&h.charCodeAt(w);return g}function f(h){return btoa(String.fromCharCode(...new Uint8Array(h))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}l.OAuth2AuthorizationCodeClient=class{constructor(h){this.client=h}async getAuthorizeUri(h){const[g,w]=await Promise.all([h.codeVerifier?d(h.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),y={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:h.redirectUri,code_challenge_method:g==null?void 0:g[0],code_challenge:g==null?void 0:g[1]};return h.state&&(y.state=h.state),h.scope&&(y.scope=h.scope.join(" ")),w+"?"+(0,c.generateQueryString)(y)}async getTokenFromCodeRedirect(h,g){const{code:w}=await this.validateResponse(h,{state:g.state});return this.getToken({code:w,redirectUri:g.redirectUri,codeVerifier:g.codeVerifier})}async validateResponse(h,g){var w;const y=new URL(h).searchParams;if(y.has("error"))throw new p.OAuth2Error((w=y.get("error_description"))!==null&&w!==void 0?w:"OAuth2 error",y.get("error"),0);if(!y.has("code"))throw new Error(`The url did not contain a code parameter ${h}`);if(g.state&&g.state!==y.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${g.state}`);return{code:y.get("code"),scope:y.has("scope")?y.get("scope").split(" "):void 0}}async getToken(h){const g={grant_type:"authorization_code",code:h.code,redirect_uri:h.redirectUri,code_verifier:h.codeVerifier};return(0,c.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",g))}},l.generateCodeVerifier=async function(){const h=u();if(h){const g=new Uint8Array(32);return h.getRandomValues(g),f(g)}{const g=a(212);return new Promise((w,y)=>{g.randomBytes(32,(C,T)=>{C&&y(C),w(T.toString("base64url"))})})}},l.getCodeChallenge=d},443:(o,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Error=void 0;class a extends Error{constructor(p,d,u){super(p),this.oauth2Code=d,this.httpCode=u}}l.OAuth2Error=a},13:(o,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Fetch=void 0,l.OAuth2Fetch=class{constructor(a){this.token=null,this.activeRefresh=null,this.refreshTimer=null,(a==null?void 0:a.scheduleRefresh)===void 0&&(a.scheduleRefresh=!0),this.options=a,a.getStoredToken&&(async()=>this.token=await a.getStoredToken())(),this.scheduleRefresh()}async fetch(a,c){const p=new Request(a,c);return this.mw()(p,d=>fetch(d))}mw(){return async(a,c)=>{const p=await this.getAccessToken();let d=a.clone();d.headers.set("Authorization","Bearer "+p);let u=await c(d);if(!u.ok&&u.status===401){const v=await this.refreshToken();d=a.clone(),d.headers.set("Authorization","Bearer "+v.accessToken),u=await c(d)}return u}}async getToken(){return this.token&&(this.token.expiresAt===null||this.token.expiresAt>Date.now())?this.token:this.refreshToken()}async getAccessToken(){return(await this.getToken()).accessToken}async refreshToken(){var a,c;if(this.activeRefresh)return this.activeRefresh;const p=this.token;this.activeRefresh=(async()=>{var d,u;let v=null;try{p!=null&&p.refreshToken&&(v=await this.options.client.refreshToken(p))}catch{console.warn("[oauth2] refresh token not accepted, we'll try reauthenticating")}if(v||(v=await this.options.getNewToken()),!v){const f=new Error("Unableto obtain OAuth2 tokens, a full reauth may be needed");throw(u=(d=this.options).onError)===null||u===void 0||u.call(d,f),f}return v})();try{const d=await this.activeRefresh;return this.token=d,(c=(a=this.options).storeToken)===null||c===void 0||c.call(a,d),this.scheduleRefresh(),d}catch(d){throw this.options.onError&&this.options.onError(d),d}finally{this.activeRefresh=null}}scheduleRefresh(){var a;if(!this.options.scheduleRefresh||(this.refreshTimer&&(clearTimeout(this.refreshTimer),this.refreshTimer=null),!(!((a=this.token)===null||a===void 0)&&a.expiresAt)||!this.token.refreshToken))return;const c=this.token.expiresAt-Date.now();c<12e4||(this.refreshTimer=setTimeout(async()=>{try{await this.refreshToken()}catch(p){console.error("[fetch-mw-oauth2] error while doing a background OAuth2 auto-refresh",p)}},c-6e4))}}},212:()=>{}},r={};function i(o){var l=r[o];if(l!==void 0)return l.exports;var a=r[o]={exports:{}};return t[o](a,a.exports,i),a.exports}var s={};return(()=>{var o=s;Object.defineProperty(o,"__esModule",{value:!0}),o.OAuth2Error=o.OAuth2Fetch=o.generateCodeVerifier=o.OAuth2AuthorizationCodeClient=o.OAuth2Client=void 0;var l=i(934);Object.defineProperty(o,"OAuth2Client",{enumerable:!0,get:function(){return l.OAuth2Client}});var a=i(618);Object.defineProperty(o,"OAuth2AuthorizationCodeClient",{enumerable:!0,get:function(){return a.OAuth2AuthorizationCodeClient}}),Object.defineProperty(o,"generateCodeVerifier",{enumerable:!0,get:function(){return a.generateCodeVerifier}});var c=i(13);Object.defineProperty(o,"OAuth2Fetch",{enumerable:!0,get:function(){return c.OAuth2Fetch}});var p=i(443);Object.defineProperty(o,"OAuth2Error",{enumerable:!0,get:function(){return p.OAuth2Error}})})(),s})())})(dn);var ct=dn.exports,I={},R={},pe={};Object.defineProperty(pe,"__esModule",{value:!0});pe.OAuth2Error=void 0;class li extends Error{constructor(e,t,r){super(e),this.oauth2Code=t,this.httpCode=r}}pe.OAuth2Error=li;var Ot;function hn(){if(Ot)return R;Ot=1,Object.defineProperty(R,"__esModule",{value:!0}),R.generateQueryString=R.tokenResponseToOAuth2Token=R.OAuth2Client=void 0;const n=pe,e=un();class t{constructor(l){this.discoveryDone=!1,this.serverMetadata=null,l!=null&&l.fetch||(l.fetch=fetch),this.settings=l}async refreshToken(l){if(!l.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const a={grant_type:"refresh_token",refresh_token:l.refreshToken};return this.settings.clientSecret||(a.client_id=this.settings.clientId),i(this.request("tokenEndpoint",a))}async clientCredentials(l){var a;const c=["client_id","client_secret","grant_type","scope"];if(l!=null&&l.extraParams&&Object.keys(l.extraParams).filter(d=>c.includes(d)).length>0)throw new Error(`The following extraParams are disallowed: '${c.join("', '")}'`);const p={grant_type:"client_credentials",scope:(a=l==null?void 0:l.scope)===null||a===void 0?void 0:a.join(" "),...l==null?void 0:l.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return i(this.request("tokenEndpoint",p))}async password(l){var a;const c={grant_type:"password",...l,scope:(a=l.scope)===null||a===void 0?void 0:a.join(" ")};return i(this.request("tokenEndpoint",c))}get authorizationCode(){return new e.OAuth2AuthorizationCodeClient(this)}async introspect(l){const a={token:l.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",a)}async getEndpoint(l){if(this.settings[l]!==void 0)return r(this.settings[l],this.settings.server);if(l!=="discoveryEndpoint"&&(await this.discover(),this.settings[l]!==void 0))return r(this.settings[l],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${l}. Either specify ${l} in the settings, or the "server" endpoint to let the client discover it.`);switch(l){case"authorizationEndpoint":return r("/authorize",this.settings.server);case"tokenEndpoint":return r("/token",this.settings.server);case"discoveryEndpoint":return r("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return r("/introspect",this.settings.server)}}async discover(){var l;if(this.discoveryDone)return;this.discoveryDone=!0;let a;try{a=await this.getEndpoint("discoveryEndpoint")}catch{console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint');return}const c=await this.settings.fetch(a,{headers:{Accept:"application/json"}});if(!c.ok)return;if(!(!((l=c.headers.get("Content-Type"))===null||l===void 0)&&l.startsWith("application/json"))){console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");return}this.serverMetadata=await c.json();const p=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[d,u]of p)this.serverMetadata[d]&&(this.settings[u]=r(this.serverMetadata[d],a));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(l,a){const c=await this.getEndpoint(l),p={"Content-Type":"application/x-www-form-urlencoded"};let d=this.settings.authenticationMethod;switch(d||(d=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),d){case"client_secret_basic":p.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":a.client_id=this.settings.clientId,this.settings.clientSecret&&(a.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+d+". Open a feature request if you want this!")}const u=await this.settings.fetch(c,{method:"POST",body:s(a),headers:p});if(u.ok)return await u.json();let v,f,h;throw u.headers.has("Content-Type")&&u.headers.get("Content-Type").startsWith("application/json")&&(v=await u.json()),v!=null&&v.error?(f="OAuth2 error "+v.error+".",v.error_description&&(f+=" "+v.error_description),h=v.error):(f="HTTP Error "+u.status+" "+u.statusText,u.status===401&&this.settings.clientSecret&&(f+=". It's likely that the clientId and/or clientSecret was incorrect"),h=null),new n.OAuth2Error(f,h,u.status)}}R.OAuth2Client=t;function r(o,l){return new URL(o,l).toString()}function i(o){return o.then(l=>{var a;return{accessToken:l.access_token,expiresAt:l.expires_in?Date.now()+l.expires_in*1e3:null,refreshToken:(a=l.refresh_token)!==null&&a!==void 0?a:null}})}R.tokenResponseToOAuth2Token=i;function s(o){return new URLSearchParams(Object.fromEntries(Object.entries(o).filter(([l,a])=>a!==void 0))).toString()}return R.generateQueryString=s,R}const ci={},di=Object.freeze(Object.defineProperty({__proto__:null,default:ci},Symbol.toStringTag,{value:"Module"})),Ne=ai(di);var Tt;function un(){if(Tt)return I;Tt=1,Object.defineProperty(I,"__esModule",{value:!0}),I.getCodeChallenge=I.generateCodeVerifier=I.OAuth2AuthorizationCodeClient=void 0;const n=hn(),e=pe;class t{constructor(c){this.client=c}async getAuthorizeUri(c){const[p,d]=await Promise.all([c.codeVerifier?i(c.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),u={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:c.redirectUri,code_challenge_method:p==null?void 0:p[0],code_challenge:p==null?void 0:p[1]};return c.state&&(u.state=c.state),c.scope&&(u.scope=c.scope.join(" ")),d+"?"+(0,n.generateQueryString)(u)}async getTokenFromCodeRedirect(c,p){const{code:d}=await this.validateResponse(c,{state:p.state});return this.getToken({code:d,redirectUri:p.redirectUri,codeVerifier:p.codeVerifier})}async validateResponse(c,p){var d;const u=new URL(c).searchParams;if(u.has("error"))throw new e.OAuth2Error((d=u.get("error_description"))!==null&&d!==void 0?d:"OAuth2 error",u.get("error"),0);if(!u.has("code"))throw new Error(`The url did not contain a code parameter ${c}`);if(p.state&&p.state!==u.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${p.state}`);return{code:u.get("code"),scope:u.has("scope")?u.get("scope").split(" "):void 0}}async getToken(c){const p={grant_type:"authorization_code",code:c.code,redirect_uri:c.redirectUri,code_verifier:c.codeVerifier};return(0,n.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",p))}}I.OAuth2AuthorizationCodeClient=t;async function r(){const a=s();if(a){const c=new Uint8Array(32);return a.getRandomValues(c),l(c)}else{const c=Ne;return new Promise((p,d)=>{c.randomBytes(32,(u,v)=>{u&&d(u),p(v.toString("base64url"))})})}}I.generateCodeVerifier=r;async function i(a){const c=s();if(c!=null&&c.subtle)return["S256",l(await c.subtle.digest("SHA-256",o(a)))];{const d=Ne.createHash("sha256");return d.update(o(a)),["S256",d.digest("base64url")]}}I.getCodeChallenge=i;function s(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const a=Ne;return a.webcrypto?a.webcrypto:null}function o(a){const c=new Uint8Array(a.length);for(let p=0;p<a.length;p++)c[p]=a.charCodeAt(p)&255;return c}function l(a){return btoa(String.fromCharCode(...new Uint8Array(a))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}return I}var pn=un(),hi=hn();function ui(){return new ct.OAuth2Client({server:$.oauth.server,clientId:$.oauth.clientId,tokenEndpoint:"/OAuth/Authorization/Token",authorizationEndpoint:gi(),fetch:(...n)=>fetch(...n)})}async function pi(n,e){const t=kr(),r=await vi(n,t);r?(console.log("Successfully logged in"),bi(r,t)):Yt(st())?(console.log("Not authenticated, redirect to login"),await ne(n,e,dt)):(console.log(`Activate token for scope "${e}"`),await fn(n,e))}async function fn(n,e){if(Yt(st()))return console.log("Refresh token expired, redirect to login"),ne(n,e,dt);const t=G(),r=mr(e),i=t?ue(t):null;(i==null?void 0:i.scope)===e?St(i)?(console.log(`Current token for scope "${e}" half expired, redirect for token refresh`),await ne(n,e,It)):console.log(`Current token for scope "${e}" already present`):!r||St(r)?(console.log(`No Token for scope "${e}" present or half expired, redirect for token refresh`),await ne(n,e,It)):(console.log(`Token for requested scope "${e}" present, set as current`),Qt(r))}async function fi(n,e){const t=Xt();if(!t)throw new Error("No instance available");const r=G();if(r)try{await mi(n,`/OAuth/Authorization/${t}/Logout`,{access_token:r})}catch(i){if(!(i instanceof SyntaxError))throw i}finally{wr(),await ne(n,e,dt)}}function gi(){const n=Xt();return n?`/OAuth/Authorization/${n}/Login`:"/OAuth/Authorization/Login"}async function ne(n,e,t){const r=await ct.generateCodeVerifier(),i=document.location.href;_r(r,i);const s=await t(n,e,i,r);document.location.href=s.toString()}const dt=async(n,e,t,r)=>{const i=new URL(await n.getEndpoint("authorizationEndpoint")),[s,o]=await pn.getCodeChallenge(r);return i.searchParams.set("clientId",n.settings.clientId),i.searchParams.set("redirectUrl",t),i.searchParams.set("culture_info","de-CH"),i.searchParams.set("application_scope",e),i.searchParams.set("response_type","code"),i.searchParams.set("code_challenge_method",s),i.searchParams.set("code_challenge",o),i},It=async(n,e,t,r)=>{const i=new URL("/OAuth/Authorization/RefreshPublic",n.settings.server),[s,o]=await pn.getCodeChallenge(r),l=st();return i.searchParams.set("redirectUrl",t),i.searchParams.set("culture_info","de-CH"),i.searchParams.set("application_scope",e),i.searchParams.set("refresh_token",l??""),i.searchParams.set("response_type","code"),i.searchParams.set("code_challenge_method",s),i.searchParams.set("code_challenge",o),i};async function vi(n,e){return new URLSearchParams(document.location.search).get("code")&&(e!=null&&e.redirectUri)?await n.authorizationCode.getTokenFromCodeRedirect(document.location.href,{redirectUri:e.redirectUri,codeVerifier:e.codeVerifier}):null}function bi(n,e){const{accessToken:t}=n,{scope:r,instanceId:i}=ue(t);yr(r,n),Qt(t),br(i),e!=null&&e.redirectUri&&b.navigate(new URL(e.redirectUri))}async function mi(n,e,t){var c;const r=new URL(e,n.settings.server).toString(),i={"Content-Type":"application/x-www-form-urlencoded"},s=await fetch(r,{method:"POST",body:t&&hi.generateQueryString(t),headers:i});if(s.ok)return await s.json();let o,l,a;throw(c=s.headers.get("Content-Type"))!=null&&c.startsWith("application/json")&&(o=await s.json()),o!=null&&o.error?(l="OAuth2 error "+o.error+".",o.error_description&&(l+=" "+o.error_description),a=o.error):(l="HTTP Error "+s.status+" "+s.statusText,a=null),new ct.OAuth2Error(l,a,s.status)}var yi=Object.defineProperty,wi=Object.getOwnPropertyDescriptor,ki=(n,e,t,r)=>{for(var i=r>1?void 0:r?wi(e,t):e,s=n.length-1,o;s>=0;s--)(o=n[s])&&(i=(r?o(e,t,i):o(i))||i);return r&&i&&yi(e,t,i),i};const Qe=ui();(async function(){await pi(Qe,gr()),b.init()})();Jn(E`
    :root {
      ${Bt}
    }
  `.toString());let Ye=class extends A{constructor(){super(),this.subscriptions=[],new z(this,b)}connectedCallback(){super.connectedCallback(),this.subscriptions.push(b.subscribeScope(n=>fn(Qe,n),!0)),this.subscriptions.push(b.subscribeInstanceName(this.updateTitle.bind(this))),this.subscriptions.push(b.subscribeNavigationItem(this.updateTitle.bind(this)))}disconnectedCallback(){super.disconnectedCallback(),this.subscriptions.forEach(n=>n())}isAuthenticated(){return!!G()}updateTitle(){const{instanceName:n,navigationItem:e}=b,t=(e==null?void 0:e.label)&&(e==null?void 0:e.key)!==$.navigationHome.key;document.title=t?[e==null?void 0:e.label,n].join(" ― "):n}handleLogout(){fi(Qe,b.app.scope)}render(){return k`
      ${Zt(this.isAuthenticated(),()=>k`
          <bkd-header @bkdlogout=${this.handleLogout.bind(this)}></bkd-header>
          <bkd-content></bkd-content>
          <bkd-footer></bkd-footer>
        `)}
    `}};Ye.styles=[S,E`
      :host {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        width: 100%;
        max-width: 1920px;
        margin: 0 auto;
      }

      bkd-content {
        flex: auto;
      }
    `];Ye=ki([x("bkd-portal"),P()],Ye);
