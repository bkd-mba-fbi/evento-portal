(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))o(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const s of i.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&o(s)}).observe(document,{childList:!0,subtree:!0});function t(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(n){if(n.ep)return;n.ep=!0;const i=t(n);fetch(n.href,i)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ee=window,Le=ee.ShadowRoot&&(ee.ShadyCSS===void 0||ee.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,ze=Symbol(),Ue=new WeakMap;let rt=class{constructor(e,t,o){if(this._$cssResult$=!0,o!==ze)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(Le&&e===void 0){const o=t!==void 0&&t.length===1;o&&(e=Ue.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),o&&Ue.set(t,e))}return e}toString(){return this.cssText}};const zt=r=>new rt(typeof r=="string"?r:r+"",void 0,ze),A=(r,...e)=>{const t=r.length===1?r[0]:e.reduce((o,n,i)=>o+(s=>{if(s._$cssResult$===!0)return s.cssText;if(typeof s=="number")return s;throw Error("Value passed to 'css' function must be a 'css' function result: "+s+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(n)+r[i+1],r[0]);return new rt(t,r,ze)},Rt=(r,e)=>{Le?r.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet):e.forEach(t=>{const o=document.createElement("style"),n=ee.litNonce;n!==void 0&&o.setAttribute("nonce",n),o.textContent=t.cssText,r.appendChild(o)})},je=Le?r=>r:r=>r instanceof CSSStyleSheet?(e=>{let t="";for(const o of e.cssRules)t+=o.cssText;return zt(t)})(r):r;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var ge;const re=window,Me=re.trustedTypes,Ut=Me?Me.emptyScript:"",Ie=re.reactiveElementPolyfillSupport,Ae={toAttribute(r,e){switch(e){case Boolean:r=r?Ut:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,e){let t=r;switch(e){case Boolean:t=r!==null;break;case Number:t=r===null?null:Number(r);break;case Object:case Array:try{t=JSON.parse(r)}catch{t=null}}return t}},nt=(r,e)=>e!==r&&(e==e||r==r),ve={attribute:!0,type:String,converter:Ae,reflect:!1,hasChanged:nt};let D=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(e){var t;this.finalize(),((t=this.h)!==null&&t!==void 0?t:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((t,o)=>{const n=this._$Ep(o,t);n!==void 0&&(this._$Ev.set(n,o),e.push(n))}),e}static createProperty(e,t=ve){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const o=typeof e=="symbol"?Symbol():"__"+e,n=this.getPropertyDescriptor(e,o,t);n!==void 0&&Object.defineProperty(this.prototype,e,n)}}static getPropertyDescriptor(e,t,o){return{get(){return this[t]},set(n){const i=this[e];this[t]=n,this.requestUpdate(e,i,o)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||ve}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),e.h!==void 0&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const t=this.properties,o=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const n of o)this.createProperty(n,t[n])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const o=new Set(e.flat(1/0).reverse());for(const n of o)t.unshift(je(n))}else e!==void 0&&t.push(je(e));return t}static _$Ep(e,t){const o=t.attribute;return o===!1?void 0:typeof o=="string"?o:typeof e=="string"?e.toLowerCase():void 0}u(){var e;this._$E_=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(e=this.constructor.h)===null||e===void 0||e.forEach(t=>t(this))}addController(e){var t,o;((t=this._$ES)!==null&&t!==void 0?t:this._$ES=[]).push(e),this.renderRoot!==void 0&&this.isConnected&&((o=e.hostConnected)===null||o===void 0||o.call(e))}removeController(e){var t;(t=this._$ES)===null||t===void 0||t.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((e,t)=>{this.hasOwnProperty(t)&&(this._$Ei.set(t,this[t]),delete this[t])})}createRenderRoot(){var e;const t=(e=this.shadowRoot)!==null&&e!==void 0?e:this.attachShadow(this.constructor.shadowRootOptions);return Rt(t,this.constructor.elementStyles),t}connectedCallback(){var e;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$ES)===null||e===void 0||e.forEach(t=>{var o;return(o=t.hostConnected)===null||o===void 0?void 0:o.call(t)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$ES)===null||e===void 0||e.forEach(t=>{var o;return(o=t.hostDisconnected)===null||o===void 0?void 0:o.call(t)})}attributeChangedCallback(e,t,o){this._$AK(e,o)}_$EO(e,t,o=ve){var n;const i=this.constructor._$Ep(e,o);if(i!==void 0&&o.reflect===!0){const s=(((n=o.converter)===null||n===void 0?void 0:n.toAttribute)!==void 0?o.converter:Ae).toAttribute(t,o.type);this._$El=e,s==null?this.removeAttribute(i):this.setAttribute(i,s),this._$El=null}}_$AK(e,t){var o;const n=this.constructor,i=n._$Ev.get(e);if(i!==void 0&&this._$El!==i){const s=n.getPropertyOptions(i),l=typeof s.converter=="function"?{fromAttribute:s.converter}:((o=s.converter)===null||o===void 0?void 0:o.fromAttribute)!==void 0?s.converter:Ae;this._$El=i,this[i]=l.fromAttribute(t,s.type),this._$El=null}}requestUpdate(e,t,o){let n=!0;e!==void 0&&(((o=o||this.constructor.getPropertyOptions(e)).hasChanged||nt)(this[e],t)?(this._$AL.has(e)||this._$AL.set(e,t),o.reflect===!0&&this._$El!==e&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(e,o))):n=!1),!this.isUpdatePending&&n&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((n,i)=>this[i]=n),this._$Ei=void 0);let t=!1;const o=this._$AL;try{t=this.shouldUpdate(o),t?(this.willUpdate(o),(e=this._$ES)===null||e===void 0||e.forEach(n=>{var i;return(i=n.hostUpdate)===null||i===void 0?void 0:i.call(n)}),this.update(o)):this._$Ek()}catch(n){throw t=!1,this._$Ek(),n}t&&this._$AE(o)}willUpdate(e){}_$AE(e){var t;(t=this._$ES)===null||t===void 0||t.forEach(o=>{var n;return(n=o.hostUpdated)===null||n===void 0?void 0:n.call(o)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){this._$EC!==void 0&&(this._$EC.forEach((t,o)=>this._$EO(o,this[o],t)),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}};D.finalized=!0,D.elementProperties=new Map,D.elementStyles=[],D.shadowRootOptions={mode:"open"},Ie==null||Ie({ReactiveElement:D}),((ge=re.reactiveElementVersions)!==null&&ge!==void 0?ge:re.reactiveElementVersions=[]).push("1.6.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var me;const ne=window,H=ne.trustedTypes,Ne=H?H.createPolicy("lit-html",{createHTML:r=>r}):void 0,Ee="$lit$",L=`lit$${(Math.random()+"").slice(9)}$`,ot="?"+L,jt=`<${ot}>`,j=document,K=()=>j.createComment(""),W=r=>r===null||typeof r!="object"&&typeof r!="function",it=Array.isArray,Mt=r=>it(r)||typeof(r==null?void 0:r[Symbol.iterator])=="function",be=`[ 	
\f\r]`,q=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,De=/-->/g,He=/>/g,z=RegExp(`>|${be}(?:([^\\s"'>=/]+)(${be}*=${be}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Be=/'/g,Ve=/"/g,st=/^(?:script|style|textarea|title)$/i,It=r=>(e,...t)=>({_$litType$:r,strings:e,values:t}),y=It(1),M=Symbol.for("lit-noChange"),_=Symbol.for("lit-nothing"),qe=new WeakMap,U=j.createTreeWalker(j,129,null,!1),Nt=(r,e)=>{const t=r.length-1,o=[];let n,i=e===2?"<svg>":"",s=q;for(let a=0;a<t;a++){const c=r[a];let p,d,u=-1,v=0;for(;v<c.length&&(s.lastIndex=v,d=s.exec(c),d!==null);)v=s.lastIndex,s===q?d[1]==="!--"?s=De:d[1]!==void 0?s=He:d[2]!==void 0?(st.test(d[2])&&(n=RegExp("</"+d[2],"g")),s=z):d[3]!==void 0&&(s=z):s===z?d[0]===">"?(s=n??q,u=-1):d[1]===void 0?u=-2:(u=s.lastIndex-d[2].length,p=d[1],s=d[3]===void 0?z:d[3]==='"'?Ve:Be):s===Ve||s===Be?s=z:s===De||s===He?s=q:(s=z,n=void 0);const f=s===z&&r[a+1].startsWith("/>")?" ":"";i+=s===q?c+jt:u>=0?(o.push(p),c.slice(0,u)+Ee+c.slice(u)+L+f):c+L+(u===-2?(o.push(void 0),a):f)}const l=i+(r[t]||"<?>")+(e===2?"</svg>":"");if(!Array.isArray(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return[Ne!==void 0?Ne.createHTML(l):l,o]};class X{constructor({strings:e,_$litType$:t},o){let n;this.parts=[];let i=0,s=0;const l=e.length-1,a=this.parts,[c,p]=Nt(e,t);if(this.el=X.createElement(c,o),U.currentNode=this.el.content,t===2){const d=this.el.content,u=d.firstChild;u.remove(),d.append(...u.childNodes)}for(;(n=U.nextNode())!==null&&a.length<l;){if(n.nodeType===1){if(n.hasAttributes()){const d=[];for(const u of n.getAttributeNames())if(u.endsWith(Ee)||u.startsWith(L)){const v=p[s++];if(d.push(u),v!==void 0){const f=n.getAttribute(v.toLowerCase()+Ee).split(L),h=/([.?@])?(.*)/.exec(v);a.push({type:1,index:i,name:h[2],strings:f,ctor:h[1]==="."?Ht:h[1]==="?"?Vt:h[1]==="@"?qt:ue})}else a.push({type:6,index:i})}for(const u of d)n.removeAttribute(u)}if(st.test(n.tagName)){const d=n.textContent.split(L),u=d.length-1;if(u>0){n.textContent=H?H.emptyScript:"";for(let v=0;v<u;v++)n.append(d[v],K()),U.nextNode(),a.push({type:2,index:++i});n.append(d[u],K())}}}else if(n.nodeType===8)if(n.data===ot)a.push({type:2,index:i});else{let d=-1;for(;(d=n.data.indexOf(L,d+1))!==-1;)a.push({type:7,index:i}),d+=L.length-1}i++}}static createElement(e,t){const o=j.createElement("template");return o.innerHTML=e,o}}function B(r,e,t=r,o){var n,i,s,l;if(e===M)return e;let a=o!==void 0?(n=t._$Co)===null||n===void 0?void 0:n[o]:t._$Cl;const c=W(e)?void 0:e._$litDirective$;return(a==null?void 0:a.constructor)!==c&&((i=a==null?void 0:a._$AO)===null||i===void 0||i.call(a,!1),c===void 0?a=void 0:(a=new c(r),a._$AT(r,t,o)),o!==void 0?((s=(l=t)._$Co)!==null&&s!==void 0?s:l._$Co=[])[o]=a:t._$Cl=a),a!==void 0&&(e=B(r,a._$AS(r,e.values),a,o)),e}class Dt{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var t;const{el:{content:o},parts:n}=this._$AD,i=((t=e==null?void 0:e.creationScope)!==null&&t!==void 0?t:j).importNode(o,!0);U.currentNode=i;let s=U.nextNode(),l=0,a=0,c=n[0];for(;c!==void 0;){if(l===c.index){let p;c.type===2?p=new Y(s,s.nextSibling,this,e):c.type===1?p=new c.ctor(s,c.name,c.strings,this,e):c.type===6&&(p=new Ft(s,this,e)),this._$AV.push(p),c=n[++a]}l!==(c==null?void 0:c.index)&&(s=U.nextNode(),l++)}return U.currentNode=j,i}v(e){let t=0;for(const o of this._$AV)o!==void 0&&(o.strings!==void 0?(o._$AI(e,o,t),t+=o.strings.length-2):o._$AI(e[t])),t++}}class Y{constructor(e,t,o,n){var i;this.type=2,this._$AH=_,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=o,this.options=n,this._$Cp=(i=n==null?void 0:n.isConnected)===null||i===void 0||i}get _$AU(){var e,t;return(t=(e=this._$AM)===null||e===void 0?void 0:e._$AU)!==null&&t!==void 0?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=B(this,e,t),W(e)?e===_||e==null||e===""?(this._$AH!==_&&this._$AR(),this._$AH=_):e!==this._$AH&&e!==M&&this._(e):e._$litType$!==void 0?this.g(e):e.nodeType!==void 0?this.$(e):Mt(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==_&&W(this._$AH)?this._$AA.nextSibling.data=e:this.$(j.createTextNode(e)),this._$AH=e}g(e){var t;const{values:o,_$litType$:n}=e,i=typeof n=="number"?this._$AC(e):(n.el===void 0&&(n.el=X.createElement(n.h,this.options)),n);if(((t=this._$AH)===null||t===void 0?void 0:t._$AD)===i)this._$AH.v(o);else{const s=new Dt(i,this),l=s.u(this.options);s.v(o),this.$(l),this._$AH=s}}_$AC(e){let t=qe.get(e.strings);return t===void 0&&qe.set(e.strings,t=new X(e)),t}T(e){it(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let o,n=0;for(const i of e)n===t.length?t.push(o=new Y(this.k(K()),this.k(K()),this,this.options)):o=t[n],o._$AI(i),n++;n<t.length&&(this._$AR(o&&o._$AB.nextSibling,n),t.length=n)}_$AR(e=this._$AA.nextSibling,t){var o;for((o=this._$AP)===null||o===void 0||o.call(this,!1,!0,t);e&&e!==this._$AB;){const n=e.nextSibling;e.remove(),e=n}}setConnected(e){var t;this._$AM===void 0&&(this._$Cp=e,(t=this._$AP)===null||t===void 0||t.call(this,e))}}class ue{constructor(e,t,o,n,i){this.type=1,this._$AH=_,this._$AN=void 0,this.element=e,this.name=t,this._$AM=n,this.options=i,o.length>2||o[0]!==""||o[1]!==""?(this._$AH=Array(o.length-1).fill(new String),this.strings=o):this._$AH=_}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,t=this,o,n){const i=this.strings;let s=!1;if(i===void 0)e=B(this,e,t,0),s=!W(e)||e!==this._$AH&&e!==M,s&&(this._$AH=e);else{const l=e;let a,c;for(e=i[0],a=0;a<i.length-1;a++)c=B(this,l[o+a],t,a),c===M&&(c=this._$AH[a]),s||(s=!W(c)||c!==this._$AH[a]),c===_?e=_:e!==_&&(e+=(c??"")+i[a+1]),this._$AH[a]=c}s&&!n&&this.j(e)}j(e){e===_?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class Ht extends ue{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===_?void 0:e}}const Bt=H?H.emptyScript:"";class Vt extends ue{constructor(){super(...arguments),this.type=4}j(e){e&&e!==_?this.element.setAttribute(this.name,Bt):this.element.removeAttribute(this.name)}}class qt extends ue{constructor(e,t,o,n,i){super(e,t,o,n,i),this.type=5}_$AI(e,t=this){var o;if((e=(o=B(this,e,t,0))!==null&&o!==void 0?o:_)===M)return;const n=this._$AH,i=e===_&&n!==_||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,s=e!==_&&(n===_||i);i&&this.element.removeEventListener(this.name,this,n),s&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t,o;typeof this._$AH=="function"?this._$AH.call((o=(t=this.options)===null||t===void 0?void 0:t.host)!==null&&o!==void 0?o:this.element,e):this._$AH.handleEvent(e)}}class Ft{constructor(e,t,o){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=o}get _$AU(){return this._$AM._$AU}_$AI(e){B(this,e)}}const Fe=ne.litHtmlPolyfillSupport;Fe==null||Fe(X,Y),((me=ne.litHtmlVersions)!==null&&me!==void 0?me:ne.litHtmlVersions=[]).push("2.7.4");const Kt=(r,e,t)=>{var o,n;const i=(o=t==null?void 0:t.renderBefore)!==null&&o!==void 0?o:e;let s=i._$litPart$;if(s===void 0){const l=(n=t==null?void 0:t.renderBefore)!==null&&n!==void 0?n:null;i._$litPart$=s=new Y(e.insertBefore(K(),l),l,void 0,t??{})}return s._$AI(r),s};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var _e,ye;class $ extends D{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,t;const o=super.createRenderRoot();return(e=(t=this.renderOptions).renderBefore)!==null&&e!==void 0||(t.renderBefore=o.firstChild),o}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Kt(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!1)}render(){return M}}$.finalized=!0,$._$litElement$=!0,(_e=globalThis.litElementHydrateSupport)===null||_e===void 0||_e.call(globalThis,{LitElement:$});const Ke=globalThis.litElementPolyfillSupport;Ke==null||Ke({LitElement:$});((ye=globalThis.litElementVersions)!==null&&ye!==void 0?ye:globalThis.litElementVersions=[]).push("3.3.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const T=r=>e=>typeof e=="function"?((t,o)=>(customElements.define(t,o),o))(r,e):((t,o)=>{const{kind:n,elements:i}=o;return{kind:n,elements:i,finisher(s){customElements.define(t,s)}}})(r,e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Wt=(r,e)=>e.kind==="method"&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(t){t.createProperty(e.key,r)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){typeof e.initializer=="function"&&(this[e.key]=e.initializer.call(this))},finisher(t){t.createProperty(e.key,r)}};function N(r){return(e,t)=>t!==void 0?((o,n,i)=>{n.constructor.createProperty(i,o)})(r,e,t):Wt(r,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Xt(r){return N({...r,state:!0})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const at=({finisher:r,descriptor:e})=>(t,o)=>{var n;if(o===void 0){const i=(n=t.originalKey)!==null&&n!==void 0?n:t.key,s=e!=null?{kind:"method",placement:"prototype",key:i,descriptor:e(t.key)}:{...t,key:i};return r!=null&&(s.finisher=function(l){r(l,i)}),s}{const i=t.constructor;e!==void 0&&Object.defineProperty(t,o,e(o)),r==null||r(i,o)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Qt(r,e){return at({descriptor:t=>{const o={get(){var n,i;return(i=(n=this.renderRoot)===null||n===void 0?void 0:n.querySelector(r))!==null&&i!==void 0?i:null},enumerable:!0,configurable:!0};if(e){const n=typeof t=="symbol"?Symbol():"__"+t;o.get=function(){var i,s;return this[n]===void 0&&(this[n]=(s=(i=this.renderRoot)===null||i===void 0?void 0:i.querySelector(r))!==null&&s!==void 0?s:null),this[n]}}return o}})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Yt(r){return at({descriptor:e=>({get(){var t,o;return(o=(t=this.renderRoot)===null||t===void 0?void 0:t.querySelectorAll(r))!==null&&o!==void 0?o:[]},enumerable:!0,configurable:!0})})}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var we;((we=window.HTMLSlotElement)===null||we===void 0?void 0:we.prototype.assignedElements)!=null;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Jt=r=>typeof r!="string"&&"strTag"in r,lt=(r,e,t)=>{let o=r[0];for(let n=1;n<r.length;n++)o+=e[t?t[n-1]:n-1],o+=r[n];return o};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ct=r=>Jt(r)?lt(r.strings,r.values):r;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ce="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Gt{constructor(e){this.__litLocalizeEventHandler=t=>{t.detail.status==="ready"&&this.host.requestUpdate()},this.host=e}hostConnected(){window.addEventListener(Ce,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(Ce,this.__litLocalizeEventHandler)}}const Zt=r=>r.addController(new Gt(r)),dt=Zt;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const er=()=>r=>typeof r=="function"?rr(r):tr(r),O=er,tr=({kind:r,elements:e})=>({kind:r,elements:e,finisher(t){t.addInitializer(dt)}}),rr=r=>(r.addInitializer(dt),r);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class ht{constructor(){this.settled=!1,this.promise=new Promise((e,t)=>{this._resolve=e,this._reject=t})}resolve(e){this.settled=!0,this._resolve(e)}reject(e){this.settled=!0,this._reject(e)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */const x=[];for(let r=0;r<256;r++)x[r]=(r>>4&15).toString(16)+(r&15).toString(16);function nr(r){let e=0,t=8997,o=0,n=33826,i=0,s=40164,l=0,a=52210;for(let c=0;c<r.length;c++)t^=r.charCodeAt(c),e=t*435,o=n*435,i=s*435,l=a*435,i+=t<<8,l+=n<<8,o+=e>>>16,t=e&65535,i+=o>>>16,n=o&65535,a=l+(i>>>16)&65535,s=i&65535;return x[a>>8]+x[a&255]+x[s>>8]+x[s&255]+x[n>>8]+x[n&255]+x[t>>8]+x[t&255]}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const or="",ir="h",sr="s";function ar(r,e){return(e?ir:sr)+nr(typeof r=="string"?r:r.join(or))}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const We=new WeakMap,Xe=new Map;function lr(r,e,t){var o;if(r){const n=(o=t==null?void 0:t.id)!==null&&o!==void 0?o:cr(e),i=r[n];if(i){if(typeof i=="string")return i;if("strTag"in i)return lt(i.strings,e.values,i.values);{let s=We.get(i);return s===void 0&&(s=i.values,We.set(i,s)),{...i,values:s.map(l=>e.values[l])}}}}return ct(e)}function cr(r){const e=typeof r=="string"?r:r.strings;let t=Xe.get(e);return t===void 0&&(t=ar(e,typeof r!="string"&&!("strTag"in r)),Xe.set(e,t)),t}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ke(r){window.dispatchEvent(new CustomEvent(Ce,{detail:r}))}let oe="",F,ut,ie,Se,pt,R=new ht;R.resolve();let Z=0;const dr=r=>(pr((e,t)=>lr(pt,e,t)),oe=ut=r.sourceLocale,ie=new Set(r.targetLocales),ie.add(r.sourceLocale),Se=r.loadLocale,{getLocale:hr,setLocale:ur}),hr=()=>oe,ur=r=>{if(r===(F??oe))return R.promise;if(!ie||!Se)throw new Error("Internal error");if(!ie.has(r))throw new Error("Invalid locale code");Z++;const e=Z;return F=r,R.settled&&(R=new ht),ke({status:"loading",loadingLocale:r}),(r===ut?Promise.resolve({templates:void 0}):Se(r)).then(o=>{Z===e&&(oe=r,F=void 0,pt=o.templates,ke({status:"ready",readyLocale:r}),R.resolve())},o=>{Z===e&&(ke({status:"error",errorLocale:r,errorMessage:o.toString()}),R.reject(o))}),R.promise};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let k=ct,Qe=!1;function pr(r){if(Qe)throw new Error("lit-localize can only be configured once");k=r,Qe=!0}const ft=A`
  /* Brand Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm1) */
  --bkd-brand-white: rgba(255, 255, 255, 0.42);
  --bkd-brand-red: rgba(234, 22, 31, 1);
  --bkd-brand-black: rgba(0, 0, 0, 1);
  --bkd-brand-light-sand: rgba(252, 248, 243, 1);
  --bkd-brand-sand: rgba(250, 241, 227, 1);
  --bkd-brand-dark-sand: rgba(247, 233, 210, 1);
  --bkd-brand-sand-hover: rgba(242, 224, 195, 1);
  --bkd-brand-cappuchino: rgba(235, 211, 174, 1);

  /* Functional Foreground Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-fg-black: rgba(0, 0, 0, 1);
  --bkd-func-fg-grey: rgba(112, 112, 112, 1);
  --bkd-func-fg-light-grey: rgba(112, 112, 112, 0.68);
  --bkd-func-fg-white: rgba(255, 255, 255, 1);

  /* Functional Background Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-bg-anthrazit-hover: rgba(64, 64, 64, 1);
  --bkd-func-bg-anthrazit: rgba(78, 78, 78, 0.95);
  --bkd-func-bg-dark-grey: rgba(112, 112, 112, 1);
  --bkd-func-bg-line-grey: rgba(112, 112, 112, 0.5);
  --bkd-func-bg-grey: rgba(222, 222, 222, 1);
  --bkd-func-bg-light-grey: rgba(242, 242, 242, 1);
  --bkd-func-bg-very-light-grey: rgba(248, 248, 248, 1);
  --bkd-func-bg-white: rgba(255, 255, 255, 1);
  --bkd-func-bg-red: rgba(208, 16, 24, 1);
  --bkd-func-bg-green: rgba(61, 134, 8, 1);

  /* Component-specific Colors */
  --bkd-language-switcher-active-border: rgba(234, 22, 31, 0.77);
  --bkd-footer-border: rgba(238, 238, 238, 1);

  /* Dropdowns */
  --bkd-z-index-dropdown: 1;

  /* Fonts */
  --bkd-font-family: "Roboto", sans-serif;
  --bkd-font-size-base: 16px;
  --bkd-font-weight-base: 300;
  --bkd-line-height-base: 1.625;

  /* Spacings */
  --bkd-margin-horizontal-large: 40px;
  --bkd-margin-horizontal-medium: 30px;
  --bkd-margin-horizontal-small: 20px;
`,fr=A`
  /* See https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm3 */

  /* Thin */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 100;
    src: url("/fonts/roboto-v30-latin-ext_latin-100.woff") format("woff");
  }

  /* Light */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 300;
    src: url("/fonts/roboto-v30-latin-ext_latin-300.woff") format("woff");
  }

  /* Regular */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: url("/fonts/roboto-v30-latin-ext_latin-400.woff") format("woff");
  }

  /* Medium */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: url("/fonts/roboto-v30-latin-ext_latin-500.woff") format("woff");
  }

  /* Bold */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: url("/fonts/roboto-v30-latin-ext_latin-700.woff") format("woff");
  }
`,P=A`
  :host {
    ${ft}
    ${fr}
  }

  /* Reset */
  * {
    box-sizing: border-box;

    font-family: var(--bkd-font-family);
    font-size: var(--bkd-font-size-base);
    font-weight: var(--bkd-font-weight-base);
    line-height: var(--bkd-line-height-base);

    font-synthesis: none;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
  }
  img,
  svg {
    display: block;
  }
`;function gr(r){var t;const e=document.createElement("style");e.innerText=r,(t=document.querySelector("body"))==null||t.appendChild(e)}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function*vr(r,e){if(r!==void 0){let t=0;for(const o of r)yield e(o,t++)}}const Q={oauth:{server:"https://eventoapp-test.erz.be.ch",clientId:"dev3000"},apps:[{key:"schulverwaltung",scope:"Tutoring"},{key:"anmeldedetailsEinlesen",scope:"NG"},{key:"schulleiterPersonen",scope:"NG"},{key:"kursausschreibung",scope:"Public"},{key:"stellvertretung",scope:"Tutoring"},{key:"reservation",scope:"NG"}]};var mr=Object.defineProperty,br=Object.getOwnPropertyDescriptor,_r=(r,e,t,o)=>{for(var n=o>1?void 0:o?br(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&mr(e,t,n),n};let xe=class extends ${handleAppClick(r,e){r.preventDefault();const t=new URL(location.href);t.searchParams.set("app",e.key),history.pushState({},"",t),window.dispatchEvent(new PopStateEvent("popstate",{state:e,bubbles:!0}))}renderAppLink(r){return y` <li>
      <a href="#" @click=${e=>this.handleAppClick(e,r)}>
        ${r.key} (${r.scope})
      </a>
    </li>`}render(){return y`
      <main>
        <p>${k("Willkommen bei Evento")}</p>
        <ul>
          ${vr(Q.apps,this.renderAppLink.bind(this))}
        </ul>
      </main>
    `}};xe.styles=[P,A`
      /* Large screen */

      :host {
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        margin: 0 var(--bkd-header-margin-horizontal);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];xe=_r([T("bkd-content"),O()],xe);var yr=Object.defineProperty,wr=Object.getOwnPropertyDescriptor,gt=(r,e,t,o)=>{for(var n=o>1?void 0:o?wr(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&yr(e,t,n),n};let se=class extends ${constructor(){super(...arguments),this.currentLocale="de"}render(){return y`
      <footer>
        <div class="copyright">${k("© Bildungs- und Kulturdirektion")}</div>
        <div class="footer-nav">
          <a
            href=${`https://www.bkd.be.ch/${this.currentLocale}/tools/rechtliches.html`}
            target="_blank"
            >${k("Rechtliche Hinweise")}</a
          >
          <a
            href=${`https://www.bkd.be.ch/${this.currentLocale}/tools/impressum.html`}
            target="_blank"
            >${k("Impressum")}</a
          >
        </div>
      </footer>
    `}};se.styles=[P,A`
      /* Large screen */

      :host {
        --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-large);
        --bkd-footer-padding-vertical: 18px;

        padding: var(--bkd-footer-padding-vertical)
          var(--bkd-footer-padding-horizontal);
        border-top: 1px solid var(--bkd-footer-border);
        background-color: var(--bkd-brand-light-sand);
        color: var(--bkd-func-fg-black);
      }

      footer {
        display: flex;
        justify-content: space-between;
      }

      .copyright {
        font-size: 0.8125rem;
        font-weight: 300;
        letter-spacing: 0.02rem;
        word-spacing: 0.05rem;
      }

      .footer-nav {
        display: flex;
        gap: 2.5rem;
      }

      a {
        font-size: 0.875rem;
        font-weight: 400;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        line-height: 1.5;
        color: var(--bkd-func-fg-black);
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-medium);
        }

        footer {
          flex-direction: column-reverse;
          gap: 2.25rem;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];gt([N()],se.prototype,"currentLocale",2);se=gt([T("bkd-footer"),O()],se);var kr=Object.defineProperty,$r=Object.getOwnPropertyDescriptor,vt=(r,e,t,o)=>{for(var n=o>1?void 0:o?$r(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&kr(e,t,n),n};let ae=class extends ${constructor(){super(),this.currentLocale="de"}render(){const r="Berufsbildungszentrum IDM Thun",e=`${k("Evento")} | ${r}`;return y`
      <header>
        <bkd-service-nav currentLocale=${this.currentLocale}></bkd-service-nav>
        <img class="logo" src="logo.svg" alt=${k("Evento Startseite")} />
        <div class="logo-caption">${e}</div>
        <bkd-main-nav></bkd-main-nav>
      </header>
    `}};ae.styles=[P,A`
      /* Large screen */

      :host {
        --bkd-header-margin-top: 12px;
        --bkd-header-margin-bottom: calc(2 * var(--bkd-header-margin-top));
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        padding: var(--bkd-header-margin-top)
          var(--bkd-header-margin-horizontal) var(--bkd-header-margin-bottom)
          var(--bkd-header-margin-horizontal);
        border-bottom: 1px solid var(--bkd-func-bg-grey);
      }

      header {
        display: grid;
        grid-template-columns: max-content auto;
        grid-template-areas:
          "service-nav service-nav"
          "logo ."
          "logo-caption main-nav";
      }

      bkd-service-nav {
        grid-area: service-nav;
        justify-self: end;
      }

      .logo {
        grid-area: logo;
        width: 150px;
        font-size: 1rem;
        line-height: 1rem;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        font-weight: 500;
        color: var(--bkd-func-fg-black);
      }

      .logo-caption {
        grid-area: logo-caption;
        align-self: baseline;
      }

      bkd-main-nav {
        grid-area: main-nav;
        align-self: baseline;
        justify-self: end;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }

        header {
          grid-template-areas:
            "logo service-nav"
            "logo-caption logo-caption";
        }

        bkd-service-nav {
          align-self: center;
        }

        .logo {
          width: 110px;
        }

        .logo-caption {
          margin-top: 12px;
          font-size: 0.75rem;
          line-height: 0.75rem;
        }

        bkd-main-nav {
          display: none;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }

        bkd-service-nav {
          align-self: start;
          margin-top: 2px; /* Align with logo text */
        }
      }
    `];vt([N()],ae.prototype,"currentLocale",2);ae=vt([T("bkd-header"),O()],ae);var Ar=Object.defineProperty,Er=Object.getOwnPropertyDescriptor,mt=(r,e,t,o)=>{for(var n=o>1?void 0:o?Er(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&Ar(e,t,n),n};let le=class extends ${constructor(){super(...arguments),this.open=!1}render(){const r=this.open?"/icons/close.svg":"/icons/hamburger.svg";return y`
      <button
        class="hamburger"
        aria-expanded=${this.open}
        aria-label=${k("Menü")}
      >
        <img src=${r} alt="Hamburger" width="32" height="32" />
      </button>
    `}};le.styles=[P,A`
      :host {
        display: flex;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }
    `];mt([N()],le.prototype,"open",2);le=mt([T("bkd-hamburger"),O()],le);const Cr="de",Sr=["fr"],xr=["de","fr"];/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Tr={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Or=r=>(...e)=>({_$litDirective$:r,values:e});class Pr{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,o){this._$Ct=e,this._$AM=t,this._$Ci=o}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Lr=Or(class extends Pr{constructor(r){var e;if(super(r),r.type!==Tr.ATTRIBUTE||r.name!=="class"||((e=r.strings)===null||e===void 0?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(r){return" "+Object.keys(r).filter(e=>r[e]).join(" ")+" "}update(r,[e]){var t,o;if(this.it===void 0){this.it=new Set,r.strings!==void 0&&(this.nt=new Set(r.strings.join(" ").split(/\s/).filter(i=>i!=="")));for(const i in e)e[i]&&!(!((t=this.nt)===null||t===void 0)&&t.has(i))&&this.it.add(i);return this.render(e)}const n=r.element.classList;this.it.forEach(i=>{i in e||(n.remove(i),this.it.delete(i))});for(const i in e){const s=!!e[i];s===this.it.has(i)||!((o=this.nt)===null||o===void 0)&&o.has(i)||(s?(n.add(i),this.it.add(i)):(n.remove(i),this.it.delete(i)))}return M}});var zr=Object.defineProperty,Rr=Object.getOwnPropertyDescriptor,bt=(r,e,t,o)=>{for(var n=o>1?void 0:o?Rr(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&zr(e,t,n),n};let ce=class extends ${constructor(){super(...arguments),this.currentLocale="de"}handleLocaleChange(r,e){r.preventDefault(),this.dispatchEvent(new CustomEvent("bkdlocalechange",{bubbles:!0,composed:!0,detail:{locale:e}}))}render(){return y`<ul>
      ${xr.map(r=>y`<li>
            <a
              href="#"
              class=${Lr({active:r===this.currentLocale})}
              aria-current=${r===this.currentLocale}
              @click=${e=>this.handleLocaleChange(e,r)}
            >
              ${r}
            </a>
          </li>`)}
    </ul>`}};ce.styles=[P,A`
      :host {
        font-size: 0.875rem;
      }

      ul {
        display: flex;
        align-items: baseline;
        margin: 0;
        padding: 0;
        list-style: none;
      }

      li {
        display: flex;
        align-items: baseline;
        margin-left: 0.75rem;
      }

      li + li:before {
        content: "|";
        margin-right: 0.75rem;
      }

      a {
        display: block;
        letter-spacing: 0.025rem;
        text-decoration: none;
        text-transform: uppercase;
        color: var(--bkd-func-fg-black);
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a.active {
        border-bottom: 2px solid var(--bkd-language-switcher-active-border);
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      a.active:hover::after,
      a.active:focus::after,
      a.active:active::after {
        transform: scaleX(0);
      }
    `];bt([N()],ce.prototype,"currentLocale",2);ce=bt([T("bkd-language-switcher"),O()],ce);var Ur=Object.defineProperty,jr=Object.getOwnPropertyDescriptor,J=(r,e,t,o)=>{for(var n=o>1?void 0:o?jr(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&Ur(e,t,n),n};let I=class extends ${constructor(){super(...arguments),this.currentLocale="de",this.open=!1,this.handleClick=r=>{const e=r.composedPath()[0];e!==this.menuButton&&!this.menuButton.contains(e)&&this.open&&this.toggle()},this.handleKeydown=r=>{switch(r.key){case"Escape":this.toggle();break;case"ArrowDown":const e=this.nextLinkIndex(1);this.menuLinks[e].focus();break;case"ArrowUp":const t=this.nextLinkIndex(-1);this.menuLinks[t].focus();break}}}renderProfile(){return y`<a role="menuitem" href="#">${k("Mein Profil")}</a>`}renderSettings(){return y`<a role="menuitem" href="#">${k("Einstellungen")}</a>`}renderVideos(){const r=this.currentLocale==="de"?"PLLDtLiOuctbx-_EQWgWqTO1MRbX845OEf":"PLLDtLiOuctbyEegnquAkaW4u8cm62lFAU";return y`<a
      role="menuitem"
      href=${`https://www.youtube.com/playlist?list=${r}`}
      target="_blank"
      ><img src="/icons/external-link.svg" alt="" width="24" height="24" />
      ${k("Video-Tutorials")}</a
    >`}renderLogout(){return y`<a role="menuitem" href="#"
      ><img src="/icons/logout.svg" alt="" width="24" height="24" />${k("Logout")}</a
    >`}render(){return y`
      <button
        type="button"
        @click=${()=>this.toggle()}
        aria-label=${k("Menü Benutzereinstellungen")}
        aria-expanded=${this.open}
        aria-haspopup="menu"
      >
        <img src="/icons/settings.svg" alt="" width="32" height="32" />
      </button>
      <ul id="menu" role="menu" ?hidden=${!this.open}>
        <li role="presentation">${this.renderProfile()}</li>
        <li role="presentation">${this.renderSettings()}</li>
        <li role="presentation">${this.renderVideos()}</li>
        <li role="presentation">${this.renderLogout()}</li>
      </ul>
    `}toggle(){this.open=!this.open,this.open?(document.addEventListener("keydown",this.handleKeydown),document.addEventListener("click",this.handleClick)):(document.removeEventListener("keydown",this.handleKeydown),document.removeEventListener("click",this.handleClick))}activeLinkIndex(){var t;const r=(t=this.shadowRoot)==null?void 0:t.activeElement,e=[...this.menuLinks].indexOf(r);return e===-1?null:e}nextLinkIndex(r){const e=this.activeLinkIndex(),t=0,o=this.menuLinks.length-1;if(e===null)return r>0?t:o;const n=e+r;return n>o?t:n<t?o:n}};I.styles=[P,A`
      :host {
        display: flex;
        position: relative;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }

      ul {
        position: absolute;
        right: 0;
        border: 1px solid var(--bkd-func-bg-grey);
        list-style-type: none;
        padding: 0.625rem 0;
        margin-top: calc(32px + 0.5rem);
        background: var(--bkd-func-bg-white);
        z-index: var(--bkd-z-index-dropdown);
        min-width: 12rem;
      }

      a {
        font-size: 0.875rem;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        font-style: normal;
        font-weight: 400;
        line-height: 2.5;
        padding: 0 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        height: 100%;
        width: 100%;
        text-decoration: none;
        color: var(--bkd-func-fg-black);
      }

      a img {
        margin-left: -5.25px;
      }

      a:hover {
        color: var(--bkd-brand-red);
        background: var(--bkd-brand-light-sand);
        border-left: 6px solid var(--bkd-brand-red);
        font-weight: 700;
        padding: 0 calc(1.5rem - 6px);
      }
    `];J([N()],I.prototype,"currentLocale",2);J([Xt()],I.prototype,"open",2);J([Qt("button")],I.prototype,"menuButton",2);J([Yt("a")],I.prototype,"menuLinks",2);I=J([T("bkd-user-settings"),O()],I);var Mr=Object.defineProperty,Ir=Object.getOwnPropertyDescriptor,Nr=(r,e,t,o)=>{for(var n=o>1?void 0:o?Ir(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&Mr(e,t,n),n};let Te=class extends ${render(){return y` <span style="font-size: 2rem">main nav</span> `}};Te.styles=[P,A`
      :host {
        background-color: salmon;
      }
    `];Te=Nr([T("bkd-main-nav"),O()],Te);var Dr=Object.defineProperty,Hr=Object.getOwnPropertyDescriptor,_t=(r,e,t,o)=>{for(var n=o>1?void 0:o?Hr(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&Dr(e,t,n),n};let de=class extends ${constructor(){super(...arguments),this.currentLocale="de"}render(){return y`
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <bkd-user-settings
        currentLocale=${this.currentLocale}
      ></bkd-user-settings>
      <bkd-language-switcher
        currentLocale=${this.currentLocale}
      ></bkd-language-switcher>
      <bkd-hamburger></bkd-hamburger>
    `}};de.styles=[P,A`
      /* Large screen */

      :host {
        display: flex;
        align-items: center;
        gap: 2.5rem;
        margin-left: 1rem;
      }

      bkd-hamburger {
        display: none;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        bkd-user-settings {
          display: none;
        }

        bkd-language-switcher {
          display: none;
        }

        bkd-hamburger {
          display: inherit;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          gap: 1.5rem;
        }
      }
    `];_t([N()],de.prototype,"currentLocale",2);de=_t([T("bkd-service-nav"),O()],de);const Br="modulepreload",Vr=function(r){return"/"+r},Ye={},qr=function(e,t,o){if(!t||t.length===0)return e();const n=document.getElementsByTagName("link");return Promise.all(t.map(i=>{if(i=Vr(i),i in Ye)return;Ye[i]=!0;const s=i.endsWith(".css"),l=s?'[rel="stylesheet"]':"";if(!!o)for(let p=n.length-1;p>=0;p--){const d=n[p];if(d.href===i&&(!s||d.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${i}"]${l}`))return;const c=document.createElement("link");if(c.rel=s?"stylesheet":Br,s||(c.as="script",c.crossOrigin=""),c.href=i,document.head.appendChild(c),s)return new Promise((p,d)=>{c.addEventListener("load",p),c.addEventListener("error",()=>d(new Error(`Unable to preload CSS for ${i}`)))})})).then(()=>e())};function Fr(r){if(r.__esModule)return r;var e=r.default;if(typeof e=="function"){var t=function o(){if(this instanceof o){var n=[null];n.push.apply(n,arguments);var i=Function.bind.apply(e,n);return new i}return e.apply(this,arguments)};t.prototype=e.prototype}else t={};return Object.defineProperty(t,"__esModule",{value:!0}),Object.keys(r).forEach(function(o){var n=Object.getOwnPropertyDescriptor(r,o);Object.defineProperty(t,o,n.get?n:{enumerable:!0,get:function(){return r[o]}})}),t}var yt={exports:{}};(function(r,e){(function(t,o){r.exports=o()})(self,()=>(()=>{var t={934:(s,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.generateQueryString=l.tokenResponseToOAuth2Token=l.OAuth2Client=void 0;const c=a(443),p=a(618);function d(f,h){return new URL(f,h).toString()}function u(f){return f.then(h=>{var g;return{accessToken:h.access_token,expiresAt:h.expires_in?Date.now()+1e3*h.expires_in:null,refreshToken:(g=h.refresh_token)!==null&&g!==void 0?g:null}})}function v(f){return new URLSearchParams(Object.fromEntries(Object.entries(f).filter(([h,g])=>g!==void 0))).toString()}l.OAuth2Client=class{constructor(f){this.discoveryDone=!1,this.serverMetadata=null,f!=null&&f.fetch||(f.fetch=fetch),this.settings=f}async refreshToken(f){if(!f.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const h={grant_type:"refresh_token",refresh_token:f.refreshToken};return this.settings.clientSecret||(h.client_id=this.settings.clientId),u(this.request("tokenEndpoint",h))}async clientCredentials(f){var h;const g=["client_id","client_secret","grant_type","scope"];if(f!=null&&f.extraParams&&Object.keys(f.extraParams).filter(m=>g.includes(m)).length>0)throw new Error(`The following extraParams are disallowed: '${g.join("', '")}'`);const b={grant_type:"client_credentials",scope:(h=f==null?void 0:f.scope)===null||h===void 0?void 0:h.join(" "),...f==null?void 0:f.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return u(this.request("tokenEndpoint",b))}async password(f){var h;const g={grant_type:"password",...f,scope:(h=f.scope)===null||h===void 0?void 0:h.join(" ")};return u(this.request("tokenEndpoint",g))}get authorizationCode(){return new p.OAuth2AuthorizationCodeClient(this)}async introspect(f){const h={token:f.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",h)}async getEndpoint(f){if(this.settings[f]!==void 0)return d(this.settings[f],this.settings.server);if(f!=="discoveryEndpoint"&&(await this.discover(),this.settings[f]!==void 0))return d(this.settings[f],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${f}. Either specify ${f} in the settings, or the "server" endpoint to let the client discover it.`);switch(f){case"authorizationEndpoint":return d("/authorize",this.settings.server);case"tokenEndpoint":return d("/token",this.settings.server);case"discoveryEndpoint":return d("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return d("/introspect",this.settings.server)}}async discover(){var f;if(this.discoveryDone)return;let h;this.discoveryDone=!0;try{h=await this.getEndpoint("discoveryEndpoint")}catch{return void console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint')}const g=await this.settings.fetch(h,{headers:{Accept:"application/json"}});if(!g.ok)return;if(!(!((f=g.headers.get("Content-Type"))===null||f===void 0)&&f.startsWith("application/json")))return void console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");this.serverMetadata=await g.json();const b=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[m,w]of b)this.serverMetadata[m]&&(this.settings[w]=d(this.serverMetadata[m],h));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(f,h){const g=await this.getEndpoint(f),b={"Content-Type":"application/x-www-form-urlencoded"};let m=this.settings.authenticationMethod;switch(m||(m=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),m){case"client_secret_basic":b.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":h.client_id=this.settings.clientId,this.settings.clientSecret&&(h.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+m+". Open a feature request if you want this!")}const w=await this.settings.fetch(g,{method:"POST",body:v(h),headers:b});if(w.ok)return await w.json();let E,V,fe;throw w.headers.has("Content-Type")&&w.headers.get("Content-Type").startsWith("application/json")&&(E=await w.json()),E!=null&&E.error?(V="OAuth2 error "+E.error+".",E.error_description&&(V+=" "+E.error_description),fe=E.error):(V="HTTP Error "+w.status+" "+w.statusText,w.status===401&&this.settings.clientSecret&&(V+=". It's likely that the clientId and/or clientSecret was incorrect"),fe=null),new c.OAuth2Error(V,fe,w.status)}},l.tokenResponseToOAuth2Token=u,l.generateQueryString=v},618:(s,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.getCodeChallenge=l.generateCodeVerifier=l.OAuth2AuthorizationCodeClient=void 0;const c=a(934),p=a(443);async function d(h){const g=u();if(g!=null&&g.subtle)return["S256",f(await g.subtle.digest("SHA-256",v(h)))];{const b=a(212).createHash("sha256");return b.update(v(h)),["S256",b.digest("base64url")]}}function u(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const h=a(212);return h.webcrypto?h.webcrypto:null}function v(h){const g=new Uint8Array(h.length);for(let b=0;b<h.length;b++)g[b]=255&h.charCodeAt(b);return g}function f(h){return btoa(String.fromCharCode(...new Uint8Array(h))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}l.OAuth2AuthorizationCodeClient=class{constructor(h){this.client=h}async getAuthorizeUri(h){const[g,b]=await Promise.all([h.codeVerifier?d(h.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),m={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:h.redirectUri,code_challenge_method:g==null?void 0:g[0],code_challenge:g==null?void 0:g[1]};return h.state&&(m.state=h.state),h.scope&&(m.scope=h.scope.join(" ")),b+"?"+(0,c.generateQueryString)(m)}async getTokenFromCodeRedirect(h,g){const{code:b}=await this.validateResponse(h,{state:g.state});return this.getToken({code:b,redirectUri:g.redirectUri,codeVerifier:g.codeVerifier})}async validateResponse(h,g){var b;const m=new URL(h).searchParams;if(m.has("error"))throw new p.OAuth2Error((b=m.get("error_description"))!==null&&b!==void 0?b:"OAuth2 error",m.get("error"),0);if(!m.has("code"))throw new Error(`The url did not contain a code parameter ${h}`);if(g.state&&g.state!==m.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${g.state}`);return{code:m.get("code"),scope:m.has("scope")?m.get("scope").split(" "):void 0}}async getToken(h){const g={grant_type:"authorization_code",code:h.code,redirect_uri:h.redirectUri,code_verifier:h.codeVerifier};return(0,c.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",g))}},l.generateCodeVerifier=async function(){const h=u();if(h){const g=new Uint8Array(32);return h.getRandomValues(g),f(g)}{const g=a(212);return new Promise((b,m)=>{g.randomBytes(32,(w,E)=>{w&&m(w),b(E.toString("base64url"))})})}},l.getCodeChallenge=d},443:(s,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Error=void 0;class a extends Error{constructor(p,d,u){super(p),this.oauth2Code=d,this.httpCode=u}}l.OAuth2Error=a},13:(s,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Fetch=void 0,l.OAuth2Fetch=class{constructor(a){this.token=null,this.activeRefresh=null,this.refreshTimer=null,(a==null?void 0:a.scheduleRefresh)===void 0&&(a.scheduleRefresh=!0),this.options=a,a.getStoredToken&&(async()=>this.token=await a.getStoredToken())(),this.scheduleRefresh()}async fetch(a,c){const p=new Request(a,c);return this.mw()(p,d=>fetch(d))}mw(){return async(a,c)=>{const p=await this.getAccessToken();let d=a.clone();d.headers.set("Authorization","Bearer "+p);let u=await c(d);if(!u.ok&&u.status===401){const v=await this.refreshToken();d=a.clone(),d.headers.set("Authorization","Bearer "+v.accessToken),u=await c(d)}return u}}async getToken(){return this.token&&(this.token.expiresAt===null||this.token.expiresAt>Date.now())?this.token:this.refreshToken()}async getAccessToken(){return(await this.getToken()).accessToken}async refreshToken(){var a,c;if(this.activeRefresh)return this.activeRefresh;const p=this.token;this.activeRefresh=(async()=>{var d,u;let v=null;try{p!=null&&p.refreshToken&&(v=await this.options.client.refreshToken(p))}catch{console.warn("[oauth2] refresh token not accepted, we'll try reauthenticating")}if(v||(v=await this.options.getNewToken()),!v){const f=new Error("Unableto obtain OAuth2 tokens, a full reauth may be needed");throw(u=(d=this.options).onError)===null||u===void 0||u.call(d,f),f}return v})();try{const d=await this.activeRefresh;return this.token=d,(c=(a=this.options).storeToken)===null||c===void 0||c.call(a,d),this.scheduleRefresh(),d}catch(d){throw this.options.onError&&this.options.onError(d),d}finally{this.activeRefresh=null}}scheduleRefresh(){var a;if(!this.options.scheduleRefresh||(this.refreshTimer&&(clearTimeout(this.refreshTimer),this.refreshTimer=null),!(!((a=this.token)===null||a===void 0)&&a.expiresAt)||!this.token.refreshToken))return;const c=this.token.expiresAt-Date.now();c<12e4||(this.refreshTimer=setTimeout(async()=>{try{await this.refreshToken()}catch(p){console.error("[fetch-mw-oauth2] error while doing a background OAuth2 auto-refresh",p)}},c-6e4))}}},212:()=>{}},o={};function n(s){var l=o[s];if(l!==void 0)return l.exports;var a=o[s]={exports:{}};return t[s](a,a.exports,n),a.exports}var i={};return(()=>{var s=i;Object.defineProperty(s,"__esModule",{value:!0}),s.OAuth2Error=s.OAuth2Fetch=s.generateCodeVerifier=s.OAuth2AuthorizationCodeClient=s.OAuth2Client=void 0;var l=n(934);Object.defineProperty(s,"OAuth2Client",{enumerable:!0,get:function(){return l.OAuth2Client}});var a=n(618);Object.defineProperty(s,"OAuth2AuthorizationCodeClient",{enumerable:!0,get:function(){return a.OAuth2AuthorizationCodeClient}}),Object.defineProperty(s,"generateCodeVerifier",{enumerable:!0,get:function(){return a.generateCodeVerifier}});var c=n(13);Object.defineProperty(s,"OAuth2Fetch",{enumerable:!0,get:function(){return c.OAuth2Fetch}});var p=n(443);Object.defineProperty(s,"OAuth2Error",{enumerable:!0,get:function(){return p.OAuth2Error}})})(),i})())})(yt);var wt=yt.exports,C={},S={},G={};Object.defineProperty(G,"__esModule",{value:!0});G.OAuth2Error=void 0;class Kr extends Error{constructor(e,t,o){super(e),this.oauth2Code=t,this.httpCode=o}}G.OAuth2Error=Kr;var Je;function kt(){if(Je)return S;Je=1,Object.defineProperty(S,"__esModule",{value:!0}),S.generateQueryString=S.tokenResponseToOAuth2Token=S.OAuth2Client=void 0;const r=G,e=$t();class t{constructor(l){this.discoveryDone=!1,this.serverMetadata=null,l!=null&&l.fetch||(l.fetch=fetch),this.settings=l}async refreshToken(l){if(!l.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const a={grant_type:"refresh_token",refresh_token:l.refreshToken};return this.settings.clientSecret||(a.client_id=this.settings.clientId),n(this.request("tokenEndpoint",a))}async clientCredentials(l){var a;const c=["client_id","client_secret","grant_type","scope"];if(l!=null&&l.extraParams&&Object.keys(l.extraParams).filter(d=>c.includes(d)).length>0)throw new Error(`The following extraParams are disallowed: '${c.join("', '")}'`);const p={grant_type:"client_credentials",scope:(a=l==null?void 0:l.scope)===null||a===void 0?void 0:a.join(" "),...l==null?void 0:l.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return n(this.request("tokenEndpoint",p))}async password(l){var a;const c={grant_type:"password",...l,scope:(a=l.scope)===null||a===void 0?void 0:a.join(" ")};return n(this.request("tokenEndpoint",c))}get authorizationCode(){return new e.OAuth2AuthorizationCodeClient(this)}async introspect(l){const a={token:l.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",a)}async getEndpoint(l){if(this.settings[l]!==void 0)return o(this.settings[l],this.settings.server);if(l!=="discoveryEndpoint"&&(await this.discover(),this.settings[l]!==void 0))return o(this.settings[l],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${l}. Either specify ${l} in the settings, or the "server" endpoint to let the client discover it.`);switch(l){case"authorizationEndpoint":return o("/authorize",this.settings.server);case"tokenEndpoint":return o("/token",this.settings.server);case"discoveryEndpoint":return o("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return o("/introspect",this.settings.server)}}async discover(){var l;if(this.discoveryDone)return;this.discoveryDone=!0;let a;try{a=await this.getEndpoint("discoveryEndpoint")}catch{console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint');return}const c=await this.settings.fetch(a,{headers:{Accept:"application/json"}});if(!c.ok)return;if(!(!((l=c.headers.get("Content-Type"))===null||l===void 0)&&l.startsWith("application/json"))){console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");return}this.serverMetadata=await c.json();const p=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[d,u]of p)this.serverMetadata[d]&&(this.settings[u]=o(this.serverMetadata[d],a));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(l,a){const c=await this.getEndpoint(l),p={"Content-Type":"application/x-www-form-urlencoded"};let d=this.settings.authenticationMethod;switch(d||(d=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),d){case"client_secret_basic":p.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":a.client_id=this.settings.clientId,this.settings.clientSecret&&(a.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+d+". Open a feature request if you want this!")}const u=await this.settings.fetch(c,{method:"POST",body:i(a),headers:p});if(u.ok)return await u.json();let v,f,h;throw u.headers.has("Content-Type")&&u.headers.get("Content-Type").startsWith("application/json")&&(v=await u.json()),v!=null&&v.error?(f="OAuth2 error "+v.error+".",v.error_description&&(f+=" "+v.error_description),h=v.error):(f="HTTP Error "+u.status+" "+u.statusText,u.status===401&&this.settings.clientSecret&&(f+=". It's likely that the clientId and/or clientSecret was incorrect"),h=null),new r.OAuth2Error(f,h,u.status)}}S.OAuth2Client=t;function o(s,l){return new URL(s,l).toString()}function n(s){return s.then(l=>{var a;return{accessToken:l.access_token,expiresAt:l.expires_in?Date.now()+l.expires_in*1e3:null,refreshToken:(a=l.refresh_token)!==null&&a!==void 0?a:null}})}S.tokenResponseToOAuth2Token=n;function i(s){return new URLSearchParams(Object.fromEntries(Object.entries(s).filter(([l,a])=>a!==void 0))).toString()}return S.generateQueryString=i,S}const Wr={},Xr=Object.freeze(Object.defineProperty({__proto__:null,default:Wr},Symbol.toStringTag,{value:"Module"})),$e=Fr(Xr);var Ge;function $t(){if(Ge)return C;Ge=1,Object.defineProperty(C,"__esModule",{value:!0}),C.getCodeChallenge=C.generateCodeVerifier=C.OAuth2AuthorizationCodeClient=void 0;const r=kt(),e=G;class t{constructor(c){this.client=c}async getAuthorizeUri(c){const[p,d]=await Promise.all([c.codeVerifier?n(c.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),u={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:c.redirectUri,code_challenge_method:p==null?void 0:p[0],code_challenge:p==null?void 0:p[1]};return c.state&&(u.state=c.state),c.scope&&(u.scope=c.scope.join(" ")),d+"?"+(0,r.generateQueryString)(u)}async getTokenFromCodeRedirect(c,p){const{code:d}=await this.validateResponse(c,{state:p.state});return this.getToken({code:d,redirectUri:p.redirectUri,codeVerifier:p.codeVerifier})}async validateResponse(c,p){var d;const u=new URL(c).searchParams;if(u.has("error"))throw new e.OAuth2Error((d=u.get("error_description"))!==null&&d!==void 0?d:"OAuth2 error",u.get("error"),0);if(!u.has("code"))throw new Error(`The url did not contain a code parameter ${c}`);if(p.state&&p.state!==u.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${p.state}`);return{code:u.get("code"),scope:u.has("scope")?u.get("scope").split(" "):void 0}}async getToken(c){const p={grant_type:"authorization_code",code:c.code,redirect_uri:c.redirectUri,code_verifier:c.codeVerifier};return(0,r.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",p))}}C.OAuth2AuthorizationCodeClient=t;async function o(){const a=i();if(a){const c=new Uint8Array(32);return a.getRandomValues(c),l(c)}else{const c=$e;return new Promise((p,d)=>{c.randomBytes(32,(u,v)=>{u&&d(u),p(v.toString("base64url"))})})}}C.generateCodeVerifier=o;async function n(a){const c=i();if(c!=null&&c.subtle)return["S256",l(await c.subtle.digest("SHA-256",s(a)))];{const d=$e.createHash("sha256");return d.update(s(a)),["S256",d.digest("base64url")]}}C.getCodeChallenge=n;function i(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const a=$e;return a.webcrypto?a.webcrypto:null}function s(a){const c=new Uint8Array(a.length);for(let p=0;p<a.length;p++)c[p]=a.charCodeAt(p)&255;return c}function l(a){return btoa(String.fromCharCode(...new Uint8Array(a))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}return C}var At=$t();kt();const Et="bkdInstance",Oe="bkdCodeVerifier",he="bkdRedirectUrl",Ct="bkdAccessToken",St="bkdRefreshToken",xt="CLX.LoginToken";function Qr(){return localStorage.getItem(Et)}function Yr(r){localStorage.setItem(Et,r)}function Jr(r){return localStorage.getItem(`${Ct}_${r}`)}function Re(){return localStorage.getItem(St)}function Gr(r,e){const{refreshToken:t,...o}=e;localStorage.setItem(`${Ct}_${r}`,JSON.stringify(o)),t&&localStorage.setItem(St,t)}function Zr(){return sessionStorage.getItem(xt)}function Tt(r){sessionStorage.setItem(xt,r)}function en(){const r=sessionStorage.getItem(Oe),e=sessionStorage.getItem(he)??void 0;return sessionStorage.removeItem(he),sessionStorage.removeItem(Oe),r?{redirectUri:e,codeVerifier:r}:null}function tn(r,e){sessionStorage.setItem(Oe,r),e?sessionStorage.setItem(he,e):sessionStorage.removeItem(he)}function pe(r){const{instance_id:e,scope:t,roles:o,nbf:n,exp:i}=rn(r);return{instanceId:e,scope:t,roles:o.split(";"),issueTime:n,expirationTime:i}}function Ot(r){if(!r)return!0;const{expirationTime:e}=pe(r),t=Math.floor(Date.now()/1e3);return e<t}function Ze(r){if(!r)return!0;const{issueTime:e,expirationTime:t}=typeof r=="string"?pe(r):r,o=t-e,n=Math.floor(Date.now()/1e3);return t<=n+o/2}function rn(r){const t=r.split(".")[1].replace("-","+").replace("_","/"),o=decodeURIComponent(window.atob(t).split("").map(function(n){return"%"+("00"+n.charCodeAt(0).toString(16)).slice(-2)}).join(""));return JSON.parse(o)}function nn(){return new wt.OAuth2Client({server:Q.oauth.server,clientId:Q.oauth.clientId,tokenEndpoint:"/OAuth/Authorization/Token",authorizationEndpoint:sn(),fetch:(...r)=>fetch(...r)})}async function on(r,e){const t=en(),o=await an(r,t);o?(console.log("Successfully logged in"),ln(o,t)):Ot(Re())?(console.log("Not authenticated, redirect to login"),await te(r,e,Lt)):(console.log(`Activate token for scope "${e}"`),await Pt(r,e))}async function Pt(r,e){if(Ot(Re()))return console.log("Refresh token expired, redirect to login"),te(r,e,Lt);const t=Zr(),o=Jr(e),n=t?pe(t):null;(n==null?void 0:n.scope)===e?Ze(n)?(console.log(`Current token for scope "${e}" half expired, redirect for token refresh`),await te(r,e,et)):console.log(`Current token for scope "${e}" already present`):!o||Ze(o)?(console.log(`No Token for scope "${e}" present or half expired, redirect for token refresh`),await te(r,e,et)):(console.log(`Token for requested scope "${e}" present, set as current`),Tt(o))}function sn(){const r=Qr();return r?`/OAuth/Authorization/${r}/Login`:"/OAuth/Authorization/Login"}async function te(r,e,t){const o=await wt.generateCodeVerifier(),n=document.location.href;tn(o,n);const i=await t(r,e,n,o);document.location.href=i.toString()}const Lt=async(r,e,t,o)=>{const n=new URL(await r.getEndpoint("authorizationEndpoint")),[i,s]=await At.getCodeChallenge(o);return n.searchParams.set("clientId",r.settings.clientId),n.searchParams.set("redirectUrl",t),n.searchParams.set("culture_info","de-CH"),n.searchParams.set("application_scope",e),n.searchParams.set("response_type","code"),n.searchParams.set("code_challenge_method",i),n.searchParams.set("code_challenge",s),n},et=async(r,e,t,o)=>{const n=new URL("/OAuth/Authorization/RefreshPublic",r.settings.server),[i,s]=await At.getCodeChallenge(o),l=Re();return n.searchParams.set("redirectUrl",t),n.searchParams.set("culture_info","de-CH"),n.searchParams.set("application_scope",e),n.searchParams.set("refresh_token",l??""),n.searchParams.set("response_type","code"),n.searchParams.set("code_challenge_method",i),n.searchParams.set("code_challenge",s),n};async function an(r,e){return new URLSearchParams(document.location.search).get("code")&&(e!=null&&e.redirectUri)?await r.authorizationCode.getTokenFromCodeRedirect(document.location.href,{redirectUri:e.redirectUri,codeVerifier:e.codeVerifier}):null}function ln(r,e){const{accessToken:t}=r,{scope:o,instanceId:n}=pe(t);Gr(o,r),Tt(t),Yr(n),e!=null&&e.redirectUri&&(document.location=e.redirectUri)}var cn=Object.defineProperty,dn=Object.getOwnPropertyDescriptor,hn=(r,e,t,o)=>{for(var n=o>1?void 0:o?dn(e,t):e,i=r.length-1,s;i>=0;i--)(s=r[i])&&(n=(o?s(e,t,n):s(n))||n);return o&&n&&cn(e,t,n),n};gr(A`
    :root {
      ${ft}
    }
  `.toString());const{getLocale:tt,setLocale:un}=dr({sourceLocale:Cr,targetLocales:Sr,loadLocale:r=>qr(()=>import(`/locales/${r}.js`),[])});let Pe=class extends ${constructor(){super(),this.oAuthClient=nn(),this.handleStateChange=r=>{Pt(this.oAuthClient,r.state.scope)},this.updateDocumentLang(tt()),on(this.oAuthClient,this.getScopeFromState())}connectedCallback(){super.connectedCallback(),window.addEventListener("popstate",this.handleStateChange)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("popstate",this.handleStateChange)}getScopeFromState(){var t;const e=new URL(location.href).searchParams.get("app");return e&&((t=Q.apps.find(({key:o})=>o===e))==null?void 0:t.scope)||Q.apps[0].scope}handleLocaleChange(r){const e=r.detail.locale;un(e),this.updateDocumentLang(e)}updateDocumentLang(r){document.documentElement.lang=r}render(){const r=tt();return y`
      <bkd-header
        currentLocale=${r}
        @bkdlocalechange=${this.handleLocaleChange.bind(this)}
      ></bkd-header>
      <bkd-content></bkd-content>
      <bkd-footer currentLocale=${r}></bkd-footer>
    `}};Pe.styles=[P,A`
      :host {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        width: 100%;
        max-width: 1920px;
        margin: 0 auto;
      }

      bkd-content {
        flex: auto;
      }
    `];Pe=hn([T("bkd-portal"),O()],Pe);
