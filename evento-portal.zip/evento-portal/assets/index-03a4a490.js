var mn=Object.defineProperty;var bn=(t,e,n)=>e in t?mn(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n;var O=(t,e,n)=>(bn(t,typeof e!="symbol"?e+"":e,n),n);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))r(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function n(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(i){if(i.ep)return;i.ep=!0;const s=n(i);fetch(i.href,s)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ve=window,et=ve.ShadowRoot&&(ve.ShadyCSS===void 0||ve.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,tt=Symbol(),ft=new WeakMap;let Lt=class{constructor(e,n,r){if(this._$cssResult$=!0,r!==tt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=n}get styleSheet(){let e=this.o;const n=this.t;if(et&&e===void 0){const r=n!==void 0&&n.length===1;r&&(e=ft.get(n)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),r&&ft.set(n,e))}return e}toString(){return this.cssText}};const yn=t=>new Lt(typeof t=="string"?t:t+"",void 0,tt),E=(t,...e)=>{const n=t.length===1?t[0]:e.reduce((r,i,s)=>r+(o=>{if(o._$cssResult$===!0)return o.cssText;if(typeof o=="number")return o;throw Error("Value passed to 'css' function must be a 'css' function result: "+o+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+t[s+1],t[0]);return new Lt(n,t,tt)},wn=(t,e)=>{et?t.adoptedStyleSheets=e.map(n=>n instanceof CSSStyleSheet?n:n.styleSheet):e.forEach(n=>{const r=document.createElement("style"),i=ve.litNonce;i!==void 0&&r.setAttribute("nonce",i),r.textContent=n.cssText,t.appendChild(r)})},gt=et?t=>t:t=>t instanceof CSSStyleSheet?(e=>{let n="";for(const r of e.cssRules)n+=r.cssText;return yn(n)})(t):t;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Te;const be=window,vt=be.trustedTypes,kn=vt?vt.emptyScript:"",mt=be.reactiveElementPolyfillSupport,He={toAttribute(t,e){switch(e){case Boolean:t=t?kn:null;break;case Object:case Array:t=t==null?t:JSON.stringify(t)}return t},fromAttribute(t,e){let n=t;switch(e){case Boolean:n=t!==null;break;case Number:n=t===null?null:Number(t);break;case Object:case Array:try{n=JSON.parse(t)}catch{n=null}}return n}},zt=(t,e)=>e!==t&&(e==e||t==t),Re={attribute:!0,type:String,converter:He,reflect:!1,hasChanged:zt};let Q=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(e){var n;this.finalize(),((n=this.h)!==null&&n!==void 0?n:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((n,r)=>{const i=this._$Ep(r,n);i!==void 0&&(this._$Ev.set(i,r),e.push(i))}),e}static createProperty(e,n=Re){if(n.state&&(n.attribute=!1),this.finalize(),this.elementProperties.set(e,n),!n.noAccessor&&!this.prototype.hasOwnProperty(e)){const r=typeof e=="symbol"?Symbol():"__"+e,i=this.getPropertyDescriptor(e,r,n);i!==void 0&&Object.defineProperty(this.prototype,e,i)}}static getPropertyDescriptor(e,n,r){return{get(){return this[n]},set(i){const s=this[e];this[n]=i,this.requestUpdate(e,s,r)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||Re}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),e.h!==void 0&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const n=this.properties,r=[...Object.getOwnPropertyNames(n),...Object.getOwnPropertySymbols(n)];for(const i of r)this.createProperty(i,n[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const n=[];if(Array.isArray(e)){const r=new Set(e.flat(1/0).reverse());for(const i of r)n.unshift(gt(i))}else e!==void 0&&n.push(gt(e));return n}static _$Ep(e,n){const r=n.attribute;return r===!1?void 0:typeof r=="string"?r:typeof e=="string"?e.toLowerCase():void 0}u(){var e;this._$E_=new Promise(n=>this.enableUpdating=n),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(e=this.constructor.h)===null||e===void 0||e.forEach(n=>n(this))}addController(e){var n,r;((n=this._$ES)!==null&&n!==void 0?n:this._$ES=[]).push(e),this.renderRoot!==void 0&&this.isConnected&&((r=e.hostConnected)===null||r===void 0||r.call(e))}removeController(e){var n;(n=this._$ES)===null||n===void 0||n.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((e,n)=>{this.hasOwnProperty(n)&&(this._$Ei.set(n,this[n]),delete this[n])})}createRenderRoot(){var e;const n=(e=this.shadowRoot)!==null&&e!==void 0?e:this.attachShadow(this.constructor.shadowRootOptions);return wn(n,this.constructor.elementStyles),n}connectedCallback(){var e;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$ES)===null||e===void 0||e.forEach(n=>{var r;return(r=n.hostConnected)===null||r===void 0?void 0:r.call(n)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$ES)===null||e===void 0||e.forEach(n=>{var r;return(r=n.hostDisconnected)===null||r===void 0?void 0:r.call(n)})}attributeChangedCallback(e,n,r){this._$AK(e,r)}_$EO(e,n,r=Re){var i;const s=this.constructor._$Ep(e,r);if(s!==void 0&&r.reflect===!0){const o=(((i=r.converter)===null||i===void 0?void 0:i.toAttribute)!==void 0?r.converter:He).toAttribute(n,r.type);this._$El=e,o==null?this.removeAttribute(s):this.setAttribute(s,o),this._$El=null}}_$AK(e,n){var r;const i=this.constructor,s=i._$Ev.get(e);if(s!==void 0&&this._$El!==s){const o=i.getPropertyOptions(s),l=typeof o.converter=="function"?{fromAttribute:o.converter}:((r=o.converter)===null||r===void 0?void 0:r.fromAttribute)!==void 0?o.converter:He;this._$El=s,this[s]=l.fromAttribute(n,o.type),this._$El=null}}requestUpdate(e,n,r){let i=!0;e!==void 0&&(((r=r||this.constructor.getPropertyOptions(e)).hasChanged||zt)(this[e],n)?(this._$AL.has(e)||this._$AL.set(e,n),r.reflect===!0&&this._$El!==e&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(e,r))):i=!1),!this.isUpdatePending&&i&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(n){Promise.reject(n)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((i,s)=>this[s]=i),this._$Ei=void 0);let n=!1;const r=this._$AL;try{n=this.shouldUpdate(r),n?(this.willUpdate(r),(e=this._$ES)===null||e===void 0||e.forEach(i=>{var s;return(s=i.hostUpdate)===null||s===void 0?void 0:s.call(i)}),this.update(r)):this._$Ek()}catch(i){throw n=!1,this._$Ek(),i}n&&this._$AE(r)}willUpdate(e){}_$AE(e){var n;(n=this._$ES)===null||n===void 0||n.forEach(r=>{var i;return(i=r.hostUpdated)===null||i===void 0?void 0:i.call(r)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){this._$EC!==void 0&&(this._$EC.forEach((n,r)=>this._$EO(r,this[r],n)),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}};Q.finalized=!0,Q.elementProperties=new Map,Q.elementStyles=[],Q.shadowRootOptions={mode:"open"},mt==null||mt({ReactiveElement:Q}),((Te=be.reactiveElementVersions)!==null&&Te!==void 0?Te:be.reactiveElementVersions=[]).push("1.6.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Le;const ye=window,J=ye.trustedTypes,bt=J?J.createPolicy("lit-html",{createHTML:t=>t}):void 0,Ke="$lit$",U=`lit$${(Math.random()+"").slice(9)}$`,jt="?"+U,_n=`<${jt}>`,G=document,se=()=>G.createComment(""),oe=t=>t===null||typeof t!="object"&&typeof t!="function",Ut=Array.isArray,$n=t=>Ut(t)||typeof(t==null?void 0:t[Symbol.iterator])=="function",ze=`[ 	
\f\r]`,re=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,yt=/-->/g,wt=/>/g,V=RegExp(`>|${ze}(?:([^\\s"'>=/]+)(${ze}*=${ze}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),kt=/'/g,_t=/"/g,Mt=/^(?:script|style|textarea|title)$/i,An=t=>(e,...n)=>({_$litType$:t,strings:e,values:n}),w=An(1),N=Symbol.for("lit-noChange"),_=Symbol.for("lit-nothing"),$t=new WeakMap,B=G.createTreeWalker(G,129,null,!1),En=(t,e)=>{const n=t.length-1,r=[];let i,s=e===2?"<svg>":"",o=re;for(let a=0;a<n;a++){const c=t[a];let p,d,u=-1,m=0;for(;m<c.length&&(o.lastIndex=m,d=o.exec(c),d!==null);)m=o.lastIndex,o===re?d[1]==="!--"?o=yt:d[1]!==void 0?o=wt:d[2]!==void 0?(Mt.test(d[2])&&(i=RegExp("</"+d[2],"g")),o=V):d[3]!==void 0&&(o=V):o===V?d[0]===">"?(o=i??re,u=-1):d[1]===void 0?u=-2:(u=o.lastIndex-d[2].length,p=d[1],o=d[3]===void 0?V:d[3]==='"'?_t:kt):o===_t||o===kt?o=V:o===yt||o===wt?o=re:(o=V,i=void 0);const f=o===V&&t[a+1].startsWith("/>")?" ":"";s+=o===re?c+_n:u>=0?(r.push(p),c.slice(0,u)+Ke+c.slice(u)+U+f):c+U+(u===-2?(r.push(void 0),a):f)}const l=s+(t[n]||"<?>")+(e===2?"</svg>":"");if(!Array.isArray(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return[bt!==void 0?bt.createHTML(l):l,r]};class ae{constructor({strings:e,_$litType$:n},r){let i;this.parts=[];let s=0,o=0;const l=e.length-1,a=this.parts,[c,p]=En(e,n);if(this.el=ae.createElement(c,r),B.currentNode=this.el.content,n===2){const d=this.el.content,u=d.firstChild;u.remove(),d.append(...u.childNodes)}for(;(i=B.nextNode())!==null&&a.length<l;){if(i.nodeType===1){if(i.hasAttributes()){const d=[];for(const u of i.getAttributeNames())if(u.endsWith(Ke)||u.startsWith(U)){const m=p[o++];if(d.push(u),m!==void 0){const f=i.getAttribute(m.toLowerCase()+Ke).split(U),h=/([.?@])?(.*)/.exec(m);a.push({type:1,index:s,name:h[2],strings:f,ctor:h[1]==="."?Pn:h[1]==="?"?Sn:h[1]==="@"?On:xe})}else a.push({type:6,index:s})}for(const u of d)i.removeAttribute(u)}if(Mt.test(i.tagName)){const d=i.textContent.split(U),u=d.length-1;if(u>0){i.textContent=J?J.emptyScript:"";for(let m=0;m<u;m++)i.append(d[m],se()),B.nextNode(),a.push({type:2,index:++s});i.append(d[u],se())}}}else if(i.nodeType===8)if(i.data===jt)a.push({type:2,index:s});else{let d=-1;for(;(d=i.data.indexOf(U,d+1))!==-1;)a.push({type:7,index:s}),d+=U.length-1}s++}}static createElement(e,n){const r=G.createElement("template");return r.innerHTML=e,r}}function Z(t,e,n=t,r){var i,s,o,l;if(e===N)return e;let a=r!==void 0?(i=n._$Co)===null||i===void 0?void 0:i[r]:n._$Cl;const c=oe(e)?void 0:e._$litDirective$;return(a==null?void 0:a.constructor)!==c&&((s=a==null?void 0:a._$AO)===null||s===void 0||s.call(a,!1),c===void 0?a=void 0:(a=new c(t),a._$AT(t,n,r)),r!==void 0?((o=(l=n)._$Co)!==null&&o!==void 0?o:l._$Co=[])[r]=a:n._$Cl=a),a!==void 0&&(e=Z(t,a._$AS(t,e.values),a,r)),e}class Cn{constructor(e,n){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=n}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var n;const{el:{content:r},parts:i}=this._$AD,s=((n=e==null?void 0:e.creationScope)!==null&&n!==void 0?n:G).importNode(r,!0);B.currentNode=s;let o=B.nextNode(),l=0,a=0,c=i[0];for(;c!==void 0;){if(l===c.index){let p;c.type===2?p=new pe(o,o.nextSibling,this,e):c.type===1?p=new c.ctor(o,c.name,c.strings,this,e):c.type===6&&(p=new In(o,this,e)),this._$AV.push(p),c=i[++a]}l!==(c==null?void 0:c.index)&&(o=B.nextNode(),l++)}return B.currentNode=G,s}v(e){let n=0;for(const r of this._$AV)r!==void 0&&(r.strings!==void 0?(r._$AI(e,r,n),n+=r.strings.length-2):r._$AI(e[n])),n++}}class pe{constructor(e,n,r,i){var s;this.type=2,this._$AH=_,this._$AN=void 0,this._$AA=e,this._$AB=n,this._$AM=r,this.options=i,this._$Cp=(s=i==null?void 0:i.isConnected)===null||s===void 0||s}get _$AU(){var e,n;return(n=(e=this._$AM)===null||e===void 0?void 0:e._$AU)!==null&&n!==void 0?n:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const n=this._$AM;return n!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=n.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,n=this){e=Z(this,e,n),oe(e)?e===_||e==null||e===""?(this._$AH!==_&&this._$AR(),this._$AH=_):e!==this._$AH&&e!==N&&this._(e):e._$litType$!==void 0?this.g(e):e.nodeType!==void 0?this.$(e):$n(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==_&&oe(this._$AH)?this._$AA.nextSibling.data=e:this.$(G.createTextNode(e)),this._$AH=e}g(e){var n;const{values:r,_$litType$:i}=e,s=typeof i=="number"?this._$AC(e):(i.el===void 0&&(i.el=ae.createElement(i.h,this.options)),i);if(((n=this._$AH)===null||n===void 0?void 0:n._$AD)===s)this._$AH.v(r);else{const o=new Cn(s,this),l=o.u(this.options);o.v(r),this.$(l),this._$AH=o}}_$AC(e){let n=$t.get(e.strings);return n===void 0&&$t.set(e.strings,n=new ae(e)),n}T(e){Ut(this._$AH)||(this._$AH=[],this._$AR());const n=this._$AH;let r,i=0;for(const s of e)i===n.length?n.push(r=new pe(this.k(se()),this.k(se()),this,this.options)):r=n[i],r._$AI(s),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,n){var r;for((r=this._$AP)===null||r===void 0||r.call(this,!1,!0,n);e&&e!==this._$AB;){const i=e.nextSibling;e.remove(),e=i}}setConnected(e){var n;this._$AM===void 0&&(this._$Cp=e,(n=this._$AP)===null||n===void 0||n.call(this,e))}}class xe{constructor(e,n,r,i,s){this.type=1,this._$AH=_,this._$AN=void 0,this.element=e,this.name=n,this._$AM=i,this.options=s,r.length>2||r[0]!==""||r[1]!==""?(this._$AH=Array(r.length-1).fill(new String),this.strings=r):this._$AH=_}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,n=this,r,i){const s=this.strings;let o=!1;if(s===void 0)e=Z(this,e,n,0),o=!oe(e)||e!==this._$AH&&e!==N,o&&(this._$AH=e);else{const l=e;let a,c;for(e=s[0],a=0;a<s.length-1;a++)c=Z(this,l[r+a],n,a),c===N&&(c=this._$AH[a]),o||(o=!oe(c)||c!==this._$AH[a]),c===_?e=_:e!==_&&(e+=(c??"")+s[a+1]),this._$AH[a]=c}o&&!i&&this.j(e)}j(e){e===_?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class Pn extends xe{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===_?void 0:e}}const xn=J?J.emptyScript:"";class Sn extends xe{constructor(){super(...arguments),this.type=4}j(e){e&&e!==_?this.element.setAttribute(this.name,xn):this.element.removeAttribute(this.name)}}class On extends xe{constructor(e,n,r,i,s){super(e,n,r,i,s),this.type=5}_$AI(e,n=this){var r;if((e=(r=Z(this,e,n,0))!==null&&r!==void 0?r:_)===N)return;const i=this._$AH,s=e===_&&i!==_||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,o=e!==_&&(i===_||s);s&&this.element.removeEventListener(this.name,this,i),o&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var n,r;typeof this._$AH=="function"?this._$AH.call((r=(n=this.options)===null||n===void 0?void 0:n.host)!==null&&r!==void 0?r:this.element,e):this._$AH.handleEvent(e)}}class In{constructor(e,n,r){this.element=e,this.type=6,this._$AN=void 0,this._$AM=n,this.options=r}get _$AU(){return this._$AM._$AU}_$AI(e){Z(this,e)}}const At=ye.litHtmlPolyfillSupport;At==null||At(ae,pe),((Le=ye.litHtmlVersions)!==null&&Le!==void 0?Le:ye.litHtmlVersions=[]).push("2.7.4");const Tn=(t,e,n)=>{var r,i;const s=(r=n==null?void 0:n.renderBefore)!==null&&r!==void 0?r:e;let o=s._$litPart$;if(o===void 0){const l=(i=n==null?void 0:n.renderBefore)!==null&&i!==void 0?i:null;s._$litPart$=o=new pe(e.insertBefore(se(),l),l,void 0,n??{})}return o._$AI(t),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var je,Ue;let A=class extends Q{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,n;const r=super.createRenderRoot();return(e=(n=this.renderOptions).renderBefore)!==null&&e!==void 0||(n.renderBefore=r.firstChild),r}update(e){const n=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Tn(n,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!1)}render(){return N}};A.finalized=!0,A._$litElement$=!0,(je=globalThis.litElementHydrateSupport)===null||je===void 0||je.call(globalThis,{LitElement:A});const Et=globalThis.litElementPolyfillSupport;Et==null||Et({LitElement:A});((Ue=globalThis.litElementVersions)!==null&&Ue!==void 0?Ue:globalThis.litElementVersions=[]).push("3.3.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const P=t=>e=>typeof e=="function"?((n,r)=>(customElements.define(n,r),r))(t,e):((n,r)=>{const{kind:i,elements:s}=r;return{kind:i,elements:s,finisher(o){customElements.define(n,o)}}})(t,e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Rn=(t,e)=>e.kind==="method"&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(n){n.createProperty(e.key,t)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){typeof e.initializer=="function"&&(this[e.key]=e.initializer.call(this))},finisher(n){n.createProperty(e.key,t)}};function D(t){return(e,n)=>n!==void 0?((r,i,s)=>{i.constructor.createProperty(s,r)})(t,e,n):Rn(t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Nt(t){return D({...t,state:!0})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const nt=({finisher:t,descriptor:e})=>(n,r)=>{var i;if(r===void 0){const s=(i=n.originalKey)!==null&&i!==void 0?i:n.key,o=e!=null?{kind:"method",placement:"prototype",key:s,descriptor:e(n.key)}:{...n,key:s};return t!=null&&(o.finisher=function(l){t(l,s)}),o}{const s=n.constructor;e!==void 0&&Object.defineProperty(n,r,e(r)),t==null||t(s,r)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Dt(t,e){return nt({descriptor:n=>{const r={get(){var i,s;return(s=(i=this.renderRoot)===null||i===void 0?void 0:i.querySelector(t))!==null&&s!==void 0?s:null},enumerable:!0,configurable:!0};if(e){const i=typeof n=="symbol"?Symbol():"__"+n;r.get=function(){var s,o;return this[i]===void 0&&(this[i]=(o=(s=this.renderRoot)===null||s===void 0?void 0:s.querySelector(t))!==null&&o!==void 0?o:null),this[i]}}return r}})}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Me;((Me=window.HTMLSlotElement)===null||Me===void 0?void 0:Me.prototype.assignedElements)!=null;function Ht(t){return typeof t=="function"?t():t}const pt=class extends Event{constructor(n,r,i){super(pt.eventName,{cancelable:!1});O(this,"key");O(this,"state");O(this,"value");this.key=n,this.value=r,this.state=i}};let M=pt;O(M,"eventName","lit-state-changed");const Ln=(t,e)=>e!==t&&(e===e||t===t);class me extends EventTarget{constructor(){super();O(this,"hookMap",new Map);this.constructor.finalize(),this.propertyMap&&[...this.propertyMap].forEach(([n,r])=>{if(r.initialValue!==void 0){const i=Ht(r.initialValue);this[n]=i,r.value=i}})}get propertyMap(){return this.constructor.propertyMap}get stateValue(){return Object.fromEntries([...this.propertyMap].map(([n])=>[n,this[n]]))}static finalize(){if(this.finalized)return!1;this.finalized=!0;const n=Object.keys(this.properties||{});for(const r of n)this.createProperty(r,this.properties[r]);return!0}static createProperty(n,r){this.finalize();const i=typeof n=="symbol"?Symbol():`__${n}`,s=this.getPropertyDescriptor(n,i,r);Object.defineProperty(this.prototype,n,s)}static getPropertyDescriptor(n,r,i){const s=(i==null?void 0:i.hasChanged)||Ln;return{get(){return this[r]},set(o){const l=this[n];this[r]=o,s(o,l)===!0&&this.dispatchStateEvent(n,o,this)},configurable:!0,enumerable:!0}}reset(){this.hookMap.forEach(n=>n.reset()),[...this.propertyMap].filter(([n,r])=>!(r.skipReset===!0||r.resetValue===void 0)).forEach(([n,r])=>{this[n]=r.resetValue})}subscribe(n,r,i){r&&!Array.isArray(r)&&(r=[r]);const s=o=>{(!r||r.includes(o.key))&&n(o.key,o.value,this)};return this.addEventListener(M.eventName,s,i),()=>this.removeEventListener(M.eventName,s)}dispatchStateEvent(n,r,i){this.dispatchEvent(new M(n,r,i))}}O(me,"propertyMap"),O(me,"properties"),O(me,"finalized",!1);class z{constructor(e,n,r){O(this,"host");O(this,"state");O(this,"callback");this.host=e,this.state=n,this.host.addController(this),this.callback=r||(()=>this.host.requestUpdate())}hostConnected(){this.state.addEventListener(M.eventName,this.callback),this.callback()}hostDisconnected(){this.state.removeEventListener(M.eventName,this.callback)}}function H(t){return nt({finisher:(e,n)=>{if(Object.getOwnPropertyDescriptor(e.prototype,n))throw new Error("@property must be called before all state decorators");return e.propertyMap||(e.propertyMap=new Map),e.propertyMap.set(n,{...t,initialValue:t==null?void 0:t.value,resetValue:t==null?void 0:t.value}),e.createProperty(n,t)}})}function zn(t,e){if(t!==null&&(e===Boolean||e===Number||e===Array||e===Object))try{t=JSON.parse(t)}catch{console.warn("cannot parse value",t)}return t}const jn=new URL(window.location.href);function Un(t){return nt({finisher:(e,n)=>{if(!Object.getOwnPropertyDescriptor(e.prototype,n))throw new Error("@local-storage decorator need to be called after @property");const i=`${(t==null?void 0:t.parameter)||String(n)}`,s=e.propertyMap.get(n),o=s==null?void 0:s.type;if(s){const l=s.initialValue,a=jn.searchParams.get(i);a!==null&&(s.skipAsync=!0),s.initialValue=()=>zn(a,o)??Ht(l),e.propertyMap.set(n,{...s,...t})}}})}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Mn=t=>typeof t!="string"&&"strTag"in t,Kt=(t,e,n)=>{let r=t[0];for(let i=1;i<t.length;i++)r+=e[n?n[i-1]:i-1],r+=t[i];return r};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Vt=t=>Mn(t)?Kt(t.strings,t.values):t;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ve="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Nn{constructor(e){this.__litLocalizeEventHandler=n=>{n.detail.status==="ready"&&this.host.requestUpdate()},this.host=e}hostConnected(){window.addEventListener(Ve,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(Ve,this.__litLocalizeEventHandler)}}const Dn=t=>t.addController(new Nn(t)),qt=Dn;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Hn=()=>t=>typeof t=="function"?Vn(t):Kn(t),x=Hn,Kn=({kind:t,elements:e})=>({kind:t,elements:e,finisher(n){n.addInitializer(qt)}}),Vn=t=>(t.addInitializer(qt),t);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Bt{constructor(){this.settled=!1,this.promise=new Promise((e,n)=>{this._resolve=e,this._reject=n})}resolve(e){this.settled=!0,this._resolve(e)}reject(e){this.settled=!0,this._reject(e)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */const L=[];for(let t=0;t<256;t++)L[t]=(t>>4&15).toString(16)+(t&15).toString(16);function qn(t){let e=0,n=8997,r=0,i=33826,s=0,o=40164,l=0,a=52210;for(let c=0;c<t.length;c++)n^=t.charCodeAt(c),e=n*435,r=i*435,s=o*435,l=a*435,s+=n<<8,l+=i<<8,r+=e>>>16,n=e&65535,s+=r>>>16,i=r&65535,a=l+(s>>>16)&65535,o=s&65535;return L[a>>8]+L[a&255]+L[o>>8]+L[o&255]+L[i>>8]+L[i&255]+L[n>>8]+L[n&255]}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Bn="",Fn="h",Gn="s";function Wn(t,e){return(e?Fn:Gn)+qn(typeof t=="string"?t:t.join(Bn))}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ct=new WeakMap,Pt=new Map;function Xn(t,e,n){var r;if(t){const i=(r=n==null?void 0:n.id)!==null&&r!==void 0?r:Qn(e),s=t[i];if(s){if(typeof s=="string")return s;if("strTag"in s)return Kt(s.strings,e.values,s.values);{let o=Ct.get(s);return o===void 0&&(o=s.values,Ct.set(s,o)),{...s,values:o.map(l=>e.values[l])}}}}return Vt(e)}function Qn(t){const e=typeof t=="string"?t:t.strings;let n=Pt.get(e);return n===void 0&&(n=Wn(e,typeof t!="string"&&!("strTag"in t)),Pt.set(e,n)),n}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Ne(t){window.dispatchEvent(new CustomEvent(Ve,{detail:t}))}let we="",ie,Ft,ke,qe,Gt,q=new Bt;q.resolve();let ge=0;const Yn=t=>(er((e,n)=>Xn(Gt,e,n)),we=Ft=t.sourceLocale,ke=new Set(t.targetLocales),ke.add(t.sourceLocale),qe=t.loadLocale,{getLocale:Jn,setLocale:Zn}),Jn=()=>we,Zn=t=>{if(t===(ie??we))return q.promise;if(!ke||!qe)throw new Error("Internal error");if(!ke.has(t))throw new Error("Invalid locale code");ge++;const e=ge;return ie=t,q.settled&&(q=new Bt),Ne({status:"loading",loadingLocale:t}),(t===Ft?Promise.resolve({templates:void 0}):qe(t)).then(r=>{ge===e&&(we=t,ie=void 0,Gt=r.templates,Ne({status:"ready",readyLocale:t}),q.resolve())},r=>{ge===e&&(Ne({status:"error",errorLocale:t,errorMessage:r.toString()}),q.reject(r))}),q.promise};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let b=Vt,xt=!1;function er(t){if(xt)throw new Error("lit-localize can only be configured once");b=t,xt=!0}const tr="modulepreload",nr=function(t){return"/"+t},St={},rr=function(e,n,r){if(!n||n.length===0)return e();const i=document.getElementsByTagName("link");return Promise.all(n.map(s=>{if(s=nr(s),s in St)return;St[s]=!0;const o=s.endsWith(".css"),l=o?'[rel="stylesheet"]':"";if(!!r)for(let p=i.length-1;p>=0;p--){const d=i[p];if(d.href===s&&(!o||d.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${s}"]${l}`))return;const c=document.createElement("link");if(c.rel=o?"stylesheet":tr,o||(c.as="script",c.crossOrigin=""),c.href=s,document.head.appendChild(c),o)return new Promise((p,d)=>{c.addEventListener("load",p),c.addEventListener("error",()=>d(new Error(`Unable to preload CSS for ${s}`)))})})).then(()=>e())},Wt="de-CH",ir=["fr-CH"],rt=["de-CH","fr-CH"];function X(t){const{instance_id:e,scope:n,culture_info:r,nbf:i,exp:s}=ar(t);return{instanceId:e,scope:n,locale:r,issueTime:i,expirationTime:s}}function Ot(t,e,n){if(!t)return!1;const r=X(t);return r.scope===e&&r.locale===n&&!or(r)}function sr(t){if(!t)return!0;const{expirationTime:e}=X(t),n=Math.floor(Date.now()/1e3);return e<n}function or(t){if(!t)return!0;const{issueTime:e,expirationTime:n}=typeof t=="string"?X(t):t,r=n-e,i=Math.floor(Date.now()/1e3);return n<=i+r/2}function ar(t){const n=t.split(".")[1].replace("-","+").replace("_","/"),r=decodeURIComponent(window.atob(n).split("").map(function(i){return"%"+("00"+i.charCodeAt(0).toString(16)).slice(-2)}).join(""));return JSON.parse(r)}const Xt="bkdInstance",Be="bkdCodeVerifier",le="bkdRedirectUrl",it="bkdAccessToken",st="bkdRefreshToken",ce="CLX.LoginToken",lr="uiCulture";function Qt(){return localStorage.getItem(Xt)}function cr(t){localStorage.setItem(Xt,t)}function dr(t){return localStorage.getItem(`${it}_${t}`)}function Yt(){return localStorage.getItem(st)}function hr(t,e){const{refreshToken:n,accessToken:r}=e;localStorage.setItem(`${it}_${t}`,r),n&&localStorage.setItem(st,n)}function ur(){new Array(localStorage.length).fill(void 0).forEach((t,e)=>{const n=localStorage.key(e);n&&(n.startsWith(it)||n===st)&&localStorage.removeItem(n)}),sessionStorage.removeItem(ce)}function pr(t){localStorage.setItem(lr,t)}function F(){return sessionStorage.getItem(ce)}function fr(){return localStorage.getItem(ce)}function Jt(t){sessionStorage.setItem(ce,t),localStorage.setItem(ce,t)}function gr(){const t=sessionStorage.getItem(Be),e=sessionStorage.getItem(le)??void 0;return sessionStorage.removeItem(le),sessionStorage.removeItem(Be),t?{redirectUri:e,codeVerifier:t}:null}function vr(t,e){sessionStorage.setItem(Be,t),e?sessionStorage.setItem(le,e):sessionStorage.removeItem(le)}function mr(){return sessionStorage.getItem(le)}const{getLocale:br,setLocale:yr}=Yn({sourceLocale:Wt,targetLocales:ir,loadLocale:t=>rr(()=>import(`/locales/${t}.js`),[])});function Zt(){const t=kr()??Ar()??Er();return t&&_r(t)?t:$r()??Wt}async function wr(t){await yr(t),document.documentElement.lang=t}function kr(){return new URL(location.href).searchParams.get(W)}function _r(t){return rt.includes(t)}function $r(){const t=navigator.language.slice(0,2);return rt.find(e=>e.startsWith(t))??null}function Ar(){const t=mr();return t?new URL(t).searchParams.get(W):null}function Er(){const t=fr();return t?X(t).locale:null}const $={api:{server:"https://eventoapp-test.erz.be.ch/restApi"},oauth:{server:"https://eventoapp-test.erz.be.ch",clientId:"dev3000"},apps:[{key:"schulverwaltung",scope:"Tutoring",root:"apps/webapp-schulverwaltung/index.html",heading:!1},{key:"anmeldedetailsEinlesen",scope:"NG",root:"apps/EmberApps/AnmeldedetailsEinlesen/index.html",heading:!0},{key:"schulleiterPersonen",scope:"NG",root:"apps/EmberApps/SchulleiterPersonen/index.html",heading:!0},{key:"kursausschreibung",scope:"Public",root:"apps/Kursausschreibung/index.html",heading:!0},{key:"kursausschreibungIntern",scope:"Public",root:"apps/Kursausschreibung/indexIntern.html",heading:!0},{key:"stellvertretung",scope:"Tutoring",root:"apps/Stellvertretung/index.html",heading:!0},{key:"reservation",scope:"NG",root:"apps/Raumreservation/index.html",heading:!0}],navigationHome:{key:"home",label:"Home",allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/dashboard"},get navigationMyProfile(){return{key:"myProfile",label:b("Mein Profil"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-profile"}},get navigationMySettings(){return{key:"mySettings",label:b("Einstellungen"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-settings"}},get navigation(){return[{label:b("Unterricht"),items:[{key:"presenceControl",label:b("Präsenzkontrolle"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/presence-control"},{key:"currentEvents",label:b("Aktuelle Fächer"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/events"},{key:"tests",label:b("Tests und Bewertung"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/events"},{key:"substitutionsAssign",label:b("Stellvertretung"),allowedRolesOrPermissions:["TeacherRole"],deniedInstanceIds:null,appKey:"stellvertretung",appPath:"#/substitutions/assign"}]},{label:b("Absenzen"),items:[{key:"openAbsences",label:b("Offene Absenzen entschuldigen"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/open-absences"},{key:"editAbsences",label:b("Absenzen bearbeiten"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/edit-absences"},{key:"evaluateAbsences",label:b("Absenzen auswerten"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/evaluate-absences"}]},{label:b("Angebote"),items:[{key:"coursesAndEvents",label:b("Kurse und Veranstaltungen"),allowedRolesOrPermissions:null,deniedInstanceIds:null,appKey:"kursausschreibung",appPath:"#/"},{key:"internalTraining",label:b("Schulinterne Weiterbildung"),allowedRolesOrPermissions:["TeacherRole","ClassTeacherRole","AbsenceAdministratorRole","SubstituteAdministratorRole"],deniedInstanceIds:null,appKey:"kursausschreibungIntern",appPath:"#/"},{key:"reservations",label:b("Räume und Geräte reservieren"),allowedRolesOrPermissions:["Reservations"],deniedInstanceIds:null,appKey:"reservation",appPath:"#/"}]},{label:b("Aus-/Weiterbildungen"),items:[{key:"myAbsences",label:b("Absenzen"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-absences"},{key:"myGrades",label:b("Noten"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/my-grades"},{key:"schedule",label:b("Stundenplan"),allowedRolesOrPermissions:["StudentRole"],deniedInstanceIds:null,appKey:"schulverwaltung",appPath:"#/schedule"}]},{label:b("Administration"),items:[{key:"substitutionsAdmin",label:b("Stellvertretungen administrieren"),allowedRolesOrPermissions:["SubstituteAdministratorRole"],deniedInstanceIds:null,appKey:"stellvertretung",appPath:"#/substitutions/admin"},{key:"personSearch",label:"Personen und Institutionen suchen",allowedRolesOrPermissions:["PersonRight"],deniedInstanceIds:null,appKey:"schulleiterPersonen",appPath:"#/persons"},{key:"eventRegistration",label:b("Anmeldedetails einlesen"),allowedRolesOrPermissions:["PersonRight","RegistrationRightWeiterbildungModulanlass","RegistrationRightWeiterbildungKurs"],deniedInstanceIds:null,appKey:"anmeldedetailsEinlesen",appPath:"#/input/"}]}]}};function ot(t,e){switch(e){case $.navigationMyProfile.key:return{item:$.navigationMyProfile,group:null};case $.navigationMySettings.key:return{item:$.navigationMySettings,group:null};default:{for(const n of t){const r=n.items.find(({key:i})=>i===e);if(r)return{item:r,group:n}}return{item:$.navigationHome,group:null}}}}function Se(t){const e=$.apps.find(n=>n.key===t.appKey);if(!e)throw new Error(`Invalid app: ${t.appKey}`);return e}function Cr(t,e){const{item:n}=ot(t,e);return Se(n).scope}function Pr(t,e,n){return t.reduce((r,i)=>{const s=i.items.filter(o=>xr(o,e)&&Sr(o,n));return s.length>0?[...r,{...i,items:s}]:r},[])}function xr(t,e){return t.deniedInstanceIds===null||t.deniedInstanceIds.includes(e)}function Sr(t,e){return t.allowedRolesOrPermissions===null||t.allowedRolesOrPermissions.some(n=>e.includes(n))}function Or(t){const e=new URL(location.href);Array.from(e.searchParams.keys()).forEach(r=>{t.includes(r)||e.searchParams.delete(r)}),history.replaceState({},"",e)}function It(t,e,n=!1){const r=new URL(location.href);r.searchParams.set(t,e),n?history.replaceState({},"",r):history.pushState({},"",r)}function Ir(){const e=new URL(location.href).searchParams.get(ee);return e?Cr($.navigation,e):Se($.navigationHome).scope}function de(t){const e=typeof t=="string"?ot(v.navigation,t).item:t;return Tr(e).toString()}function Tr(t){const e=new URL(location.origin);return e.searchParams.set(W,v.locale),e.searchParams.set(ee,t.key),e.hash=t.appPath,e}async function Rr(){var n,r;const t=`${$.api.server}/UserSettings/?expand=AccessInfo`,e=await en(t);return{roles:((n=e==null?void 0:e.AccessInfo)==null?void 0:n.Roles)??[],permissions:((r=e==null?void 0:e.AccessInfo)==null?void 0:r.Permissions)??[]}}async function Lr(){const t=`${$.api.server}/Configurations/SchoolAppNavigation`,e=await en(t);return(e==null?void 0:e.instanceName)||null}async function en(t,{method:e="GET"}={}){const n=F();if(!n)throw new Error("No token available");const r=new Headers({"CLX-Authorization":`token_type=urn:ietf:params:oauth:token-type:jwt-bearer, access_token=${n}`,"Content-Type":"application/json"});return await(await fetch(t,{method:e,headers:r})).json()}var zr=Object.defineProperty,jr=Object.getOwnPropertyDescriptor,K=(t,e,n,r)=>{for(var i=r>1?void 0:r?jr(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&zr(e,n,i),i};const W="locale",ee="module",Ur=[W,ee];class j extends me{constructor(){super(...arguments),this.setInitialized=()=>{},this.initialized=new Promise(e=>this.setInitialized=()=>e(null))}async init(){await this.handleStateChange("locale",this.locale),this.subscribe(this.handleStateChange.bind(this)),await this.loadRolesAndPermissions(),this.setInitialized()}subscribeLocale(e){return e(this.locale),this.subscribe((n,r)=>e(r),"locale")}subscribeInstanceName(e){return this.subscribe((n,r)=>e(r),"instanceName")}subscribeNavigationItemKey(e){return e(this.navigationItemKey),this.subscribe((n,r)=>e(r),"navigationItemKey")}subscribeNavigationItem(e){return e(this.navigationItem),this.subscribe((n,r)=>e(r),"navigationItem")}subscribeScopeAndLocale(e,n=!1){return n||e(this.app.scope,this.locale),this.subscribe(()=>e(this.app.scope,this.locale),["app","locale"])}navigate(e){this.initialized.then(()=>{Or(Ur),this.locale=e.searchParams.get(W)||br(),this.navigationItemKey=e.searchParams.get(ee)??$.navigationHome.key})}async handleStateChange(e,n){e==="locale"&&(await this.updateLocale(n),await this.loadInstanceName()),(e==="locale"||e==="navigationItemKey")&&pr(this.locale),(e==="rolesAndPermissions"||e==="locale")&&this.updateNavigation(),(e==="navigationItemKey"||e==="navigation")&&(this.updateNavigationItemAndGroup(this.navigationItemKey),this.updateApp(this.navigationItem))}async updateLocale(e){It(W,e),await wr(e)}updateNavigation(){const e=F();if(!e)return;const{instanceId:n}=X(e);this.navigation=Pr($.navigation,n,this.rolesAndPermissions)}updateNavigationItemAndGroup(e){if(this.navigation.length>0){const{item:n,group:r}=ot(this.navigation,e);this.navigationItem=n,this.navigationGroup=r,n.key===$.navigationHome.key&&n.key!==e&&(this.navigationItemKey=n.key)}It(ee,this.navigationItemKey)}updateApp(e){this.app=Se(e)}async loadRolesAndPermissions(){if(!F())return;const{roles:n,permissions:r}=await Rr();this.rolesAndPermissions=[...n,...r]}async loadInstanceName(){if(!F())return;const n=await Lr();this.instanceName=[b("Evento"),n].filter(Boolean).join(" | ")}}K([H({value:Zt()})],j.prototype,"locale",2);K([H({value:[]})],j.prototype,"rolesAndPermissions",2);K([H({value:""})],j.prototype,"instanceName",2);K([H({value:[]})],j.prototype,"navigation",2);K([Un({parameter:ee}),H({value:null})],j.prototype,"navigationItemKey",2);K([H({value:null})],j.prototype,"navigationGroup",2);K([H({value:$.navigationHome})],j.prototype,"navigationItem",2);K([H({value:Se($.navigationHome)})],j.prototype,"app",2);const v=new j;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const tn={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},at=t=>(...e)=>({_$litDirective$:t,values:e});let lt=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,n,r){this._$Ct=e,this._$AM=n,this._$Ci=r}_$AS(e,n){return this.update(e,n)}update(e,n){return this.render(...n)}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Mr={},Nr=(t,e=Mr)=>t._$AH=e;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Dr=at(class extends lt{constructor(){super(...arguments),this.key=_}render(t,e){return this.key=t,e}update(t,[e,n]){return e!==this.key&&(Nr(t),this.key=e),n}}),nn=E`
  /* Brand Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm1) */
  --bkd-brand-white: rgba(255, 255, 255, 0.42);
  --bkd-brand-red: rgba(234, 22, 31, 1);
  --bkd-brand-black: rgba(0, 0, 0, 1);
  --bkd-brand-light-sand: rgba(252, 248, 243, 1);
  --bkd-brand-sand: rgba(250, 241, 227, 1);
  --bkd-brand-dark-sand: rgba(247, 233, 210, 1);
  --bkd-brand-sand-hover: rgba(242, 224, 195, 1);
  --bkd-brand-cappuchino: rgba(235, 211, 174, 1);

  /* Functional Foreground Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-fg-black: rgba(0, 0, 0, 1);
  --bkd-func-fg-grey: rgba(112, 112, 112, 1);
  --bkd-func-fg-light-grey: rgba(112, 112, 112, 0.68);
  --bkd-func-fg-white: rgba(255, 255, 255, 1);

  /* Functional Background Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-bg-anthrazit-hover: rgba(64, 64, 64, 1);
  --bkd-func-bg-anthrazit: rgba(78, 78, 78, 0.95);
  --bkd-func-bg-dark-grey: rgba(112, 112, 112, 1);
  --bkd-func-bg-line-grey: rgba(112, 112, 112, 0.5);
  --bkd-func-bg-grey: rgba(222, 222, 222, 1);
  --bkd-func-bg-light-grey: rgba(242, 242, 242, 1);
  --bkd-func-bg-very-light-grey: rgba(248, 248, 248, 1);
  --bkd-func-bg-white: rgba(255, 255, 255, 1);
  --bkd-func-bg-red: rgba(208, 16, 24, 1);
  --bkd-func-bg-green: rgba(61, 134, 8, 1);

  /* Component-specific Colors */
  --bkd-language-switcher-active-border: rgba(234, 22, 31, 0.77);
  --bkd-footer-border: rgba(238, 238, 238, 1);
  --bkd-mobile-nav-shadow: rgba(0, 0, 0, 0.16);

  /* Dropdowns */
  --bkd-z-index-dropdown: 1;

  /* Fonts */
  --bkd-font-family: "Roboto", sans-serif;
  --bkd-font-size-base: 16px;
  --bkd-font-weight-base: 300;
  --bkd-line-height-base: 1.625;

  /* Spacings */
  --bkd-margin-horizontal-large: 40px;
  --bkd-margin-horizontal-medium: 30px;
  --bkd-margin-horizontal-small: 20px;
`,Hr=E`
  /* See https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm3 */

  /* Thin */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 100;
    src: url("/fonts/roboto-v30-latin-ext_latin-100.woff") format("woff");
  }

  /* Light */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 300;
    src: url("/fonts/roboto-v30-latin-ext_latin-300.woff") format("woff");
  }

  /* Regular */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: url("/fonts/roboto-v30-latin-ext_latin-400.woff") format("woff");
  }

  /* Medium */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: url("/fonts/roboto-v30-latin-ext_latin-500.woff") format("woff");
  }

  /* Bold */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: url("/fonts/roboto-v30-latin-ext_latin-700.woff") format("woff");
  }
`,S=E`
  :host {
    ${nn}
    ${Hr}
  }

  /* Reset */
  * {
    box-sizing: border-box;

    font-family: var(--bkd-font-family);
    font-size: var(--bkd-font-size-base);
    font-weight: var(--bkd-font-weight-base);
    line-height: var(--bkd-line-height-base);

    font-synthesis: none;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
  }
  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin: 0;
  }
  img,
  svg {
    display: block;
  }
`;function Kr(t){var n;const e=document.createElement("style");e.innerText=t,(n=document.querySelector("body"))==null||n.appendChild(e)}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ct(t,e,n){return t?e():n==null?void 0:n()}var Vr=Object.defineProperty,qr=Object.getOwnPropertyDescriptor,rn=(t,e,n,r)=>{for(var i=r>1?void 0:r?qr(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Vr(e,n,i),i};let _e=class extends A{constructor(){super(),this.handleResize=t=>{const{type:e,height:n}=t.data;e==="bkdResize"&&this.iframe&&(this.iframe.height=n)},new z(this,v)}connectedCallback(){super.connectedCallback(),window.addEventListener("message",this.handleResize,!0)}disconnectedCallback(){window.removeEventListener("message",this.handleResize,!0),super.disconnectedCallback()}render(){return w`
      <main>
        ${ct(v.app.heading,()=>w`<h1>${v.navigationItem.label}</h1>`)}
        ${Dr(v.app.root,w`<iframe
            id="app"
            title=${v.app.key}
            src=${v.app.root+v.navigationItem.appPath}
          ></iframe>`)}
      </main>
    `}};_e.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-content-margin-top: 3rem;
        --bkd-content-margin-horizontal: var(--bkd-margin-horizontal-large);
        padding: var(--bkd-content-margin-top)
          var(--bkd-content-margin-horizontal) 0
          var(--bkd-content-margin-horizontal);
      }

      h1 {
        font-size: 3.375rem;
        font-weight: 100;
        line-height: 2.25rem;
        margin: 0 0 calc(3.375rem / 2) 0;
      }

      iframe {
        border: none;
        width: 100%;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-content-margin-top: 2rem;
          --bkd-content-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }

        h1 {
          font-size: 2.25rem;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-content-margin-top: 1rem;
          --bkd-content-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];rn([Dt("iframe")],_e.prototype,"iframe",2);_e=rn([P("bkd-content"),x()],_e);var Br=Object.defineProperty,Fr=Object.getOwnPropertyDescriptor,Gr=(t,e,n,r)=>{for(var i=r>1?void 0:r?Fr(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Br(e,n,i),i};let Fe=class extends A{constructor(){super(),new z(this,v)}render(){return w`
      <footer>
        <div class="copyright">${b("© Bildungs- und Kulturdirektion")}</div>
        <div class="footer-nav">
          <a
            href=${`https://www.bkd.be.ch/${v.locale.slice(0,2)}/tools/rechtliches.html`}
            target="_blank"
            >${b("Rechtliche Hinweise")}</a
          >
          <a
            href=${`https://www.bkd.be.ch/${v.locale.slice(0,2)}/tools/impressum.html`}
            target="_blank"
            >${b("Impressum")}</a
          >
        </div>
      </footer>
    `}};Fe.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-large);
        --bkd-footer-padding-vertical: 18px;

        padding: var(--bkd-footer-padding-vertical)
          var(--bkd-footer-padding-horizontal);
        border-top: 1px solid var(--bkd-footer-border);
        background-color: var(--bkd-brand-light-sand);
        color: var(--bkd-func-fg-black);
      }

      footer {
        display: flex;
        justify-content: space-between;
      }

      .copyright {
        font-size: 0.8125rem;
        font-weight: 300;
        letter-spacing: 0.02rem;
        word-spacing: 0.05rem;
      }

      .footer-nav {
        display: flex;
        gap: 2.5rem;
      }

      a {
        font-size: 0.875rem;
        font-weight: 400;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        line-height: 1.5;
        color: var(--bkd-func-fg-black);
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-medium);
        }

        footer {
          flex-direction: column-reverse;
          gap: 2.25rem;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];Fe=Gr([P("bkd-footer"),x()],Fe);class dt{constructor(e,n,r,i){this.host=e,this.toggleButtonId=n,this.menuId=r,this.itemQueries=i,this.open=!1,this.handleClick=s=>{this.targetMatchesId(s,[this.toggleButtonId,this.menuId])||this.close()},this.handleKeydown=s=>{switch(s.key){case"Escape":{this.close();break}case"ArrowDown":{const o=this.items[this.nextLinkIndex(1)];o==null||o.focus();break}case"ArrowUp":{const o=this.items[this.nextLinkIndex(-1)];o==null||o.focus();break}}},this.handleCloseOthers=s=>{const{source:o}=s.detail;o!==this&&this.close()},this.host.addController(this)}get items(){var n;const e=((n=this.itemQueries)==null?void 0:n.queryItems)&&this.itemQueries.queryItems();return Array.from(e??[])}get focusedItem(){var e;return(e=this.itemQueries)!=null&&e.queryFocused?this.itemQueries.queryFocused():null}hostDisconnected(){this.removeListeners()}toggle(){this.open=!this.open,this.host.requestUpdate(),this.open?(this.closeOthers(),this.addListeners()):this.removeListeners()}close(){this.open&&this.toggle()}addListeners(){document.addEventListener("click",this.handleClick,!0),document.addEventListener("keydown",this.handleKeydown,!0),document.addEventListener("bkddropdowntoggleclose",this.handleCloseOthers)}removeListeners(){document.removeEventListener("click",this.handleClick,!0),document.removeEventListener("keydown",this.handleKeydown,!0),document.removeEventListener("bkddropdowntoggleclose",this.handleCloseOthers)}activeLinkIndex(){const e=this.focusedItem?this.items.indexOf(this.focusedItem):-1;return e===-1?null:e}nextLinkIndex(e){const n=this.activeLinkIndex(),r=0,i=this.items.length-1;if(n===null)return e>0?r:i;const s=n+e;return s>i?r:s<r?i:s}closeOthers(){document.dispatchEvent(new CustomEvent("bkddropdowntoggleclose",{detail:{source:this}}))}targetMatchesId(e,n){return e.composedPath().some(r=>n.includes(r.id))}}var Wr=Object.defineProperty,Xr=Object.getOwnPropertyDescriptor,Qr=(t,e,n,r)=>{for(var i=r>1?void 0:r?Xr(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Wr(e,n,i),i};let Ge=class extends A{constructor(){super(),this.mobileNav=new dt(this,"mobile-nav-toggle","mobile-nav-menu"),new z(this,v)}handleLogoClick(t){t.preventDefault(),v.navigationItemKey="home"}handleNavItemClick(t){const{item:e}=t.detail;v.navigationItemKey=e.key,this.mobileNav.close()}handleSettingsItemClick(t){const{item:e,event:n}=t.detail;e.external||(n.preventDefault(),e.key==="logout"?this.dispatchEvent(new CustomEvent("bkdlogout",{composed:!0,bubbles:!0})):v.navigationItemKey=e.key),this.mobileNav.close()}render(){return w`
      <header>
        <bkd-service-nav
          .mobileNavOpen=${this.mobileNav.open}
          @bkdhamburgertoggle=${()=>this.mobileNav.toggle()}
          @bkdsettingsitemclick=${this.handleSettingsItemClick.bind(this)}
        ></bkd-service-nav>
        <a class="logo" href=${de("home")}
          ><img
            src="logo.svg"
            alt=${b("Evento Startseite")}
            @click=${this.handleLogoClick.bind(this)}
        /></a>
        <div class="logo-caption">${v.instanceName}</div>
        <bkd-nav
          @bkdnavitemclick=${this.handleNavItemClick.bind(this)}
        ></bkd-nav>
        ${ct(this.mobileNav.open,()=>w`<bkd-mobile-nav
              id="mobile-nav-menu"
              @bkdnavitemclick=${this.handleNavItemClick.bind(this)}
              @bkdsettingsitemclick=${this.handleSettingsItemClick.bind(this)}
            ></bkd-mobile-nav>`)}
      </header>
    `}};Ge.styles=[S,E`
      /* Large screen */

      :host {
        --bkd-header-margin-top: 12px;
        --bkd-header-margin-bottom: calc(2 * var(--bkd-header-margin-top));
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        position: relative;
        padding: var(--bkd-header-margin-top)
          var(--bkd-header-margin-horizontal) var(--bkd-header-margin-bottom)
          var(--bkd-header-margin-horizontal);
        border-bottom: 1px solid var(--bkd-func-bg-grey);
      }

      header {
        display: grid;
        grid-template-columns: max-content auto;
        grid-template-areas:
          "service-nav service-nav"
          "logo ."
          "logo-caption nav";
      }

      bkd-service-nav {
        grid-area: service-nav;
        justify-self: end;
      }

      .logo {
        grid-area: logo;
      }

      .logo > img {
        width: 150px;
      }

      .logo-caption {
        grid-area: logo-caption;
        align-self: baseline;
        max-width: 21rem;
      }

      bkd-nav {
        grid-area: nav;
        align-self: baseline;
        justify-self: end;
      }

      /* Hide mobile nav on large screens */
      @media screen and (min-width: 1201px) {
        bkd-mobile-nav {
          display: none;
        }
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }

        header {
          grid-template-areas:
            "logo service-nav"
            "logo-caption logo-caption";
        }

        bkd-service-nav {
          align-self: center;
        }

        .logo > img {
          width: 110px;
        }

        .logo-caption {
          margin-top: 12px;
          font-size: 0.75rem;
          line-height: 0.75rem;
          max-width: 13.125rem;
        }

        bkd-nav {
          display: none;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }

        bkd-service-nav {
          align-self: start;
          margin-top: 2px; /* Align with logo text */
        }
      }
    `];Ge=Qr([P("bkd-header"),x()],Ge);var Yr=Object.defineProperty,Jr=Object.getOwnPropertyDescriptor,sn=(t,e,n,r)=>{for(var i=r>1?void 0:r?Jr(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Yr(e,n,i),i};let $e=class extends A{constructor(){super(...arguments),this.open=!1}toggle(){this.dispatchEvent(new CustomEvent("bkdhamburgertoggle",{bubbles:!0,composed:!0}))}render(){const t=this.open?"/icons/close.svg":"/icons/hamburger.svg";return w`
      <button
        class="hamburger"
        aria-expanded=${this.open}
        aria-label=${b("Menü")}
        @click=${this.toggle.bind(this)}
      >
        <img src=${t} alt="" width="32" height="32" />
      </button>
    `}};$e.styles=[S,E`
      :host {
        display: flex;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }
    `];sn([D()],$e.prototype,"open",2);$e=sn([P("bkd-hamburger"),x()],$e);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const he=at(class extends lt{constructor(t){var e;if(super(t),t.type!==tn.ATTRIBUTE||t.name!=="class"||((e=t.strings)===null||e===void 0?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(t){return" "+Object.keys(t).filter(e=>t[e]).join(" ")+" "}update(t,[e]){var n,r;if(this.it===void 0){this.it=new Set,t.strings!==void 0&&(this.nt=new Set(t.strings.join(" ").split(/\s/).filter(s=>s!=="")));for(const s in e)e[s]&&!(!((n=this.nt)===null||n===void 0)&&n.has(s))&&this.it.add(s);return this.render(e)}const i=t.element.classList;this.it.forEach(s=>{s in e||(i.remove(s),this.it.delete(s))});for(const s in e){const o=!!e[s];o===this.it.has(s)||!((r=this.nt)===null||r===void 0)&&r.has(s)||(o?(i.add(s),this.it.add(s)):(i.remove(s),this.it.delete(s)))}return N}});var Zr=Object.defineProperty,ei=Object.getOwnPropertyDescriptor,ti=(t,e,n,r)=>{for(var i=r>1?void 0:r?ei(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Zr(e,n,i),i};let We=class extends A{constructor(){super(),new z(this,v)}handleLocaleChange(t,e){t.preventDefault(),v.locale=e}render(){return w`<ul>
      ${rt.map(t=>w`<li>
            <a
              href="#"
              class=${he({active:t===v.locale})}
              aria-current=${t===v.locale}
              @click=${e=>this.handleLocaleChange(e,t)}
            >
              ${t.slice(0,2)}
            </a>
          </li>`)}
    </ul>`}};We.styles=[S,E`
      :host {
        font-size: 0.875rem;
      }

      ul {
        display: flex;
        align-items: baseline;
        margin: 0;
        padding: 0;
        list-style: none;
      }

      li {
        display: flex;
        align-items: baseline;
        margin-left: 0.75rem;
      }

      li + li:before {
        content: "|";
        margin-right: 0.75rem;
      }

      a {
        display: block;
        letter-spacing: 0.025rem;
        text-decoration: none;
        text-transform: uppercase;
        color: var(--bkd-func-fg-black);
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a.active {
        border-bottom: 2px solid var(--bkd-language-switcher-active-border);
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      a.active:hover::after,
      a.active:focus::after,
      a.active:active::after {
        transform: scaleX(0);
      }
    `];We=ti([P("bkd-language-switcher"),x()],We);/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function*Y(t,e){if(t!==void 0){let n=0;for(const r of t)yield e(r,n++)}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Xe extends lt{constructor(e){if(super(e),this.et=_,e.type!==tn.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===_||e==null)return this.ft=void 0,this.et=e;if(e===N)return e;if(typeof e!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.et)return this.ft;this.et=e;const n=[e];return n.raw=n,this.ft={_$litType$:this.constructor.resultType,strings:n,values:[]}}}Xe.directiveName="unsafeHTML",Xe.resultType=1;const ni=at(Xe),ri=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"><path fill="currentColor" d="m22 15.975-1.775 1.775L12 9.525 3.775 17.75 2 15.975l10-10 10 10Z"/></svg>
`,ii=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"><path fill="currentColor" d="M2 8.025 3.775 6.25 12 14.475l8.225-8.225L22 8.025l-10 10-10-10Z"/></svg>
`;function on(t){return[{key:"myProfile",label:b("Mein Profil"),href:de("myProfile")},{key:"mySettings",label:b("Einstellungen"),href:de("mySettings")},{key:"videos",label:b("Video-Tutorials"),href:t==="de-CH"?"https://www.youtube.com/playlist?list=PLLDtLiOuctbx-_EQWgWqTO1MRbX845OEf":"https://www.youtube.com/playlist?list=PLLDtLiOuctbyEegnquAkaW4u8cm62lFAU",img:"/icons/external-link.svg",external:!0},{key:"logout",label:b("Logout"),href:"#",img:"/icons/logout.svg"}]}var si=Object.defineProperty,oi=Object.getOwnPropertyDescriptor,an=(t,e,n,r)=>{for(var i=r>1?void 0:r?oi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&si(e,n,i),i};let Ae=class extends A{constructor(){super(),this.openGroup=null,new z(this,v)}connectedCallback(){super.connectedCallback(),this.openGroupOfCurrentItem()}openGroupOfCurrentItem(){this.openGroup||(this.openGroup=v.navigationGroup)}handleGroupClick(t,e){var n;t.preventDefault(),this.openGroup=e.label!==((n=this.openGroup)==null?void 0:n.label)?e:null}handleNavItemClick(t,e){t.preventDefault(),this.dispatchEvent(new CustomEvent("bkdnavitemclick",{detail:{item:e},composed:!0,bubbles:!0}))}handleSettingsItemClick(t,e){this.dispatchEvent(new CustomEvent("bkdsettingsitemclick",{detail:{item:e,event:t},composed:!0,bubbles:!0}))}renderGroup(t){var n;const e=t.label===((n=this.openGroup)==null?void 0:n.label);return w`
      <li
        class=${he({group:!0,open:e})}
        aria-expanded=${e}
      >
        <button
          class="group-header"
          @click=${r=>this.handleGroupClick(r,t)}
        >
          <label> ${t.label} </label>
          ${ni(e?ii:ri)}
        </button>
        <ul class="items">
          ${Y(t.items,this.renderNavItem.bind(this))}
        </ul>
      </li>
    `}renderNavItem(t){const e=t.key===v.navigationItemKey;return w`
      <li
        class=${he({item:!0,active:e})}
      >
        <a
          href=${de(t)}
          @click=${n=>this.handleNavItemClick(n,t)}
        >
          ${t.label}
        </a>
      </li>
    `}renderSettingsItem(t){return w`<li>
      <a
        href=${t.href}
        target=${t.external?"_blank":"_self"}
        @click=${e=>this.handleSettingsItemClick(e,t)}
      >
        ${t.label}
      </a>
      ${t.img?w`<img src=${t.img} alt="" width="24" height="24" />`:_}
    </li>`}render(){return w`
      <ul class="nav">
        ${Y(v.navigation,this.renderGroup.bind(this))}
      </ul>
      <div class="service-nav">
        <ul>
          ${Y(on(v.locale),this.renderSettingsItem.bind(this))}
        </ul>
        <bkd-language-switcher></bkd-language-switcher>
      </div>
    `}};Ae.styles=[S,E`
      :host {
        position: absolute;
        width: 100vw;
        padding: 1.25rem;
        left: 0;
        top: calc(100% + 1px); /* Place right below header */
        max-height: calc(100vh - 100% - 1px);
        display: flex;
        gap: 5rem;
        flex-direction: column;
        background-color: var(--bkd-func-bg-white);
        box-shadow: 0 2px 6px -1px var(--bkd-mobile-nav-shadow);
      }

      a {
        color: var(--bkd-brand-black);
        text-decoration: none;
      }

      ul {
        list-style: none;
        margin: 0;
        padding: 0;
      }

      li.group {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .group-header {
        display: flex;
        justify-content: space-between;
        width: 100%;
        padding: 0.5rem 1rem;
        cursor: pointer;
        border: none;
        background: transparent;
      }

      .group-header label {
        font-weight: 600;
        cursor: pointer;
      }

      ul.items {
        height: 0;
      }

      .open ul.items {
        height: auto;
      }

      li.item {
        display: flex; /* Animated bottom border should only be as wide as the link */
        border-left: 4px solid transparent;
        padding: 0.5rem 1.25rem;
      }

      li.item a {
        font-weight: 400;
      }

      li.item a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-brand-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      li.item a:hover::after,
      li.item a:focus::after,
      li.item a:active::after {
        transform: scaleX(1);
      }

      li.item.active {
        border-color: var(--bkd-brand-red);
        background-color: var(--bkd-brand-sand);
      }

      li.item.active a {
        font-weight: 600;
        color: var(--bkd-brand-red);
      }

      li.item.active a:after {
        border-color: transparent;
      }

      .service-nav {
        background: var(--bkd-brand-sand);
        padding: 1.5rem 2rem;
        display: flex;
        flex-direction: column;
        gap: 2rem;
      }

      .service-nav li {
        display: flex;
        gap: 0.5rem;
        align-items: center;
        height: 36px;
        line-height: 1.5;
      }

      .service-nav a {
        font-size: 0.875rem;
        font-weight: 400;
        color: var(--bkd-func-fg-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
        margin-top: 2px;
      }

      .service-nav a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      .service-nav a:hover::after,
      .service-nav a:focus::after {
        transform: scaleX(1);
      }

      bkd-language-switcher {
        margin-left: -0.75rem;
      }
    `];an([Nt()],Ae.prototype,"openGroup",2);Ae=an([P("bkd-mobile-nav"),x()],Ae);var ai=Object.defineProperty,li=Object.getOwnPropertyDescriptor,ci=(t,e,n,r)=>{for(var i=r>1?void 0:r?li(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&ai(e,n,i),i};let Qe=class extends A{constructor(){super(),new z(this,v)}renderGroupToggle(t,e){return w`
      <bkd-nav-group-toggle
        .group=${t}
        ?active=${e}
      ></bkd-nav-group-toggle>
    `}render(){return Y(v.navigation,t=>{var e;return this.renderGroupToggle(t,t.label===((e=v.navigationGroup)==null?void 0:e.label))})}};Qe.styles=[S,E`
      /* Large screen */

      :host {
        display: flex;
        justify-content: end;
        gap: 4.375rem;
      }

      /* Medium screen */

      @media screen and (max-width: 1500px) {
        :host {
          gap: 3rem;
        }
      }
    `];Qe=ci([P("bkd-nav"),x()],Qe);var di=Object.defineProperty,hi=Object.getOwnPropertyDescriptor,ht=(t,e,n,r)=>{for(var i=r>1?void 0:r?hi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&di(e,n,i),i};let ue=class extends A{constructor(){super(),this.open=!1,new z(this,v)}handleItemClick(t,e){t.preventDefault(),this.dispatchEvent(new CustomEvent("bkdnavitemclick",{detail:{item:e},composed:!0,bubbles:!0}))}renderItem(t){const e=t.key===v.navigationItemKey;return w`
      <li role="presentation" class=${he({active:e})}>
        <a
          role="menuitem"
          href=${de(t)}
          @click=${n=>this.handleItemClick(n,t)}
          >${t.label}</a
        >
      </li>
    `}render(){if(!(!this.group||!this.open))return w`
      <ul role="menu" id="group-menu">
        ${Y(this.group.items,this.renderItem.bind(this))}
      </ul>
    `}};ue.styles=[S,E`
      :host {
        position: relative;
      }

      ul {
        position: absolute;
        right: 0;
        border: 1px solid var(--bkd-func-bg-grey);
        padding: 1rem 0;
        margin: 0.5rem 0;
        list-style-type: none;
        background: var(--bkd-func-bg-white);
        z-index: var(--bkd-z-index-dropdown);
        min-width: max-content;
      }

      li {
        padding: 0 1.5rem;
        height: 100%;
        line-height: 2.5;
      }

      li.active {
        background: var(--bkd-brand-sand);
        border-left: 6px solid var(--bkd-brand-red);
        padding: 0 calc(1.5rem - 6px);
      }

      li.active a {
        font-weight: 600;
        color: var(--bkd-brand-red);
      }

      li.active a:after {
        background-color: transparent;
      }

      a {
        font-size: 1.125rem;
        font-weight: 300;
        color: var(--bkd-brand-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a.active:after {
        background-color: var(--bkd-brand-red);
      }

      a:hover::after,
      a:focus::after,
      a:active::after,
      a.active:after {
        transform: scaleX(1);
      }
    `];ht([D()],ue.prototype,"group",2);ht([D()],ue.prototype,"open",2);ue=ht([P("bkd-nav-group-dropdown"),x()],ue);var ui=Object.defineProperty,pi=Object.getOwnPropertyDescriptor,Oe=(t,e,n,r)=>{for(var i=r>1?void 0:r?pi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&ui(e,n,i),i};let te=class extends A{constructor(){super(...arguments),this.dropdown=new dt(this,"group-toggle","group-menu",{queryItems:()=>{var t,e;return((e=(t=this.dropdownElement)==null?void 0:t.shadowRoot)==null?void 0:e.querySelectorAll("a[role='menuitem']"))??null},queryFocused:()=>{var t,e;return((e=(t=this.dropdownElement)==null?void 0:t.shadowRoot)==null?void 0:e.activeElement)??null}})}toggle(t){t.preventDefault(),this.dropdown.toggle()}handleItemClick(){this.dropdown.close()}render(){if(this.group)return w`
      <a
        id="group-toggle"
        href="#"
        @click=${this.toggle.bind(this)}
        class=${he({active:!!this.active})}
        aria-expanded=${this.dropdown.open}
        aria-haspopup="menu"
      >
        ${this.group.label}
      </a>
      <bkd-nav-group-dropdown
        .group=${this.group}
        .open=${this.dropdown.open}
        @bkdnavitemclick=${this.handleItemClick.bind(this)}
      ></bkd-nav-group-dropdown>
    `}};te.styles=[S,E`
      a {
        font-size: 1.5rem;
        font-weight: 300;
        color: var(--bkd-brand-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a.active:after {
        background-color: var(--bkd-brand-red);
      }

      a:hover::after,
      a:focus::after,
      a:active::after,
      a.active:after {
        transform: scaleX(1);
      }
    `];Oe([Dt("bkd-nav-group-dropdown")],te.prototype,"dropdownElement",2);Oe([D()],te.prototype,"group",2);Oe([D({type:Boolean})],te.prototype,"active",2);te=Oe([P("bkd-nav-group-toggle"),x()],te);var fi=Object.defineProperty,gi=Object.getOwnPropertyDescriptor,ln=(t,e,n,r)=>{for(var i=r>1?void 0:r?gi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&fi(e,n,i),i};let Ee=class extends A{handleClick(t){t.preventDefault(),console.log("clicked",this.item)}render(){if(this.item)return w`<a href="#" @click=${this.handleClick.bind(this)}
      >${this.item.label}</a
    >`}};Ee.styles=[S,E``];ln([D()],Ee.prototype,"item",2);Ee=ln([P("bkd-nav-item-link"),x()],Ee);var vi=Object.defineProperty,mi=Object.getOwnPropertyDescriptor,cn=(t,e,n,r)=>{for(var i=r>1?void 0:r?mi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&vi(e,n,i),i};let Ce=class extends A{constructor(){super(...arguments),this.mobileNavOpen=!1}render(){return w`
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <erz-notifications></erz-notifications>
      <bkd-user-settings></bkd-user-settings>
      <bkd-language-switcher></bkd-language-switcher>
      <bkd-hamburger
        id="mobile-nav-toggle"
        .open=${this.mobileNavOpen}
      ></bkd-hamburger>
    `}};Ce.styles=[S,E`
      /* Large screen */

      :host {
        display: flex;
        align-items: center;
        gap: 2.5rem;
        margin-left: 1rem;
      }

      bkd-hamburger {
        display: none;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        bkd-user-settings {
          display: none;
        }

        bkd-language-switcher {
          display: none;
        }

        bkd-hamburger {
          display: inherit;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          gap: 1.5rem;
        }
      }
    `];cn([D()],Ce.prototype,"mobileNavOpen",2);Ce=cn([P("bkd-service-nav"),x()],Ce);var bi=Object.defineProperty,yi=Object.getOwnPropertyDescriptor,wi=(t,e,n,r)=>{for(var i=r>1?void 0:r?yi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&bi(e,n,i),i};let Ye=class extends A{constructor(){super(),this.dropdown=new dt(this,"settings-toggle","settings-menu",{queryItems:()=>{var t;return((t=this.shadowRoot)==null?void 0:t.querySelectorAll("a[role='menuitem']"))??null},queryFocused:()=>{var t;return((t=this.shadowRoot)==null?void 0:t.activeElement)??null}}),new z(this,v)}handleSettingsItemClick(t,e){this.dropdown.close(),this.dispatchEvent(new CustomEvent("bkdsettingsitemclick",{detail:{item:e,event:t},composed:!0,bubbles:!0}))}renderSettingsItem(t){return w`<li role="presentation">
      <a
        role="menuitem"
        href=${t.href}
        target=${t.external?"_blank":"_self"}
        @click=${e=>this.handleSettingsItemClick(e,t)}
      >
        ${t.label}</a
      >
      ${t.img?w`<img src=${t.img} alt="" width="24" height="24" />`:_}
    </li>`}render(){return w`
      <button
        type="button"
        id="settings-toggle"
        @click=${()=>this.dropdown.toggle()}
        aria-label=${b("Menü Benutzereinstellungen")}
        aria-expanded=${this.dropdown.open}
        aria-haspopup="menu"
      >
        <img src="/icons/settings.svg" alt="" width="32" height="32" />
      </button>
      <ul id="settings-menu" role="menu" ?hidden=${!this.dropdown.open}>
        ${Y(on(v.locale),this.renderSettingsItem.bind(this))}
      </ul>
    `}};Ye.styles=[S,E`
      :host {
        display: flex;
        position: relative;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }

      ul {
        position: absolute;
        right: 0;
        border: 1px solid var(--bkd-func-bg-grey);
        padding: 1rem 0;
        list-style-type: none;
        margin-top: calc(32px + 0.5rem);
        background: var(--bkd-func-bg-white);
        z-index: var(--bkd-z-index-dropdown);
        min-width: max-content;
      }

      li {
        padding: 0 1.5rem;
        display: flex;
        gap: 0.5rem;
        align-items: center;
        height: 36px;
      }

      li.selected {
        color: var(--bkd-brand-red);
        background: var(--bkd-brand-sand);
        border-left: 6px solid var(--bkd-brand-red);
        font-weight: 700;
        padding: 0 calc(1.5rem - 6px);
      }

      a {
        font-size: 0.875rem;
        font-weight: 400;
        color: var(--bkd-func-fg-black);
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        text-decoration: none;
        display: inline-block;
        margin-top: 2px;
      }

      a:after {
        display: block;
        content: "";
        height: 2px;
        background-color: var(--bkd-brand-black);
        transform: scaleX(0);
        transition: all 150ms ease-in-out;
      }

      a:hover::after,
      a:focus::after {
        transform: scaleX(1);
      }
    `];Ye=wi([P("bkd-user-settings"),x()],Ye);function ki(t){if(t.__esModule)return t;var e=t.default;if(typeof e=="function"){var n=function r(){if(this instanceof r){var i=[null];i.push.apply(i,arguments);var s=Function.bind.apply(e,i);return new s}return e.apply(this,arguments)};n.prototype=e.prototype}else n={};return Object.defineProperty(n,"__esModule",{value:!0}),Object.keys(t).forEach(function(r){var i=Object.getOwnPropertyDescriptor(t,r);Object.defineProperty(n,r,i.get?i:{enumerable:!0,get:function(){return t[r]}})}),n}var dn={exports:{}};(function(t,e){(function(n,r){t.exports=r()})(self,()=>(()=>{var n={934:(o,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.generateQueryString=l.tokenResponseToOAuth2Token=l.OAuth2Client=void 0;const c=a(443),p=a(618);function d(f,h){return new URL(f,h).toString()}function u(f){return f.then(h=>{var g;return{accessToken:h.access_token,expiresAt:h.expires_in?Date.now()+1e3*h.expires_in:null,refreshToken:(g=h.refresh_token)!==null&&g!==void 0?g:null}})}function m(f){return new URLSearchParams(Object.fromEntries(Object.entries(f).filter(([h,g])=>g!==void 0))).toString()}l.OAuth2Client=class{constructor(f){this.discoveryDone=!1,this.serverMetadata=null,f!=null&&f.fetch||(f.fetch=fetch),this.settings=f}async refreshToken(f){if(!f.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const h={grant_type:"refresh_token",refresh_token:f.refreshToken};return this.settings.clientSecret||(h.client_id=this.settings.clientId),u(this.request("tokenEndpoint",h))}async clientCredentials(f){var h;const g=["client_id","client_secret","grant_type","scope"];if(f!=null&&f.extraParams&&Object.keys(f.extraParams).filter(y=>g.includes(y)).length>0)throw new Error(`The following extraParams are disallowed: '${g.join("', '")}'`);const k={grant_type:"client_credentials",scope:(h=f==null?void 0:f.scope)===null||h===void 0?void 0:h.join(" "),...f==null?void 0:f.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return u(this.request("tokenEndpoint",k))}async password(f){var h;const g={grant_type:"password",...f,scope:(h=f.scope)===null||h===void 0?void 0:h.join(" ")};return u(this.request("tokenEndpoint",g))}get authorizationCode(){return new p.OAuth2AuthorizationCodeClient(this)}async introspect(f){const h={token:f.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",h)}async getEndpoint(f){if(this.settings[f]!==void 0)return d(this.settings[f],this.settings.server);if(f!=="discoveryEndpoint"&&(await this.discover(),this.settings[f]!==void 0))return d(this.settings[f],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${f}. Either specify ${f} in the settings, or the "server" endpoint to let the client discover it.`);switch(f){case"authorizationEndpoint":return d("/authorize",this.settings.server);case"tokenEndpoint":return d("/token",this.settings.server);case"discoveryEndpoint":return d("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return d("/introspect",this.settings.server)}}async discover(){var f;if(this.discoveryDone)return;let h;this.discoveryDone=!0;try{h=await this.getEndpoint("discoveryEndpoint")}catch{return void console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint')}const g=await this.settings.fetch(h,{headers:{Accept:"application/json"}});if(!g.ok)return;if(!(!((f=g.headers.get("Content-Type"))===null||f===void 0)&&f.startsWith("application/json")))return void console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");this.serverMetadata=await g.json();const k=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[y,C]of k)this.serverMetadata[y]&&(this.settings[C]=d(this.serverMetadata[y],h));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(f,h){const g=await this.getEndpoint(f),k={"Content-Type":"application/x-www-form-urlencoded"};let y=this.settings.authenticationMethod;switch(y||(y=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),y){case"client_secret_basic":k.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":h.client_id=this.settings.clientId,this.settings.clientSecret&&(h.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+y+". Open a feature request if you want this!")}const C=await this.settings.fetch(g,{method:"POST",body:m(h),headers:k});if(C.ok)return await C.json();let I,ne,Ie;throw C.headers.has("Content-Type")&&C.headers.get("Content-Type").startsWith("application/json")&&(I=await C.json()),I!=null&&I.error?(ne="OAuth2 error "+I.error+".",I.error_description&&(ne+=" "+I.error_description),Ie=I.error):(ne="HTTP Error "+C.status+" "+C.statusText,C.status===401&&this.settings.clientSecret&&(ne+=". It's likely that the clientId and/or clientSecret was incorrect"),Ie=null),new c.OAuth2Error(ne,Ie,C.status)}},l.tokenResponseToOAuth2Token=u,l.generateQueryString=m},618:(o,l,a)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.getCodeChallenge=l.generateCodeVerifier=l.OAuth2AuthorizationCodeClient=void 0;const c=a(934),p=a(443);async function d(h){const g=u();if(g!=null&&g.subtle)return["S256",f(await g.subtle.digest("SHA-256",m(h)))];{const k=a(212).createHash("sha256");return k.update(m(h)),["S256",k.digest("base64url")]}}function u(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const h=a(212);return h.webcrypto?h.webcrypto:null}function m(h){const g=new Uint8Array(h.length);for(let k=0;k<h.length;k++)g[k]=255&h.charCodeAt(k);return g}function f(h){return btoa(String.fromCharCode(...new Uint8Array(h))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}l.OAuth2AuthorizationCodeClient=class{constructor(h){this.client=h}async getAuthorizeUri(h){const[g,k]=await Promise.all([h.codeVerifier?d(h.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),y={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:h.redirectUri,code_challenge_method:g==null?void 0:g[0],code_challenge:g==null?void 0:g[1]};return h.state&&(y.state=h.state),h.scope&&(y.scope=h.scope.join(" ")),k+"?"+(0,c.generateQueryString)(y)}async getTokenFromCodeRedirect(h,g){const{code:k}=await this.validateResponse(h,{state:g.state});return this.getToken({code:k,redirectUri:g.redirectUri,codeVerifier:g.codeVerifier})}async validateResponse(h,g){var k;const y=new URL(h).searchParams;if(y.has("error"))throw new p.OAuth2Error((k=y.get("error_description"))!==null&&k!==void 0?k:"OAuth2 error",y.get("error"),0);if(!y.has("code"))throw new Error(`The url did not contain a code parameter ${h}`);if(g.state&&g.state!==y.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${g.state}`);return{code:y.get("code"),scope:y.has("scope")?y.get("scope").split(" "):void 0}}async getToken(h){const g={grant_type:"authorization_code",code:h.code,redirect_uri:h.redirectUri,code_verifier:h.codeVerifier};return(0,c.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",g))}},l.generateCodeVerifier=async function(){const h=u();if(h){const g=new Uint8Array(32);return h.getRandomValues(g),f(g)}{const g=a(212);return new Promise((k,y)=>{g.randomBytes(32,(C,I)=>{C&&y(C),k(I.toString("base64url"))})})}},l.getCodeChallenge=d},443:(o,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Error=void 0;class a extends Error{constructor(p,d,u){super(p),this.oauth2Code=d,this.httpCode=u}}l.OAuth2Error=a},13:(o,l)=>{Object.defineProperty(l,"__esModule",{value:!0}),l.OAuth2Fetch=void 0,l.OAuth2Fetch=class{constructor(a){this.token=null,this.activeRefresh=null,this.refreshTimer=null,(a==null?void 0:a.scheduleRefresh)===void 0&&(a.scheduleRefresh=!0),this.options=a,a.getStoredToken&&(async()=>this.token=await a.getStoredToken())(),this.scheduleRefresh()}async fetch(a,c){const p=new Request(a,c);return this.mw()(p,d=>fetch(d))}mw(){return async(a,c)=>{const p=await this.getAccessToken();let d=a.clone();d.headers.set("Authorization","Bearer "+p);let u=await c(d);if(!u.ok&&u.status===401){const m=await this.refreshToken();d=a.clone(),d.headers.set("Authorization","Bearer "+m.accessToken),u=await c(d)}return u}}async getToken(){return this.token&&(this.token.expiresAt===null||this.token.expiresAt>Date.now())?this.token:this.refreshToken()}async getAccessToken(){return(await this.getToken()).accessToken}async refreshToken(){var a,c;if(this.activeRefresh)return this.activeRefresh;const p=this.token;this.activeRefresh=(async()=>{var d,u;let m=null;try{p!=null&&p.refreshToken&&(m=await this.options.client.refreshToken(p))}catch{console.warn("[oauth2] refresh token not accepted, we'll try reauthenticating")}if(m||(m=await this.options.getNewToken()),!m){const f=new Error("Unableto obtain OAuth2 tokens, a full reauth may be needed");throw(u=(d=this.options).onError)===null||u===void 0||u.call(d,f),f}return m})();try{const d=await this.activeRefresh;return this.token=d,(c=(a=this.options).storeToken)===null||c===void 0||c.call(a,d),this.scheduleRefresh(),d}catch(d){throw this.options.onError&&this.options.onError(d),d}finally{this.activeRefresh=null}}scheduleRefresh(){var a;if(!this.options.scheduleRefresh||(this.refreshTimer&&(clearTimeout(this.refreshTimer),this.refreshTimer=null),!(!((a=this.token)===null||a===void 0)&&a.expiresAt)||!this.token.refreshToken))return;const c=this.token.expiresAt-Date.now();c<12e4||(this.refreshTimer=setTimeout(async()=>{try{await this.refreshToken()}catch(p){console.error("[fetch-mw-oauth2] error while doing a background OAuth2 auto-refresh",p)}},c-6e4))}}},212:()=>{}},r={};function i(o){var l=r[o];if(l!==void 0)return l.exports;var a=r[o]={exports:{}};return n[o](a,a.exports,i),a.exports}var s={};return(()=>{var o=s;Object.defineProperty(o,"__esModule",{value:!0}),o.OAuth2Error=o.OAuth2Fetch=o.generateCodeVerifier=o.OAuth2AuthorizationCodeClient=o.OAuth2Client=void 0;var l=i(934);Object.defineProperty(o,"OAuth2Client",{enumerable:!0,get:function(){return l.OAuth2Client}});var a=i(618);Object.defineProperty(o,"OAuth2AuthorizationCodeClient",{enumerable:!0,get:function(){return a.OAuth2AuthorizationCodeClient}}),Object.defineProperty(o,"generateCodeVerifier",{enumerable:!0,get:function(){return a.generateCodeVerifier}});var c=i(13);Object.defineProperty(o,"OAuth2Fetch",{enumerable:!0,get:function(){return c.OAuth2Fetch}});var p=i(443);Object.defineProperty(o,"OAuth2Error",{enumerable:!0,get:function(){return p.OAuth2Error}})})(),s})())})(dn);var ut=dn.exports,T={},R={},fe={};Object.defineProperty(fe,"__esModule",{value:!0});fe.OAuth2Error=void 0;class _i extends Error{constructor(e,n,r){super(e),this.oauth2Code=n,this.httpCode=r}}fe.OAuth2Error=_i;var Tt;function hn(){if(Tt)return R;Tt=1,Object.defineProperty(R,"__esModule",{value:!0}),R.generateQueryString=R.tokenResponseToOAuth2Token=R.OAuth2Client=void 0;const t=fe,e=un();class n{constructor(l){this.discoveryDone=!1,this.serverMetadata=null,l!=null&&l.fetch||(l.fetch=fetch),this.settings=l}async refreshToken(l){if(!l.refreshToken)throw new Error("This token didn't have a refreshToken. It's not possible to refresh this");const a={grant_type:"refresh_token",refresh_token:l.refreshToken};return this.settings.clientSecret||(a.client_id=this.settings.clientId),i(this.request("tokenEndpoint",a))}async clientCredentials(l){var a;const c=["client_id","client_secret","grant_type","scope"];if(l!=null&&l.extraParams&&Object.keys(l.extraParams).filter(d=>c.includes(d)).length>0)throw new Error(`The following extraParams are disallowed: '${c.join("', '")}'`);const p={grant_type:"client_credentials",scope:(a=l==null?void 0:l.scope)===null||a===void 0?void 0:a.join(" "),...l==null?void 0:l.extraParams};if(!this.settings.clientSecret)throw new Error("A clientSecret must be provided to use client_credentials");return i(this.request("tokenEndpoint",p))}async password(l){var a;const c={grant_type:"password",...l,scope:(a=l.scope)===null||a===void 0?void 0:a.join(" ")};return i(this.request("tokenEndpoint",c))}get authorizationCode(){return new e.OAuth2AuthorizationCodeClient(this)}async introspect(l){const a={token:l.accessToken,token_type_hint:"access_token"};return this.request("introspectionEndpoint",a)}async getEndpoint(l){if(this.settings[l]!==void 0)return r(this.settings[l],this.settings.server);if(l!=="discoveryEndpoint"&&(await this.discover(),this.settings[l]!==void 0))return r(this.settings[l],this.settings.server);if(!this.settings.server)throw new Error(`Could not determine the location of ${l}. Either specify ${l} in the settings, or the "server" endpoint to let the client discover it.`);switch(l){case"authorizationEndpoint":return r("/authorize",this.settings.server);case"tokenEndpoint":return r("/token",this.settings.server);case"discoveryEndpoint":return r("/.well-known/oauth-authorization-server",this.settings.server);case"introspectionEndpoint":return r("/introspect",this.settings.server)}}async discover(){var l;if(this.discoveryDone)return;this.discoveryDone=!0;let a;try{a=await this.getEndpoint("discoveryEndpoint")}catch{console.warn('[oauth2] OAuth2 discovery endpoint could not be determined. Either specify the "server" or "discoveryEndpoint');return}const c=await this.settings.fetch(a,{headers:{Accept:"application/json"}});if(!c.ok)return;if(!(!((l=c.headers.get("Content-Type"))===null||l===void 0)&&l.startsWith("application/json"))){console.warn("[oauth2] OAuth2 discovery endpoint was not a JSON response. Response is ignored");return}this.serverMetadata=await c.json();const p=[["authorization_endpoint","authorizationEndpoint"],["token_endpoint","tokenEndpoint"],["introspection_endpoint","introspectionEndpoint"]];if(this.serverMetadata!==null){for(const[d,u]of p)this.serverMetadata[d]&&(this.settings[u]=r(this.serverMetadata[d],a));this.serverMetadata.token_endpoint_auth_methods_supported&&!this.settings.authenticationMethod&&(this.settings.authenticationMethod=this.serverMetadata.token_endpoint_auth_methods_supported[0])}}async request(l,a){const c=await this.getEndpoint(l),p={"Content-Type":"application/x-www-form-urlencoded"};let d=this.settings.authenticationMethod;switch(d||(d=this.settings.clientSecret?"client_secret_basic":"client_secret_post"),d){case"client_secret_basic":p.Authorization="Basic "+btoa(this.settings.clientId+":"+this.settings.clientSecret);break;case"client_secret_post":a.client_id=this.settings.clientId,this.settings.clientSecret&&(a.client_secret=this.settings.clientSecret);break;default:throw new Error("Authentication method not yet supported:"+d+". Open a feature request if you want this!")}const u=await this.settings.fetch(c,{method:"POST",body:s(a),headers:p});if(u.ok)return await u.json();let m,f,h;throw u.headers.has("Content-Type")&&u.headers.get("Content-Type").startsWith("application/json")&&(m=await u.json()),m!=null&&m.error?(f="OAuth2 error "+m.error+".",m.error_description&&(f+=" "+m.error_description),h=m.error):(f="HTTP Error "+u.status+" "+u.statusText,u.status===401&&this.settings.clientSecret&&(f+=". It's likely that the clientId and/or clientSecret was incorrect"),h=null),new t.OAuth2Error(f,h,u.status)}}R.OAuth2Client=n;function r(o,l){return new URL(o,l).toString()}function i(o){return o.then(l=>{var a;return{accessToken:l.access_token,expiresAt:l.expires_in?Date.now()+l.expires_in*1e3:null,refreshToken:(a=l.refresh_token)!==null&&a!==void 0?a:null}})}R.tokenResponseToOAuth2Token=i;function s(o){return new URLSearchParams(Object.fromEntries(Object.entries(o).filter(([l,a])=>a!==void 0))).toString()}return R.generateQueryString=s,R}const $i={},Ai=Object.freeze(Object.defineProperty({__proto__:null,default:$i},Symbol.toStringTag,{value:"Module"})),De=ki(Ai);var Rt;function un(){if(Rt)return T;Rt=1,Object.defineProperty(T,"__esModule",{value:!0}),T.getCodeChallenge=T.generateCodeVerifier=T.OAuth2AuthorizationCodeClient=void 0;const t=hn(),e=fe;class n{constructor(c){this.client=c}async getAuthorizeUri(c){const[p,d]=await Promise.all([c.codeVerifier?i(c.codeVerifier):void 0,this.client.getEndpoint("authorizationEndpoint")]),u={client_id:this.client.settings.clientId,response_type:"code",redirect_uri:c.redirectUri,code_challenge_method:p==null?void 0:p[0],code_challenge:p==null?void 0:p[1]};return c.state&&(u.state=c.state),c.scope&&(u.scope=c.scope.join(" ")),d+"?"+(0,t.generateQueryString)(u)}async getTokenFromCodeRedirect(c,p){const{code:d}=await this.validateResponse(c,{state:p.state});return this.getToken({code:d,redirectUri:p.redirectUri,codeVerifier:p.codeVerifier})}async validateResponse(c,p){var d;const u=new URL(c).searchParams;if(u.has("error"))throw new e.OAuth2Error((d=u.get("error_description"))!==null&&d!==void 0?d:"OAuth2 error",u.get("error"),0);if(!u.has("code"))throw new Error(`The url did not contain a code parameter ${c}`);if(p.state&&p.state!==u.get("state"))throw new Error(`The "state" parameter in the url did not match the expected value of ${p.state}`);return{code:u.get("code"),scope:u.has("scope")?u.get("scope").split(" "):void 0}}async getToken(c){const p={grant_type:"authorization_code",code:c.code,redirect_uri:c.redirectUri,code_verifier:c.codeVerifier};return(0,t.tokenResponseToOAuth2Token)(this.client.request("tokenEndpoint",p))}}T.OAuth2AuthorizationCodeClient=n;async function r(){const a=s();if(a){const c=new Uint8Array(32);return a.getRandomValues(c),l(c)}else{const c=De;return new Promise((p,d)=>{c.randomBytes(32,(u,m)=>{u&&d(u),p(m.toString("base64url"))})})}}T.generateCodeVerifier=r;async function i(a){const c=s();if(c!=null&&c.subtle)return["S256",l(await c.subtle.digest("SHA-256",o(a)))];{const d=De.createHash("sha256");return d.update(o(a)),["S256",d.digest("base64url")]}}T.getCodeChallenge=i;function s(){if(typeof window<"u"&&window.crypto)return window.crypto;if(typeof self<"u"&&self.crypto)return self.crypto;const a=De;return a.webcrypto?a.webcrypto:null}function o(a){const c=new Uint8Array(a.length);for(let p=0;p<a.length;p++)c[p]=a.charCodeAt(p)&255;return c}function l(a){return btoa(String.fromCharCode(...new Uint8Array(a))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}return T}var pn=un(),Ei=hn();function Ci(){return new ut.OAuth2Client({server:$.oauth.server,clientId:$.oauth.clientId,tokenEndpoint:"/OAuth/Authorization/Token",authorizationEndpoint:Si(),fetch:(...t)=>fetch(...t)})}async function Pi(t,e,n){const r=gr(),i=await Ii(t,r);i?(console.log("Successfully logged in"),Ti(i,r)):await fn(t,e,n)}async function fn(t,e,n){if(console.log(`Activate token for scope "${e}" and locale "${n}"`),sr(Yt()))return console.log("Not authenticated or refresh token expired, redirect to login"),Je(t,e,n,gn);const r=F(),i=dr(e);Ot(r,e,n)?console.log(`Current token for scope "${e}" and locale "${n}" already set`):Ot(i,e,n)?(console.log(`Token for scope "${e}" and locale "${n}" cached, set as current`),Jt(i)):(console.log(`No token for scope "${e}" and locale "${n}" present or half expired, redirect for token fetch/refresh`),await Je(t,e,n,Oi))}async function xi(t){const e=Qt();if(!e)throw new Error("No instance available");const n=F();if(n)try{await Ri(t,`/OAuth/Authorization/${e}/Logout`,{access_token:n})}catch(r){if(!(r instanceof SyntaxError))throw r}finally{ur();const{scope:r,locale:i}=X(n);await Je(t,r,i,gn)}}function Si(){const t=Qt();return t?`/OAuth/Authorization/${t}/Login`:"/OAuth/Authorization/Login"}async function Je(t,e,n,r){const i=await ut.generateCodeVerifier(),s=new URL(document.location.href);s.searchParams.set(W,n),vr(i,s.toString());const o=await r(t,e,n,s.toString(),i);document.location.href=o.toString()}const gn=async(t,e,n,r,i)=>{const s=new URL(await t.getEndpoint("authorizationEndpoint")),[o,l]=await pn.getCodeChallenge(i);return s.searchParams.set("clientId",t.settings.clientId),s.searchParams.set("redirectUrl",r),s.searchParams.set("culture_info",n),s.searchParams.set("application_scope",e),s.searchParams.set("response_type","code"),s.searchParams.set("code_challenge_method",o),s.searchParams.set("code_challenge",l),s},Oi=async(t,e,n,r,i)=>{const s=new URL("/OAuth/Authorization/RefreshPublic",t.settings.server),[o,l]=await pn.getCodeChallenge(i),a=Yt();return s.searchParams.set("redirectUrl",r),s.searchParams.set("culture_info",n),s.searchParams.set("application_scope",e),s.searchParams.set("refresh_token",a??""),s.searchParams.set("response_type","code"),s.searchParams.set("code_challenge_method",o),s.searchParams.set("code_challenge",l),s};async function Ii(t,e){return new URLSearchParams(document.location.search).get("code")&&(e!=null&&e.redirectUri)?await t.authorizationCode.getTokenFromCodeRedirect(document.location.href,{redirectUri:e.redirectUri,codeVerifier:e.codeVerifier}):null}function Ti(t,e){const{accessToken:n}=t,{scope:r,instanceId:i}=X(n);hr(r,t),Jt(n),cr(i),e!=null&&e.redirectUri&&v.navigate(new URL(e.redirectUri))}async function Ri(t,e,n){var c;const r=new URL(e,t.settings.server).toString(),i={"Content-Type":"application/x-www-form-urlencoded"},s=await fetch(r,{method:"POST",body:n&&Ei.generateQueryString(n),headers:i});if(s.ok)return await s.json();let o,l,a;throw(c=s.headers.get("Content-Type"))!=null&&c.startsWith("application/json")&&(o=await s.json()),o!=null&&o.error?(l="OAuth2 error "+o.error+".",o.error_description&&(l+=" "+o.error_description),a=o.error):(l="HTTP Error "+s.status+" "+s.statusText,a=null),new ut.OAuth2Error(l,a,s.status)}var Li=Object.defineProperty,zi=Object.getOwnPropertyDescriptor,vn=(t,e,n,r)=>{for(var i=r>1?void 0:r?zi(e,n):e,s=t.length-1,o;s>=0;s--)(o=t[s])&&(i=(r?o(e,n,i):o(i))||i);return r&&i&&Li(e,n,i),i};const Ze=Ci(),ji=async function(){await Pi(Ze,Ir(),Zt()),v.init()}();Kr(E`
    :root {
      ${nn}
    }
  `.toString());let Pe=class extends A{constructor(){super(),this.authReady=!1,this.subscriptions=[],ji.then(()=>this.authReady=!0),new z(this,v)}connectedCallback(){super.connectedCallback(),this.subscriptions.push(v.subscribeScopeAndLocale((t,e)=>fn(Ze,t,e),!0)),this.subscriptions.push(v.subscribeInstanceName(this.updateTitle.bind(this))),this.subscriptions.push(v.subscribeNavigationItem(this.updateTitle.bind(this)))}disconnectedCallback(){super.disconnectedCallback(),this.subscriptions.forEach(t=>t())}isAuthenticated(){return!!F()}updateTitle(){const{instanceName:t,navigationItem:e}=v,n=(e==null?void 0:e.label)&&(e==null?void 0:e.key)!==$.navigationHome.key;document.title=n?[e==null?void 0:e.label,t].join(" ― "):t}handleLogout(){xi(Ze)}render(){return w`
      ${ct(this.authReady&&this.isAuthenticated(),()=>w`
          <bkd-header @bkdlogout=${this.handleLogout.bind(this)}></bkd-header>
          <bkd-content></bkd-content>
          <bkd-footer></bkd-footer>
        `)}
    `}};Pe.styles=[S,E`
      :host {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        width: 100%;
        max-width: 1920px;
        margin: 0 auto;
      }

      bkd-content {
        flex: auto;
      }
    `];vn([Nt()],Pe.prototype,"authReady",2);Pe=vn([P("bkd-portal"),x()],Pe);
