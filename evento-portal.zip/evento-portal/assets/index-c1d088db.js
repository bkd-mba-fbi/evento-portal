(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(i){if(i.ep)return;i.ep=!0;const s=t(i);fetch(i.href,s)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const I=window,pe=I.ShadowRoot&&(I.ShadyCSS===void 0||I.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,ge=Symbol(),ve=new WeakMap;let Te=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==ge)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(pe&&e===void 0){const n=t!==void 0&&t.length===1;n&&(e=ve.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&ve.set(t,e))}return e}toString(){return this.cssText}};const Je=r=>new Te(typeof r=="string"?r:r+"",void 0,ge),g=(r,...e)=>{const t=r.length===1?r[0]:e.reduce((n,i,s)=>n+(o=>{if(o._$cssResult$===!0)return o.cssText;if(typeof o=="number")return o;throw Error("Value passed to 'css' function must be a 'css' function result: "+o+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+r[s+1],r[0]);return new Te(t,r,ge)},Ze=(r,e)=>{pe?r.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet):e.forEach(t=>{const n=document.createElement("style"),i=I.litNonce;i!==void 0&&n.setAttribute("nonce",i),n.textContent=t.cssText,r.appendChild(n)})},me=pe?r=>r:r=>r instanceof CSSStyleSheet?(e=>{let t="";for(const n of e.cssRules)t+=n.cssText;return Je(t)})(r):r;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Y;const B=window,be=B.trustedTypes,Ge=be?be.emptyScript:"",$e=B.reactiveElementPolyfillSupport,oe={toAttribute(r,e){switch(e){case Boolean:r=r?Ge:null;break;case Object:case Array:r=r==null?r:JSON.stringify(r)}return r},fromAttribute(r,e){let t=r;switch(e){case Boolean:t=r!==null;break;case Number:t=r===null?null:Number(r);break;case Object:case Array:try{t=JSON.parse(r)}catch{t=null}}return t}},Re=(r,e)=>e!==r&&(e==e||r==r),Q={attribute:!0,type:String,converter:oe,reflect:!1,hasChanged:Re};let C=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(e){var t;this.finalize(),((t=this.h)!==null&&t!==void 0?t:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((t,n)=>{const i=this._$Ep(n,t);i!==void 0&&(this._$Ev.set(i,n),e.push(i))}),e}static createProperty(e,t=Q){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const n=typeof e=="symbol"?Symbol():"__"+e,i=this.getPropertyDescriptor(e,n,t);i!==void 0&&Object.defineProperty(this.prototype,e,i)}}static getPropertyDescriptor(e,t,n){return{get(){return this[t]},set(i){const s=this[e];this[t]=i,this.requestUpdate(e,s,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||Q}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),e.h!==void 0&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const t=this.properties,n=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const i of n)this.createProperty(i,t[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const n=new Set(e.flat(1/0).reverse());for(const i of n)t.unshift(me(i))}else e!==void 0&&t.push(me(e));return t}static _$Ep(e,t){const n=t.attribute;return n===!1?void 0:typeof n=="string"?n:typeof e=="string"?e.toLowerCase():void 0}u(){var e;this._$E_=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(e=this.constructor.h)===null||e===void 0||e.forEach(t=>t(this))}addController(e){var t,n;((t=this._$ES)!==null&&t!==void 0?t:this._$ES=[]).push(e),this.renderRoot!==void 0&&this.isConnected&&((n=e.hostConnected)===null||n===void 0||n.call(e))}removeController(e){var t;(t=this._$ES)===null||t===void 0||t.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((e,t)=>{this.hasOwnProperty(t)&&(this._$Ei.set(t,this[t]),delete this[t])})}createRenderRoot(){var e;const t=(e=this.shadowRoot)!==null&&e!==void 0?e:this.attachShadow(this.constructor.shadowRootOptions);return Ze(t,this.constructor.elementStyles),t}connectedCallback(){var e;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$ES)===null||e===void 0||e.forEach(t=>{var n;return(n=t.hostConnected)===null||n===void 0?void 0:n.call(t)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$ES)===null||e===void 0||e.forEach(t=>{var n;return(n=t.hostDisconnected)===null||n===void 0?void 0:n.call(t)})}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$EO(e,t,n=Q){var i;const s=this.constructor._$Ep(e,n);if(s!==void 0&&n.reflect===!0){const o=(((i=n.converter)===null||i===void 0?void 0:i.toAttribute)!==void 0?n.converter:oe).toAttribute(t,n.type);this._$El=e,o==null?this.removeAttribute(s):this.setAttribute(s,o),this._$El=null}}_$AK(e,t){var n;const i=this.constructor,s=i._$Ev.get(e);if(s!==void 0&&this._$El!==s){const o=i.getPropertyOptions(s),c=typeof o.converter=="function"?{fromAttribute:o.converter}:((n=o.converter)===null||n===void 0?void 0:n.fromAttribute)!==void 0?o.converter:oe;this._$El=s,this[s]=c.fromAttribute(t,o.type),this._$El=null}}requestUpdate(e,t,n){let i=!0;e!==void 0&&(((n=n||this.constructor.getPropertyOptions(e)).hasChanged||Re)(this[e],t)?(this._$AL.has(e)||this._$AL.set(e,t),n.reflect===!0&&this._$El!==e&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(e,n))):i=!1),!this.isUpdatePending&&i&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((i,s)=>this[s]=i),this._$Ei=void 0);let t=!1;const n=this._$AL;try{t=this.shouldUpdate(n),t?(this.willUpdate(n),(e=this._$ES)===null||e===void 0||e.forEach(i=>{var s;return(s=i.hostUpdate)===null||s===void 0?void 0:s.call(i)}),this.update(n)):this._$Ek()}catch(i){throw t=!1,this._$Ek(),i}t&&this._$AE(n)}willUpdate(e){}_$AE(e){var t;(t=this._$ES)===null||t===void 0||t.forEach(n=>{var i;return(i=n.hostUpdated)===null||i===void 0?void 0:i.call(n)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){this._$EC!==void 0&&(this._$EC.forEach((t,n)=>this._$EO(n,this[n],t)),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}};C.finalized=!0,C.elementProperties=new Map,C.elementStyles=[],C.shadowRootOptions={mode:"open"},$e==null||$e({ReactiveElement:C}),((Y=B.reactiveElementVersions)!==null&&Y!==void 0?Y:B.reactiveElementVersions=[]).push("1.6.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var ee;const V=window,P=V.trustedTypes,_e=P?P.createPolicy("lit-html",{createHTML:r=>r}):void 0,ae="$lit$",$=`lit$${(Math.random()+"").slice(9)}$`,Ne="?"+$,Ye=`<${Ne}>`,x=document,R=()=>x.createComment(""),N=r=>r===null||typeof r!="object"&&typeof r!="function",Ue=Array.isArray,Qe=r=>Ue(r)||typeof(r==null?void 0:r[Symbol.iterator])=="function",te=`[ 	
\f\r]`,z=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,ye=/-->/g,Ae=/>/g,w=RegExp(`>|${te}(?:([^\\s"'>=/]+)(${te}*=${te}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),we=/'/g,Ee=/"/g,He=/^(?:script|style|textarea|title)$/i,et=r=>(e,...t)=>({_$litType$:r,strings:e,values:t}),b=et(1),S=Symbol.for("lit-noChange"),u=Symbol.for("lit-nothing"),ke=new WeakMap,k=x.createTreeWalker(x,129,null,!1),tt=(r,e)=>{const t=r.length-1,n=[];let i,s=e===2?"<svg>":"",o=z;for(let l=0;l<t;l++){const a=r[l];let f,d,h=-1,v=0;for(;v<a.length&&(o.lastIndex=v,d=o.exec(a),d!==null);)v=o.lastIndex,o===z?d[1]==="!--"?o=ye:d[1]!==void 0?o=Ae:d[2]!==void 0?(He.test(d[2])&&(i=RegExp("</"+d[2],"g")),o=w):d[3]!==void 0&&(o=w):o===w?d[0]===">"?(o=i??z,h=-1):d[1]===void 0?h=-2:(h=o.lastIndex-d[2].length,f=d[1],o=d[3]===void 0?w:d[3]==='"'?Ee:we):o===Ee||o===we?o=w:o===ye||o===Ae?o=z:(o=w,i=void 0);const M=o===w&&r[l+1].startsWith("/>")?" ":"";s+=o===z?a+Ye:h>=0?(n.push(f),a.slice(0,h)+ae+a.slice(h)+$+M):a+$+(h===-2?(n.push(void 0),l):M)}const c=s+(r[t]||"<?>")+(e===2?"</svg>":"");if(!Array.isArray(r)||!r.hasOwnProperty("raw"))throw Error("invalid template strings array");return[_e!==void 0?_e.createHTML(c):c,n]};class U{constructor({strings:e,_$litType$:t},n){let i;this.parts=[];let s=0,o=0;const c=e.length-1,l=this.parts,[a,f]=tt(e,t);if(this.el=U.createElement(a,n),k.currentNode=this.el.content,t===2){const d=this.el.content,h=d.firstChild;h.remove(),d.append(...h.childNodes)}for(;(i=k.nextNode())!==null&&l.length<c;){if(i.nodeType===1){if(i.hasAttributes()){const d=[];for(const h of i.getAttributeNames())if(h.endsWith(ae)||h.startsWith($)){const v=f[o++];if(d.push(h),v!==void 0){const M=i.getAttribute(v.toLowerCase()+ae).split($),j=/([.?@])?(.*)/.exec(v);l.push({type:1,index:s,name:j[2],strings:M,ctor:j[1]==="."?nt:j[1]==="?"?st:j[1]==="@"?ot:Z})}else l.push({type:6,index:s})}for(const h of d)i.removeAttribute(h)}if(He.test(i.tagName)){const d=i.textContent.split($),h=d.length-1;if(h>0){i.textContent=P?P.emptyScript:"";for(let v=0;v<h;v++)i.append(d[v],R()),k.nextNode(),l.push({type:2,index:++s});i.append(d[h],R())}}}else if(i.nodeType===8)if(i.data===Ne)l.push({type:2,index:s});else{let d=-1;for(;(d=i.data.indexOf($,d+1))!==-1;)l.push({type:7,index:s}),d+=$.length-1}s++}}static createElement(e,t){const n=x.createElement("template");return n.innerHTML=e,n}}function L(r,e,t=r,n){var i,s,o,c;if(e===S)return e;let l=n!==void 0?(i=t._$Co)===null||i===void 0?void 0:i[n]:t._$Cl;const a=N(e)?void 0:e._$litDirective$;return(l==null?void 0:l.constructor)!==a&&((s=l==null?void 0:l._$AO)===null||s===void 0||s.call(l,!1),a===void 0?l=void 0:(l=new a(r),l._$AT(r,t,n)),n!==void 0?((o=(c=t)._$Co)!==null&&o!==void 0?o:c._$Co=[])[n]=l:t._$Cl=l),l!==void 0&&(e=L(r,l._$AS(r,e.values),l,n)),e}class rt{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var t;const{el:{content:n},parts:i}=this._$AD,s=((t=e==null?void 0:e.creationScope)!==null&&t!==void 0?t:x).importNode(n,!0);k.currentNode=s;let o=k.nextNode(),c=0,l=0,a=i[0];for(;a!==void 0;){if(c===a.index){let f;a.type===2?f=new H(o,o.nextSibling,this,e):a.type===1?f=new a.ctor(o,a.name,a.strings,this,e):a.type===6&&(f=new at(o,this,e)),this._$AV.push(f),a=i[++l]}c!==(a==null?void 0:a.index)&&(o=k.nextNode(),c++)}return k.currentNode=x,s}v(e){let t=0;for(const n of this._$AV)n!==void 0&&(n.strings!==void 0?(n._$AI(e,n,t),t+=n.strings.length-2):n._$AI(e[t])),t++}}class H{constructor(e,t,n,i){var s;this.type=2,this._$AH=u,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=i,this._$Cp=(s=i==null?void 0:i.isConnected)===null||s===void 0||s}get _$AU(){var e,t;return(t=(e=this._$AM)===null||e===void 0?void 0:e._$AU)!==null&&t!==void 0?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=L(this,e,t),N(e)?e===u||e==null||e===""?(this._$AH!==u&&this._$AR(),this._$AH=u):e!==this._$AH&&e!==S&&this._(e):e._$litType$!==void 0?this.g(e):e.nodeType!==void 0?this.$(e):Qe(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==u&&N(this._$AH)?this._$AA.nextSibling.data=e:this.$(x.createTextNode(e)),this._$AH=e}g(e){var t;const{values:n,_$litType$:i}=e,s=typeof i=="number"?this._$AC(e):(i.el===void 0&&(i.el=U.createElement(i.h,this.options)),i);if(((t=this._$AH)===null||t===void 0?void 0:t._$AD)===s)this._$AH.v(n);else{const o=new rt(s,this),c=o.u(this.options);o.v(n),this.$(c),this._$AH=o}}_$AC(e){let t=ke.get(e.strings);return t===void 0&&ke.set(e.strings,t=new U(e)),t}T(e){Ue(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let n,i=0;for(const s of e)i===t.length?t.push(n=new H(this.k(R()),this.k(R()),this,this.options)):n=t[i],n._$AI(s),i++;i<t.length&&(this._$AR(n&&n._$AB.nextSibling,i),t.length=i)}_$AR(e=this._$AA.nextSibling,t){var n;for((n=this._$AP)===null||n===void 0||n.call(this,!1,!0,t);e&&e!==this._$AB;){const i=e.nextSibling;e.remove(),e=i}}setConnected(e){var t;this._$AM===void 0&&(this._$Cp=e,(t=this._$AP)===null||t===void 0||t.call(this,e))}}class Z{constructor(e,t,n,i,s){this.type=1,this._$AH=u,this._$AN=void 0,this.element=e,this.name=t,this._$AM=i,this.options=s,n.length>2||n[0]!==""||n[1]!==""?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=u}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,t=this,n,i){const s=this.strings;let o=!1;if(s===void 0)e=L(this,e,t,0),o=!N(e)||e!==this._$AH&&e!==S,o&&(this._$AH=e);else{const c=e;let l,a;for(e=s[0],l=0;l<s.length-1;l++)a=L(this,c[n+l],t,l),a===S&&(a=this._$AH[l]),o||(o=!N(a)||a!==this._$AH[l]),a===u?e=u:e!==u&&(e+=(a??"")+s[l+1]),this._$AH[l]=a}o&&!i&&this.j(e)}j(e){e===u?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class nt extends Z{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===u?void 0:e}}const it=P?P.emptyScript:"";class st extends Z{constructor(){super(...arguments),this.type=4}j(e){e&&e!==u?this.element.setAttribute(this.name,it):this.element.removeAttribute(this.name)}}class ot extends Z{constructor(e,t,n,i,s){super(e,t,n,i,s),this.type=5}_$AI(e,t=this){var n;if((e=(n=L(this,e,t,0))!==null&&n!==void 0?n:u)===S)return;const i=this._$AH,s=e===u&&i!==u||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,o=e!==u&&(i===u||s);s&&this.element.removeEventListener(this.name,this,i),o&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t,n;typeof this._$AH=="function"?this._$AH.call((n=(t=this.options)===null||t===void 0?void 0:t.host)!==null&&n!==void 0?n:this.element,e):this._$AH.handleEvent(e)}}class at{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){L(this,e)}}const xe=V.litHtmlPolyfillSupport;xe==null||xe(U,H),((ee=V.litHtmlVersions)!==null&&ee!==void 0?ee:V.litHtmlVersions=[]).push("2.7.4");const lt=(r,e,t)=>{var n,i;const s=(n=t==null?void 0:t.renderBefore)!==null&&n!==void 0?n:e;let o=s._$litPart$;if(o===void 0){const c=(i=t==null?void 0:t.renderBefore)!==null&&i!==void 0?i:null;s._$litPart$=o=new H(e.insertBefore(R(),c),c,void 0,t??{})}return o._$AI(r),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var re,ne;class p extends C{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,t;const n=super.createRenderRoot();return(e=(t=this.renderOptions).renderBefore)!==null&&e!==void 0||(t.renderBefore=n.firstChild),n}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=lt(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)===null||e===void 0||e.setConnected(!1)}render(){return S}}p.finalized=!0,p._$litElement$=!0,(re=globalThis.litElementHydrateSupport)===null||re===void 0||re.call(globalThis,{LitElement:p});const Se=globalThis.litElementPolyfillSupport;Se==null||Se({LitElement:p});((ne=globalThis.litElementVersions)!==null&&ne!==void 0?ne:globalThis.litElementVersions=[]).push("3.3.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const _=r=>e=>typeof e=="function"?((t,n)=>(customElements.define(t,n),n))(r,e):((t,n)=>{const{kind:i,elements:s}=n;return{kind:i,elements:s,finisher(o){customElements.define(t,o)}}})(r,e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const dt=(r,e)=>e.kind==="method"&&e.descriptor&&!("value"in e.descriptor)?{...e,finisher(t){t.createProperty(e.key,r)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:e.key,initializer(){typeof e.initializer=="function"&&(this[e.key]=e.initializer.call(this))},finisher(t){t.createProperty(e.key,r)}};function G(r){return(e,t)=>t!==void 0?((n,i,s)=>{i.constructor.createProperty(s,n)})(r,e,t):dt(r,e)}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var ie;((ie=window.HTMLSlotElement)===null||ie===void 0?void 0:ie.prototype.assignedElements)!=null;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ct=r=>typeof r!="string"&&"strTag"in r,Me=(r,e,t)=>{let n=r[0];for(let i=1;i<r.length;i++)n+=e[t?t[i-1]:i-1],n+=r[i];return n};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const je=r=>ct(r)?Me(r.strings,r.values):r;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const le="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class ht{constructor(e){this.__litLocalizeEventHandler=t=>{t.detail.status==="ready"&&this.host.requestUpdate()},this.host=e}hostConnected(){window.addEventListener(le,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(le,this.__litLocalizeEventHandler)}}const ut=r=>r.addController(new ht(r)),De=ut;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ft=()=>r=>typeof r=="function"?gt(r):pt(r),y=ft,pt=({kind:r,elements:e})=>({kind:r,elements:e,finisher(t){t.addInitializer(De)}}),gt=r=>(r.addInitializer(De),r);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Ie{constructor(){this.settled=!1,this.promise=new Promise((e,t)=>{this._resolve=e,this._reject=t})}resolve(e){this.settled=!0,this._resolve(e)}reject(e){this.settled=!0,this._reject(e)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */const m=[];for(let r=0;r<256;r++)m[r]=(r>>4&15).toString(16)+(r&15).toString(16);function vt(r){let e=0,t=8997,n=0,i=33826,s=0,o=40164,c=0,l=52210;for(let a=0;a<r.length;a++)t^=r.charCodeAt(a),e=t*435,n=i*435,s=o*435,c=l*435,s+=t<<8,c+=i<<8,n+=e>>>16,t=e&65535,s+=n>>>16,i=n&65535,l=c+(s>>>16)&65535,o=s&65535;return m[l>>8]+m[l&255]+m[o>>8]+m[o&255]+m[i>>8]+m[i&255]+m[t>>8]+m[t&255]}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const mt="",bt="h",$t="s";function _t(r,e){return(e?bt:$t)+vt(typeof r=="string"?r:r.join(mt))}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ce=new WeakMap,Pe=new Map;function yt(r,e,t){var n;if(r){const i=(n=t==null?void 0:t.id)!==null&&n!==void 0?n:At(e),s=r[i];if(s){if(typeof s=="string")return s;if("strTag"in s)return Me(s.strings,e.values,s.values);{let o=Ce.get(s);return o===void 0&&(o=s.values,Ce.set(s,o)),{...s,values:o.map(c=>e.values[c])}}}}return je(e)}function At(r){const e=typeof r=="string"?r:r.strings;let t=Pe.get(e);return t===void 0&&(t=_t(e,typeof r!="string"&&!("strTag"in r)),Pe.set(e,t)),t}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function se(r){window.dispatchEvent(new CustomEvent(le,{detail:r}))}let W="",T,Be,q,de,Ve,E=new Ie;E.resolve();let D=0;const wt=r=>(xt((e,t)=>yt(Ve,e,t)),W=Be=r.sourceLocale,q=new Set(r.targetLocales),q.add(r.sourceLocale),de=r.loadLocale,{getLocale:Et,setLocale:kt}),Et=()=>W,kt=r=>{if(r===(T??W))return E.promise;if(!q||!de)throw new Error("Internal error");if(!q.has(r))throw new Error("Invalid locale code");D++;const e=D;return T=r,E.settled&&(E=new Ie),se({status:"loading",loadingLocale:r}),(r===Be?Promise.resolve({templates:void 0}):de(r)).then(n=>{D===e&&(W=r,T=void 0,Ve=n.templates,se({status:"ready",readyLocale:r}),E.resolve())},n=>{D===e&&(se({status:"error",errorLocale:r,errorMessage:n.toString()}),E.reject(n))}),E.promise};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let O=je,Le=!1;function xt(r){if(Le)throw new Error("lit-localize can only be configured once");O=r,Le=!0}const We=g`
  /* Brand Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm1) */
  --bkd-brand-white: rgba(255, 255, 255, 0.42);
  --bkd-brand-red: rgba(234, 22, 31, 1);
  --bkd-brand-black: rgba(0, 0, 0, 1);
  --bkd-brand-light-sand: rgba(252, 248, 243, 1);
  --bkd-brand-sand: rgba(250, 241, 227, 1);
  --bkd-brand-dark-sand: rgba(247, 233, 210, 1);
  --bkd-brand-sand-hover: rgba(242, 224, 195, 1);
  --bkd-brand-cappuchino: rgba(235, 211, 174, 1);

  /* Functional Foreground Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-fg-black: rgba(0, 0, 0, 1);
  --bkd-func-fg-grey: rgba(112, 112, 112, 1);
  --bkd-func-fg-light-grey: rgba(112, 112, 112, 0.68);
  --bkd-func-fg-white: rgba(255, 255, 255, 1);

  /* Functional Background Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-bg-anthrazit-hover: rgba(64, 64, 64, 1);
  --bkd-func-bg-anthrazit: rgba(78, 78, 78, 0.95);
  --bkd-func-bg-dark-grey: rgba(112, 112, 112, 1);
  --bkd-func-bg-line-grey: rgba(112, 112, 112, 0.5);
  --bkd-func-bg-grey: rgba(222, 222, 222, 1);
  --bkd-func-bg-light-grey: rgba(242, 242, 242, 1);
  --bkd-func-bg-very-light-grey: rgba(248, 248, 248, 1);
  --bkd-func-bg-white: rgba(255, 255, 255, 1);
  --bkd-func-bg-red: rgba(208, 16, 24, 1);
  --bkd-func-bg-green: rgba(61, 134, 8, 1);

  /* Component-specific Colors */
  --bkd-language-switcher-active-border: rgba(234, 22, 31, 0.77);
  --bkd-footer-border: rgba(238, 238, 238, 1);

  /* Fonts */
  --bkd-font-family: "Roboto", sans-serif;
  --bkd-font-size-base: 16px;
  --bkd-font-weight-base: 300;
  --bkd-line-height-base: 1.625;

  /* Spacings */
  --bkd-margin-horizontal-large: 40px;
  --bkd-margin-horizontal-medium: 30px;
  --bkd-margin-horizontal-small: 20px;
`,St=g`
  /* See https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm3 */

  /* Thin */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 100;
    src: url("/fonts/roboto-v30-latin-ext_latin-100.woff") format("woff");
  }

  /* Light */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 300;
    src: url("/fonts/roboto-v30-latin-ext_latin-300.woff") format("woff");
  }

  /* Regular */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: url("/fonts/roboto-v30-latin-ext_latin-400.woff") format("woff");
  }

  /* Medium */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: url("/fonts/roboto-v30-latin-ext_latin-500.woff") format("woff");
  }

  /* Bold */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: url("/fonts/roboto-v30-latin-ext_latin-700.woff") format("woff");
  }
`,A=g`
  :host {
    ${We}
    ${St}
  }

  /* Reset */
  :host,
  :host * {
    box-sizing: border-box;

    font-family: var(--bkd-font-family);
    font-size: var(--bkd-font-size-base);
    font-weight: var(--bkd-font-weight-base);
    line-height: var(--bkd-line-height-base);

    font-synthesis: none;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
  }
  img,
  svg {
    display: block;
  }
`;function Ct(r){var t;const e=document.createElement("style");e.innerText=r,(t=document.querySelector("body"))==null||t.appendChild(e)}var Pt=Object.defineProperty,Lt=Object.getOwnPropertyDescriptor,Ot=(r,e,t,n)=>{for(var i=n>1?void 0:n?Lt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Pt(e,t,i),i};let ce=class extends p{render(){return b` <main>${O("Willkommen bei Evento")}</main> `}};ce.styles=[A,g`
      /* Large screen */

      :host {
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        margin: 0 var(--bkd-header-margin-horizontal);
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];ce=Ot([_("bkd-content"),y()],ce);var zt=Object.defineProperty,Tt=Object.getOwnPropertyDescriptor,Rt=(r,e,t,n)=>{for(var i=n>1?void 0:n?Tt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&zt(e,t,i),i};let he=class extends p{render(){return b`
      <footer>
        <div class="copyright">${O("© Bildungs- und Kulturdirektion")}</div>
      </footer>
    `}};he.styles=[A,g`
      /* Large screen */

      :host {
        --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-large);
        --bkd-footer-padding-vertical: 18px;

        padding: var(--bkd-footer-padding-vertical)
          var(--bkd-footer-padding-horizontal);
        border-top: 1px solid var(--bkd-footer-border);
        background-color: var(--bkd-brand-light-sand);
        color: var(--bkd-func-fg-black);
      }

      .copyright {
        font-size: 0.8125rem;
        font-weight: 300;
        letter-spacing: 0.02rem;
        word-spacing: 0.05rem;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];he=Rt([_("bkd-footer"),y()],he);var Nt=Object.defineProperty,Ut=Object.getOwnPropertyDescriptor,qe=(r,e,t,n)=>{for(var i=n>1?void 0:n?Ut(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Nt(e,t,i),i};let F=class extends p{constructor(){super(),this.currentLocale="de"}render(){const r="Berufsbildungszentrum IDM Thun",e=`${O("Evento")} | ${r}`;return b`
      <header>
        <bkd-service-nav currentLocale=${this.currentLocale}></bkd-service-nav>
        <img class="logo" src="logo.svg" alt=${O("Evento Startseite")} />
        <div class="logo-caption">${e}</div>
        <bkd-main-nav></bkd-main-nav>
      </header>
    `}};F.styles=[A,g`
      /* Large screen */

      :host {
        --bkd-header-margin-top: 12px;
        --bkd-header-margin-bottom: calc(2 * var(--bkd-header-margin-top));
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        padding: var(--bkd-header-margin-top)
          var(--bkd-header-margin-horizontal) var(--bkd-header-margin-bottom)
          var(--bkd-header-margin-horizontal);
        border-bottom: 1px solid var(--bkd-func-bg-grey);
      }

      header {
        display: grid;
        grid-template-columns: max-content auto;
        grid-template-areas:
          "service-nav service-nav"
          "logo ."
          "logo-caption main-nav";
      }

      bkd-service-nav {
        grid-area: service-nav;
        justify-self: end;
      }

      .logo {
        grid-area: logo;
        width: 150px;
        font-size: 1rem;
        line-height: 1rem;
        letter-spacing: 0.01rem;
        word-spacing: 0.025rem;
        font-weight: 500;
        color: var(--bkd-func-fg-black);
      }

      .logo-caption {
        grid-area: logo-caption;
        align-self: baseline;
      }

      bkd-main-nav {
        grid-area: main-nav;
        align-self: baseline;
        justify-self: end;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }

        header {
          grid-template-areas:
            "logo service-nav"
            "logo-caption logo-caption";
        }

        bkd-service-nav {
          align-self: center;
        }

        .logo {
          width: 110px;
        }

        .logo-caption {
          margin-top: 12px;
          font-size: 0.75rem;
          line-height: 0.75rem;
        }

        bkd-main-nav {
          display: none;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }

        bkd-service-nav {
          align-self: start;
          margin-top: 2px; /* Align with logo text */
        }
      }
    `];qe([G()],F.prototype,"currentLocale",2);F=qe([_("bkd-header"),y()],F);var Ht=Object.defineProperty,Mt=Object.getOwnPropertyDescriptor,Fe=(r,e,t,n)=>{for(var i=n>1?void 0:n?Mt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Ht(e,t,i),i};let K=class extends p{constructor(){super(...arguments),this.open=!1}render(){const r=this.open?"/icons/close.svg":"/icons/hamburger.svg";return b`
      <button
        class="hamburger"
        aria-expanded=${this.open}
        aria-label=${O("Menü")}
      >
        <img src=${r} alt="Hamburger" width="32" height="32" />
      </button>
    `}};K.styles=[A,g`
      :host {
        display: flex;
      }

      button {
        background: transparent;
        border: none;
        cursor: pointer;
      }
    `];Fe([G()],K.prototype,"open",2);K=Fe([_("bkd-hamburger"),y()],K);const jt="de",Dt=["fr"],It=["de","fr"];/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Bt={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Vt=r=>(...e)=>({_$litDirective$:r,values:e});class Wt{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const qt=Vt(class extends Wt{constructor(r){var e;if(super(r),r.type!==Bt.ATTRIBUTE||r.name!=="class"||((e=r.strings)===null||e===void 0?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(r){return" "+Object.keys(r).filter(e=>r[e]).join(" ")+" "}update(r,[e]){var t,n;if(this.it===void 0){this.it=new Set,r.strings!==void 0&&(this.nt=new Set(r.strings.join(" ").split(/\s/).filter(s=>s!=="")));for(const s in e)e[s]&&!(!((t=this.nt)===null||t===void 0)&&t.has(s))&&this.it.add(s);return this.render(e)}const i=r.element.classList;this.it.forEach(s=>{s in e||(i.remove(s),this.it.delete(s))});for(const s in e){const o=!!e[s];o===this.it.has(s)||!((n=this.nt)===null||n===void 0)&&n.has(s)||(o?(i.add(s),this.it.add(s)):(i.remove(s),this.it.delete(s)))}return S}});var Ft=Object.defineProperty,Kt=Object.getOwnPropertyDescriptor,Ke=(r,e,t,n)=>{for(var i=n>1?void 0:n?Kt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Ft(e,t,i),i};let X=class extends p{constructor(){super(...arguments),this.currentLocale="de"}handleLocaleChange(r,e){r.preventDefault(),this.dispatchEvent(new CustomEvent("bkdlocalechange",{bubbles:!0,composed:!0,detail:{locale:e}}))}render(){return b`<ul>
      ${It.map(r=>b`<li>
            <a
              href="#"
              class=${qt({active:r===this.currentLocale})}
              aria-current=${r===this.currentLocale}
              @click=${e=>this.handleLocaleChange(e,r)}
            >
              ${r}
            </a>
          </li>`)}
    </ul>`}};X.styles=[A,g`
      :host {
        font-size: 0.875rem;
      }

      ul {
        display: flex;
        align-items: baseline;
        margin: 0;
        padding: 0;
        list-style: none;
      }

      li {
        display: flex;
        align-items: baseline;
        margin-left: 0.75rem;
      }

      li + li:before {
        content: "|";
        margin-right: 0.75rem;
      }

      a {
        display: block;
        letter-spacing: 0.025rem;
        text-decoration: none;
        text-transform: uppercase;
        color: var(--bkd-func-fg-black);
      }

      a:after {
        display: block;
        content: "";
        border-bottom: 2px solid var(--bkd-func-fg-black);
        transform: scaleX(0);
        transition: transform 100ms ease-in-out;
      }

      a.active {
        border-bottom: 2px solid var(--bkd-language-switcher-active-border);
      }

      a:hover::after,
      a:focus::after,
      a:active::after {
        transform: scaleX(1);
      }

      a.active:hover::after,
      a.active:focus::after,
      a.active:active::after {
        transform: scaleX(0);
      }
    `];Ke([G()],X.prototype,"currentLocale",2);X=Ke([_("bkd-language-switcher"),y()],X);var Xt=Object.defineProperty,Jt=Object.getOwnPropertyDescriptor,Zt=(r,e,t,n)=>{for(var i=n>1?void 0:n?Jt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Xt(e,t,i),i};let ue=class extends p{render(){return b` <span style="font-size: 2rem">main nav</span> `}};ue.styles=[A,g`
      :host {
        background-color: salmon;
      }
    `];ue=Zt([_("bkd-main-nav"),y()],ue);var Gt=Object.defineProperty,Yt=Object.getOwnPropertyDescriptor,Xe=(r,e,t,n)=>{for(var i=n>1?void 0:n?Yt(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&Gt(e,t,i),i};let J=class extends p{constructor(){super(...arguments),this.currentLocale="de"}render(){return b`
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <div
        style="background: #000; border-radius: 50%; width: 32px; height: 32px;"
      ></div>
      <bkd-language-switcher
        currentLocale=${this.currentLocale}
      ></bkd-language-switcher>
      <bkd-hamburger></bkd-hamburger>
    `}};J.styles=[A,g`
      /* Large screen */

      :host {
        display: flex;
        align-items: center;
        gap: 2.5rem;
        margin-left: 1rem;
      }

      bkd-hamburger {
        display: none;
      }

      /* Medium screen */

      @media screen and (max-width: 1200px) {
        bkd-language-switcher {
          display: none;
        }

        bkd-hamburger {
          display: inherit;
        }
      }

      /* Small screen */

      @media screen and (max-width: 767px) {
        :host {
          gap: 1.5rem;
        }
      }
    `];Xe([G()],J.prototype,"currentLocale",2);J=Xe([_("bkd-service-nav"),y()],J);const Qt="modulepreload",er=function(r){return"/"+r},Oe={},tr=function(e,t,n){if(!t||t.length===0)return e();const i=document.getElementsByTagName("link");return Promise.all(t.map(s=>{if(s=er(s),s in Oe)return;Oe[s]=!0;const o=s.endsWith(".css"),c=o?'[rel="stylesheet"]':"";if(!!n)for(let f=i.length-1;f>=0;f--){const d=i[f];if(d.href===s&&(!o||d.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${s}"]${c}`))return;const a=document.createElement("link");if(a.rel=o?"stylesheet":Qt,o||(a.as="script",a.crossOrigin=""),a.href=s,document.head.appendChild(a),o)return new Promise((f,d)=>{a.addEventListener("load",f),a.addEventListener("error",()=>d(new Error(`Unable to preload CSS for ${s}`)))})})).then(()=>e())};var rr=Object.defineProperty,nr=Object.getOwnPropertyDescriptor,ir=(r,e,t,n)=>{for(var i=n>1?void 0:n?nr(e,t):e,s=r.length-1,o;s>=0;s--)(o=r[s])&&(i=(n?o(e,t,i):o(i))||i);return n&&i&&rr(e,t,i),i};Ct(g`
    :root {
      ${We}
    }
  `.toString());const{getLocale:ze,setLocale:sr}=wt({sourceLocale:jt,targetLocales:Dt,loadLocale:r=>tr(()=>import(`/locales/${r}.js`),[])});let fe=class extends p{constructor(){super(),this.updateDocumentLang(ze())}handleLocaleChange(r){const e=r.detail.locale;sr(e),this.updateDocumentLang(e)}updateDocumentLang(r){document.documentElement.lang=r}render(){return b`
      <bkd-header
        currentLocale=${ze()}
        @bkdlocalechange=${this.handleLocaleChange.bind(this)}
      ></bkd-header>
      <bkd-content></bkd-content>
      <bkd-footer></bkd-footer>
    `}};fe.styles=[A,g`
      :host {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        width: 100%;
        max-width: 1920px;
        margin: 0 auto;
      }

      bkd-content {
        flex: auto;
      }
    `];fe=ir([_("bkd-portal"),y()],fe);
