(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))s(n);new MutationObserver(n=>{for(const o of n)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&s(r)}).observe(document,{childList:!0,subtree:!0});function e(n){const o={};return n.integrity&&(o.integrity=n.integrity),n.referrerPolicy&&(o.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?o.credentials="include":n.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function s(n){if(n.ep)return;n.ep=!0;const o=e(n);fetch(n.href,o)}})();/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const U=window,at=U.ShadowRoot&&(U.ShadyCSS===void 0||U.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,dt=Symbol(),ht=new WeakMap;let kt=class{constructor(t,e,s){if(this._$cssResult$=!0,s!==dt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(at&&t===void 0){const s=e!==void 0&&e.length===1;s&&(t=ht.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),s&&ht.set(e,t))}return t}toString(){return this.cssText}};const Mt=i=>new kt(typeof i=="string"?i:i+"",void 0,dt),A=(i,...t)=>{const e=i.length===1?i[0]:t.reduce((s,n,o)=>s+(r=>{if(r._$cssResult$===!0)return r.cssText;if(typeof r=="number")return r;throw Error("Value passed to 'css' function must be a 'css' function result: "+r+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(n)+i[o+1],i[0]);return new kt(e,i,dt)},jt=(i,t)=>{at?i.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet):t.forEach(e=>{const s=document.createElement("style"),n=U.litNonce;n!==void 0&&s.setAttribute("nonce",n),s.textContent=e.cssText,i.appendChild(s)})},ct=at?i=>i:i=>i instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return Mt(e)})(i):i;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var q;const N=window,ut=N.trustedTypes,It=ut?ut.emptyScript:"",ft=N.reactiveElementPolyfillSupport,tt={toAttribute(i,t){switch(t){case Boolean:i=i?It:null;break;case Object:case Array:i=i==null?i:JSON.stringify(i)}return i},fromAttribute(i,t){let e=i;switch(t){case Boolean:e=i!==null;break;case Number:e=i===null?null:Number(i);break;case Object:case Array:try{e=JSON.parse(i)}catch{e=null}}return e}},xt=(i,t)=>t!==i&&(t==t||i==i),K={attribute:!0,type:String,converter:tt,reflect:!1,hasChanged:xt};let E=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this.u()}static addInitializer(t){var e;this.finalize(),((e=this.h)!==null&&e!==void 0?e:this.h=[]).push(t)}static get observedAttributes(){this.finalize();const t=[];return this.elementProperties.forEach((e,s)=>{const n=this._$Ep(s,e);n!==void 0&&(this._$Ev.set(n,s),t.push(n))}),t}static createProperty(t,e=K){if(e.state&&(e.attribute=!1),this.finalize(),this.elementProperties.set(t,e),!e.noAccessor&&!this.prototype.hasOwnProperty(t)){const s=typeof t=="symbol"?Symbol():"__"+t,n=this.getPropertyDescriptor(t,s,e);n!==void 0&&Object.defineProperty(this.prototype,t,n)}}static getPropertyDescriptor(t,e,s){return{get(){return this[e]},set(n){const o=this[t];this[e]=n,this.requestUpdate(t,o,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)||K}static finalize(){if(this.hasOwnProperty("finalized"))return!1;this.finalized=!0;const t=Object.getPrototypeOf(this);if(t.finalize(),t.h!==void 0&&(this.h=[...t.h]),this.elementProperties=new Map(t.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const e=this.properties,s=[...Object.getOwnPropertyNames(e),...Object.getOwnPropertySymbols(e)];for(const n of s)this.createProperty(n,e[n])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const s=new Set(t.flat(1/0).reverse());for(const n of s)e.unshift(ct(n))}else t!==void 0&&e.push(ct(t));return e}static _$Ep(t,e){const s=e.attribute;return s===!1?void 0:typeof s=="string"?s:typeof t=="string"?t.toLowerCase():void 0}u(){var t;this._$E_=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$Eg(),this.requestUpdate(),(t=this.constructor.h)===null||t===void 0||t.forEach(e=>e(this))}addController(t){var e,s;((e=this._$ES)!==null&&e!==void 0?e:this._$ES=[]).push(t),this.renderRoot!==void 0&&this.isConnected&&((s=t.hostConnected)===null||s===void 0||s.call(t))}removeController(t){var e;(e=this._$ES)===null||e===void 0||e.splice(this._$ES.indexOf(t)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((t,e)=>{this.hasOwnProperty(e)&&(this._$Ei.set(e,this[e]),delete this[e])})}createRenderRoot(){var t;const e=(t=this.shadowRoot)!==null&&t!==void 0?t:this.attachShadow(this.constructor.shadowRootOptions);return jt(e,this.constructor.elementStyles),e}connectedCallback(){var t;this.renderRoot===void 0&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(t=this._$ES)===null||t===void 0||t.forEach(e=>{var s;return(s=e.hostConnected)===null||s===void 0?void 0:s.call(e)})}enableUpdating(t){}disconnectedCallback(){var t;(t=this._$ES)===null||t===void 0||t.forEach(e=>{var s;return(s=e.hostDisconnected)===null||s===void 0?void 0:s.call(e)})}attributeChangedCallback(t,e,s){this._$AK(t,s)}_$EO(t,e,s=K){var n;const o=this.constructor._$Ep(t,s);if(o!==void 0&&s.reflect===!0){const r=(((n=s.converter)===null||n===void 0?void 0:n.toAttribute)!==void 0?s.converter:tt).toAttribute(e,s.type);this._$El=t,r==null?this.removeAttribute(o):this.setAttribute(o,r),this._$El=null}}_$AK(t,e){var s;const n=this.constructor,o=n._$Ev.get(t);if(o!==void 0&&this._$El!==o){const r=n.getPropertyOptions(o),h=typeof r.converter=="function"?{fromAttribute:r.converter}:((s=r.converter)===null||s===void 0?void 0:s.fromAttribute)!==void 0?r.converter:tt;this._$El=o,this[o]=h.fromAttribute(e,r.type),this._$El=null}}requestUpdate(t,e,s){let n=!0;t!==void 0&&(((s=s||this.constructor.getPropertyOptions(t)).hasChanged||xt)(this[t],e)?(this._$AL.has(t)||this._$AL.set(t,e),s.reflect===!0&&this._$El!==t&&(this._$EC===void 0&&(this._$EC=new Map),this._$EC.set(t,s))):n=!1),!this.isUpdatePending&&n&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var t;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((n,o)=>this[o]=n),this._$Ei=void 0);let e=!1;const s=this._$AL;try{e=this.shouldUpdate(s),e?(this.willUpdate(s),(t=this._$ES)===null||t===void 0||t.forEach(n=>{var o;return(o=n.hostUpdate)===null||o===void 0?void 0:o.call(n)}),this.update(s)):this._$Ek()}catch(n){throw e=!1,this._$Ek(),n}e&&this._$AE(s)}willUpdate(t){}_$AE(t){var e;(e=this._$ES)===null||e===void 0||e.forEach(s=>{var n;return(n=s.hostUpdated)===null||n===void 0?void 0:n.call(s)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(t){return!0}update(t){this._$EC!==void 0&&(this._$EC.forEach((e,s)=>this._$EO(s,this[s],e)),this._$EC=void 0),this._$Ek()}updated(t){}firstUpdated(t){}};E.finalized=!0,E.elementProperties=new Map,E.elementStyles=[],E.shadowRootOptions={mode:"open"},ft==null||ft({ReactiveElement:E}),((q=N.reactiveElementVersions)!==null&&q!==void 0?q:N.reactiveElementVersions=[]).push("1.6.1");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var J;const M=window,w=M.trustedTypes,pt=w?w.createPolicy("lit-html",{createHTML:i=>i}):void 0,et="$lit$",g=`lit$${(Math.random()+"").slice(9)}$`,Ct="?"+g,Bt=`<${Ct}>`,y=document,P=()=>y.createComment(""),z=i=>i===null||typeof i!="object"&&typeof i!="function",Pt=Array.isArray,Dt=i=>Pt(i)||typeof(i==null?void 0:i[Symbol.iterator])=="function",X=`[ 	
\f\r]`,x=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,vt=/-->/g,gt=/>/g,m=RegExp(`>|${X}(?:([^\\s"'>=/]+)(${X}*=${X}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),$t=/'/g,mt=/"/g,zt=/^(?:script|style|textarea|title)$/i,Vt=i=>(t,...e)=>({_$litType$:i,strings:t,values:e}),B=Vt(1),S=Symbol.for("lit-noChange"),u=Symbol.for("lit-nothing"),bt=new WeakMap,_=y.createTreeWalker(y,129,null,!1),Wt=(i,t)=>{const e=i.length-1,s=[];let n,o=t===2?"<svg>":"",r=x;for(let a=0;a<e;a++){const l=i[a];let f,d,c=-1,p=0;for(;p<l.length&&(r.lastIndex=p,d=r.exec(l),d!==null);)p=r.lastIndex,r===x?d[1]==="!--"?r=vt:d[1]!==void 0?r=gt:d[2]!==void 0?(zt.test(d[2])&&(n=RegExp("</"+d[2],"g")),r=m):d[3]!==void 0&&(r=m):r===m?d[0]===">"?(r=n??x,c=-1):d[1]===void 0?c=-2:(c=r.lastIndex-d[2].length,f=d[1],r=d[3]===void 0?m:d[3]==='"'?mt:$t):r===mt||r===$t?r=m:r===vt||r===gt?r=x:(r=m,n=void 0);const T=r===m&&i[a+1].startsWith("/>")?" ":"";o+=r===x?l+Bt:c>=0?(s.push(f),l.slice(0,c)+et+l.slice(c)+g+T):l+g+(c===-2?(s.push(void 0),a):T)}const h=o+(i[e]||"<?>")+(t===2?"</svg>":"");if(!Array.isArray(i)||!i.hasOwnProperty("raw"))throw Error("invalid template strings array");return[pt!==void 0?pt.createHTML(h):h,s]};class O{constructor({strings:t,_$litType$:e},s){let n;this.parts=[];let o=0,r=0;const h=t.length-1,a=this.parts,[l,f]=Wt(t,e);if(this.el=O.createElement(l,s),_.currentNode=this.el.content,e===2){const d=this.el.content,c=d.firstChild;c.remove(),d.append(...c.childNodes)}for(;(n=_.nextNode())!==null&&a.length<h;){if(n.nodeType===1){if(n.hasAttributes()){const d=[];for(const c of n.getAttributeNames())if(c.endsWith(et)||c.startsWith(g)){const p=f[r++];if(d.push(c),p!==void 0){const T=n.getAttribute(p.toLowerCase()+et).split(g),R=/([.?@])?(.*)/.exec(p);a.push({type:1,index:o,name:R[2],strings:T,ctor:R[1]==="."?qt:R[1]==="?"?Jt:R[1]==="@"?Xt:D})}else a.push({type:6,index:o})}for(const c of d)n.removeAttribute(c)}if(zt.test(n.tagName)){const d=n.textContent.split(g),c=d.length-1;if(c>0){n.textContent=w?w.emptyScript:"";for(let p=0;p<c;p++)n.append(d[p],P()),_.nextNode(),a.push({type:2,index:++o});n.append(d[c],P())}}}else if(n.nodeType===8)if(n.data===Ct)a.push({type:2,index:o});else{let d=-1;for(;(d=n.data.indexOf(g,d+1))!==-1;)a.push({type:7,index:o}),d+=g.length-1}o++}}static createElement(t,e){const s=y.createElement("template");return s.innerHTML=t,s}}function k(i,t,e=i,s){var n,o,r,h;if(t===S)return t;let a=s!==void 0?(n=e._$Co)===null||n===void 0?void 0:n[s]:e._$Cl;const l=z(t)?void 0:t._$litDirective$;return(a==null?void 0:a.constructor)!==l&&((o=a==null?void 0:a._$AO)===null||o===void 0||o.call(a,!1),l===void 0?a=void 0:(a=new l(i),a._$AT(i,e,s)),s!==void 0?((r=(h=e)._$Co)!==null&&r!==void 0?r:h._$Co=[])[s]=a:e._$Cl=a),a!==void 0&&(t=k(i,a._$AS(i,t.values),a,s)),t}class Ft{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){var e;const{el:{content:s},parts:n}=this._$AD,o=((e=t==null?void 0:t.creationScope)!==null&&e!==void 0?e:y).importNode(s,!0);_.currentNode=o;let r=_.nextNode(),h=0,a=0,l=n[0];for(;l!==void 0;){if(h===l.index){let f;l.type===2?f=new L(r,r.nextSibling,this,t):l.type===1?f=new l.ctor(r,l.name,l.strings,this,t):l.type===6&&(f=new Zt(r,this,t)),this._$AV.push(f),l=n[++a]}h!==(l==null?void 0:l.index)&&(r=_.nextNode(),h++)}return _.currentNode=y,o}v(t){let e=0;for(const s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(t,s,e),e+=s.strings.length-2):s._$AI(t[e])),e++}}class L{constructor(t,e,s,n){var o;this.type=2,this._$AH=u,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=s,this.options=n,this._$Cp=(o=n==null?void 0:n.isConnected)===null||o===void 0||o}get _$AU(){var t,e;return(e=(t=this._$AM)===null||t===void 0?void 0:t._$AU)!==null&&e!==void 0?e:this._$Cp}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&(t==null?void 0:t.nodeType)===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=k(this,t,e),z(t)?t===u||t==null||t===""?(this._$AH!==u&&this._$AR(),this._$AH=u):t!==this._$AH&&t!==S&&this._(t):t._$litType$!==void 0?this.g(t):t.nodeType!==void 0?this.$(t):Dt(t)?this.T(t):this._(t)}k(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}$(t){this._$AH!==t&&(this._$AR(),this._$AH=this.k(t))}_(t){this._$AH!==u&&z(this._$AH)?this._$AA.nextSibling.data=t:this.$(y.createTextNode(t)),this._$AH=t}g(t){var e;const{values:s,_$litType$:n}=t,o=typeof n=="number"?this._$AC(t):(n.el===void 0&&(n.el=O.createElement(n.h,this.options)),n);if(((e=this._$AH)===null||e===void 0?void 0:e._$AD)===o)this._$AH.v(s);else{const r=new Ft(o,this),h=r.u(this.options);r.v(s),this.$(h),this._$AH=r}}_$AC(t){let e=bt.get(t.strings);return e===void 0&&bt.set(t.strings,e=new O(t)),e}T(t){Pt(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let s,n=0;for(const o of t)n===e.length?e.push(s=new L(this.k(P()),this.k(P()),this,this.options)):s=e[n],s._$AI(o),n++;n<e.length&&(this._$AR(s&&s._$AB.nextSibling,n),e.length=n)}_$AR(t=this._$AA.nextSibling,e){var s;for((s=this._$AP)===null||s===void 0||s.call(this,!1,!0,e);t&&t!==this._$AB;){const n=t.nextSibling;t.remove(),t=n}}setConnected(t){var e;this._$AM===void 0&&(this._$Cp=t,(e=this._$AP)===null||e===void 0||e.call(this,t))}}class D{constructor(t,e,s,n,o){this.type=1,this._$AH=u,this._$AN=void 0,this.element=t,this.name=e,this._$AM=n,this.options=o,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=u}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(t,e=this,s,n){const o=this.strings;let r=!1;if(o===void 0)t=k(this,t,e,0),r=!z(t)||t!==this._$AH&&t!==S,r&&(this._$AH=t);else{const h=t;let a,l;for(t=o[0],a=0;a<o.length-1;a++)l=k(this,h[s+a],e,a),l===S&&(l=this._$AH[a]),r||(r=!z(l)||l!==this._$AH[a]),l===u?t=u:t!==u&&(t+=(l??"")+o[a+1]),this._$AH[a]=l}r&&!n&&this.j(t)}j(t){t===u?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class qt extends D{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===u?void 0:t}}const Kt=w?w.emptyScript:"";class Jt extends D{constructor(){super(...arguments),this.type=4}j(t){t&&t!==u?this.element.setAttribute(this.name,Kt):this.element.removeAttribute(this.name)}}class Xt extends D{constructor(t,e,s,n,o){super(t,e,s,n,o),this.type=5}_$AI(t,e=this){var s;if((t=(s=k(this,t,e,0))!==null&&s!==void 0?s:u)===S)return;const n=this._$AH,o=t===u&&n!==u||t.capture!==n.capture||t.once!==n.once||t.passive!==n.passive,r=t!==u&&(n===u||o);o&&this.element.removeEventListener(this.name,this,n),r&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){var e,s;typeof this._$AH=="function"?this._$AH.call((s=(e=this.options)===null||e===void 0?void 0:e.host)!==null&&s!==void 0?s:this.element,t):this._$AH.handleEvent(t)}}class Zt{constructor(t,e,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){k(this,t)}}const _t=M.litHtmlPolyfillSupport;_t==null||_t(O,L),((J=M.litHtmlVersions)!==null&&J!==void 0?J:M.litHtmlVersions=[]).push("2.7.4");const Gt=(i,t,e)=>{var s,n;const o=(s=e==null?void 0:e.renderBefore)!==null&&s!==void 0?s:t;let r=o._$litPart$;if(r===void 0){const h=(n=e==null?void 0:e.renderBefore)!==null&&n!==void 0?n:null;o._$litPart$=r=new L(t.insertBefore(P(),h),h,void 0,e??{})}return r._$AI(i),r};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Z,G;class $ extends E{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var t,e;const s=super.createRenderRoot();return(t=(e=this.renderOptions).renderBefore)!==null&&t!==void 0||(e.renderBefore=s.firstChild),s}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=Gt(e,this.renderRoot,this.renderOptions)}connectedCallback(){var t;super.connectedCallback(),(t=this._$Do)===null||t===void 0||t.setConnected(!0)}disconnectedCallback(){var t;super.disconnectedCallback(),(t=this._$Do)===null||t===void 0||t.setConnected(!1)}render(){return S}}$.finalized=!0,$._$litElement$=!0,(Z=globalThis.litElementHydrateSupport)===null||Z===void 0||Z.call(globalThis,{LitElement:$});const yt=globalThis.litElementPolyfillSupport;yt==null||yt({LitElement:$});((G=globalThis.litElementVersions)!==null&&G!==void 0?G:globalThis.litElementVersions=[]).push("3.3.2");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const V=i=>t=>typeof t=="function"?((e,s)=>(customElements.define(e,s),s))(i,t):((e,s)=>{const{kind:n,elements:o}=s;return{kind:n,elements:o,finisher(r){customElements.define(e,r)}}})(i,t);/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Q;((Q=window.HTMLSlotElement)===null||Q===void 0?void 0:Q.prototype.assignedElements)!=null;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Qt=i=>typeof i!="string"&&"strTag"in i,Ot=(i,t,e)=>{let s=i[0];for(let n=1;n<i.length;n++)s+=t[e?e[n-1]:n-1],s+=i[n];return s};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Lt=i=>Qt(i)?Ot(i.strings,i.values):i;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const st="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Yt{constructor(t){this.__litLocalizeEventHandler=e=>{e.detail.status==="ready"&&this.host.requestUpdate()},this.host=t}hostConnected(){window.addEventListener(st,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(st,this.__litLocalizeEventHandler)}}const te=i=>i.addController(new Yt(i)),Tt=te;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ee=()=>i=>typeof i=="function"?ne(i):se(i),W=ee,se=({kind:i,elements:t})=>({kind:i,elements:t,finisher(e){e.addInitializer(Tt)}}),ne=i=>(i.addInitializer(Tt),i);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Rt{constructor(){this.settled=!1,this.promise=new Promise((t,e)=>{this._resolve=t,this._reject=e})}resolve(t){this.settled=!0,this._resolve(t)}reject(t){this.settled=!0,this._reject(t)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */const v=[];for(let i=0;i<256;i++)v[i]=(i>>4&15).toString(16)+(i&15).toString(16);function ie(i){let t=0,e=8997,s=0,n=33826,o=0,r=40164,h=0,a=52210;for(let l=0;l<i.length;l++)e^=i.charCodeAt(l),t=e*435,s=n*435,o=r*435,h=a*435,o+=e<<8,h+=n<<8,s+=t>>>16,e=t&65535,o+=s>>>16,n=s&65535,a=h+(o>>>16)&65535,r=o&65535;return v[a>>8]+v[a&255]+v[r>>8]+v[r&255]+v[n>>8]+v[n&255]+v[e>>8]+v[e&255]}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const oe="",re="h",le="s";function ae(i,t){return(t?re:le)+ie(typeof i=="string"?i:i.join(oe))}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const At=new WeakMap,Et=new Map;function de(i,t,e){var s;if(i){const n=(s=e==null?void 0:e.id)!==null&&s!==void 0?s:he(t),o=i[n];if(o){if(typeof o=="string")return o;if("strTag"in o)return Ot(o.strings,t.values,o.values);{let r=At.get(o);return r===void 0&&(r=o.values,At.set(o,r)),{...o,values:r.map(h=>t.values[h])}}}}return Lt(t)}function he(i){const t=typeof i=="string"?i:i.strings;let e=Et.get(t);return e===void 0&&(e=ae(t,typeof i!="string"&&!("strTag"in i)),Et.set(t,e)),e}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Y(i){window.dispatchEvent(new CustomEvent(st,{detail:i}))}let j="",C,Ht,I,nt,Ut,b=new Rt;b.resolve();let H=0;const ce=i=>(pe((t,e)=>de(Ut,t,e)),j=Ht=i.sourceLocale,I=new Set(i.targetLocales),I.add(i.sourceLocale),nt=i.loadLocale,{getLocale:ue,setLocale:fe}),ue=()=>j,fe=i=>{if(i===(C??j))return b.promise;if(!I||!nt)throw new Error("Internal error");if(!I.has(i))throw new Error("Invalid locale code");H++;const t=H;return C=i,b.settled&&(b=new Rt),Y({status:"loading",loadingLocale:i}),(i===Ht?Promise.resolve({templates:void 0}):nt(i)).then(s=>{H===t&&(j=i,C=void 0,Ut=s.templates,Y({status:"ready",readyLocale:i}),b.resolve())},s=>{H===t&&(Y({status:"error",errorLocale:i,errorMessage:s.toString()}),b.reject(s))}),b.promise};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Nt=Lt,wt=!1;function pe(i){if(wt)throw new Error("lit-localize can only be configured once");Nt=i,wt=!0}const ve=A`
  /* Brand Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm1) */
  --bkd-brand-white: rgba(255, 255, 255, 0.42);
  --bkd-brand-red: rgba(234, 22, 31, 1);
  --bkd-brand-black: rgba(0, 0, 0, 1);
  --bkd-brand-light-sand: rgba(252, 248, 243, 1);
  --bkd-brand-sand: rgba(250, 241, 227, 1);
  --bkd-brand-dark-sand: rgba(247, 233, 210, 1);
  --bkd-brand-sand-hover: rgba(242, 224, 195, 1);
  --bkd-brand-cappuchino: rgba(235, 211, 174, 1);

  /* Functional Foreground Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-fg-black: rgba(0, 0, 0, 1);
  --bkd-func-fg-grey: rgba(112, 112, 112, 1);
  --bkd-func-fg-light-grey: rgba(112, 112, 112, 0.68);
  --bkd-func-fg-white: rgba(255, 255, 255, 1);

  /* Functional Background Colors (https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm2) */
  --bkd-func-bg-anthrazit-hover: rgba(64, 64, 64, 1);
  --bkd-func-bg-anthrazit: rgba(78, 78, 78, 0.95);
  --bkd-func-bg-dark-grey: rgba(112, 112, 112, 1);
  --bkd-func-bg-line-grey: rgba(112, 112, 112, 0.5);
  --bkd-func-bg-grey: rgba(222, 222, 222, 1);
  --bkd-func-bg-light-grey: rgba(242, 242, 242, 1);
  --bkd-func-bg-very-light-grey: rgba(248, 248, 248, 1);
  --bkd-func-bg-white: rgba(255, 255, 255, 1);
  --bkd-func-bg-red: rgba(208, 16, 24, 1);
  --bkd-func-bg-green: rgba(61, 134, 8, 1);

  /* Fonts */
  --bkd-font-family: "Roboto", sans-serif;
  --bkd-font-size-base: 16px;
  --bkd-font-weight-base: 300;
  --bkd-line-height-base: 1.625;

  /* Spacings */
  --bkd-margin-horizontal-large: 40px;
  --bkd-margin-horizontal-medium: 30px;
  --bkd-margin-horizontal-small: 20px;
`,ge=A`
  /* See https://kantonbern.snowflake.ch/styleguides/1/Kanton-Bern/#Sm3 */

  /* Thin */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 100;
    src: url("/fonts/roboto-v30-latin-ext_latin-100.woff") format("woff");
  }

  /* Light */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 300;
    src: url("/fonts/roboto-v30-latin-ext_latin-300.woff") format("woff");
  }

  /* Regular */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    src: url("/fonts/roboto-v30-latin-ext_latin-400.woff") format("woff");
  }

  /* Medium */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    src: url("/fonts/roboto-v30-latin-ext_latin-500.woff") format("woff");
  }

  /* Bold */
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 700;
    src: url("/fonts/roboto-v30-latin-ext_latin-700.woff") format("woff");
  }
`,F=A`
  :host {
    ${ve}
    ${ge}
  }

  /* Reset */
  :host,
  :host * {
    box-sizing: border-box;

    font-family: var(--bkd-font-family);
    font-size: var(--bkd-font-size-base);
    font-weight: var(--bkd-font-weight-base);
    line-height: var(--bkd-line-height-base);

    font-synthesis: none;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
  }
  img,
  svg {
    display: block;
  }
`;var $e=Object.defineProperty,me=Object.getOwnPropertyDescriptor,be=(i,t,e,s)=>{for(var n=s>1?void 0:s?me(t,e):t,o=i.length-1,r;o>=0;o--)(r=i[o])&&(n=(s?r(t,e,n):r(n))||n);return s&&n&&$e(t,e,n),n};let it=class extends ${render(){return B` <main>content</main> `}};it.styles=[F,A`
      :host {
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        margin: 0 var(--bkd-header-margin-horizontal);
      }

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];it=be([V("bkd-content"),W()],it);var _e=Object.defineProperty,ye=Object.getOwnPropertyDescriptor,Ae=(i,t,e,s)=>{for(var n=s>1?void 0:s?ye(t,e):t,o=i.length-1,r;o>=0;o--)(r=i[o])&&(n=(s?r(t,e,n):r(n))||n);return s&&n&&_e(t,e,n),n};let ot=class extends ${render(){return B` <footer>footer</footer> `}};ot.styles=[F,A`
      :host {
        --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-large);
        --bkd-footer-padding-vertical: 18px;

        padding: var(--bkd-footer-padding-vertical)
          var(--bkd-footer-padding-horizontal);
        border-top: 1px solid rgba(238, 238, 238, 1);
        background-color: var(--bkd-brand-light-sand);
      }

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      @media screen and (max-width: 767px) {
        :host {
          --bkd-footer-padding-horizontal: var(--bkd-margin-horizontal-small);
        }
      }
    `];ot=Ae([V("bkd-footer"),W()],ot);var Ee=Object.defineProperty,we=Object.getOwnPropertyDescriptor,Se=(i,t,e,s)=>{for(var n=s>1?void 0:s?we(t,e):t,o=i.length-1,r;o>=0;o--)(r=i[o])&&(n=(s?r(t,e,n):r(n))||n);return s&&n&&Ee(t,e,n),n};let rt=class extends ${render(){return B`
      <header>
        <img class="logo" src="logo.svg" />
        <div class="logo-caption">
          ${Nt("Evento")} | Berufsbildungszentrum IDM Thun
        </div>
      </header>
    `}};rt.styles=[F,A`
      :host {
        --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-large);

        margin: 0 var(--bkd-header-margin-horizontal);
        border-bottom: 1px solid var(--bkd-func-bg-grey);
      }

      @media screen and (max-width: 1200px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-medium);
        }
      }

      @media screen and (max-width: 767px) {
        :host {
          --bkd-header-margin-horizontal: var(--bkd-margin-horizontal-small);
        }
      }

      .logo {
        width: 150px;
      }
    `];rt=Se([V("bkd-header"),W()],rt);const ke="modulepreload",xe=function(i){return"/"+i},St={},Ce=function(t,e,s){if(!e||e.length===0)return t();const n=document.getElementsByTagName("link");return Promise.all(e.map(o=>{if(o=xe(o),o in St)return;St[o]=!0;const r=o.endsWith(".css"),h=r?'[rel="stylesheet"]':"";if(!!s)for(let f=n.length-1;f>=0;f--){const d=n[f];if(d.href===o&&(!r||d.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${o}"]${h}`))return;const l=document.createElement("link");if(l.rel=r?"stylesheet":ke,r||(l.as="script",l.crossOrigin=""),l.href=o,document.head.appendChild(l),r)return new Promise((f,d)=>{l.addEventListener("load",f),l.addEventListener("error",()=>d(new Error(`Unable to preload CSS for ${o}`)))})})).then(()=>t())},Pe="de",ze=["fr"];var Oe=Object.defineProperty,Le=Object.getOwnPropertyDescriptor,Te=(i,t,e,s)=>{for(var n=s>1?void 0:s?Le(t,e):t,o=i.length-1,r;o>=0;o--)(r=i[o])&&(n=(s?r(t,e,n):r(n))||n);return s&&n&&Oe(t,e,n),n};ce({sourceLocale:Pe,targetLocales:ze,loadLocale:i=>Ce(()=>import(`/locales/${i}.js`),[])});let lt=class extends ${render(){return B`
      <bkd-header></bkd-header>
      <bkd-content></bkd-content>
      <bkd-footer></bkd-footer>
    `}};lt.styles=[F,A`
      :host {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        width: 100%;
        max-width: 1920px;
        margin: 0 auto;
      }

      bkd-content {
        flex: auto;
      }
    `];lt=Te([V("bkd-portal"),W()],lt);
