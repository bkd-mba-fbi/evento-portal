﻿define([
    'main_settings',
    'constants'
], function (mainSettings, constants) {
    var settings = {
        // module specific settings
    };
    settings.__proto__ = mainSettings;
    return settings;
});