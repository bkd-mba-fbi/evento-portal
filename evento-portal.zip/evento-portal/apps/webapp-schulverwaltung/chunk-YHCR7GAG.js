var e=class extends Error{constructor(o,t){super(`TypeScript thought we could never end up here
${t}`)}};export{e as a};
