import{Cc as t,Dc as n,Ic as o,Kc as r}from"./chunk-IFJN5CDK.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
