import{Ac as n,Fc as o,Hc as r,zc as t}from"./chunk-XTHSYQMN.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
