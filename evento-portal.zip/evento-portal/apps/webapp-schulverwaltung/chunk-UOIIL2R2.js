import{i as o,j as a}from"./chunk-RXV77OBQ.js";function c(e,r,i){let t=a(e,i?.in);return isNaN(r)?o(i?.in||e,NaN):(r&&t.setDate(t.getDate()+r),t)}export{c as a};
