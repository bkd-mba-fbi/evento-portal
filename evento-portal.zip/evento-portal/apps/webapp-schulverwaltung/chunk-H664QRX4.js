import{Mc as t,Nc as n,Sc as o,Uc as r}from"./chunk-NEW5VGRB.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
