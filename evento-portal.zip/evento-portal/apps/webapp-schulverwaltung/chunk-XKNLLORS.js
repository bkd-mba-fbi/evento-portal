import{Ic as t,Jc as n,Oc as o,Qc as r}from"./chunk-S3H6YSFW.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
