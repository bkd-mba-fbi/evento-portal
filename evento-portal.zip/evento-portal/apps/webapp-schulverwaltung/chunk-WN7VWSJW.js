import{Ac as t,Bc as n,Gc as o,Ic as r}from"./chunk-T7QWSMKM.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
