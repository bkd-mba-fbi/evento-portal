function r(e,t){return n(e).includes(t)}function n(e){return e?e.split(";"):[]}export{r as a,n as b};
