import{Dd as e,Gd as o,xd as t,yd as n,zd as r}from"./chunk-GUP4UHKK.js";var s=e({Key:o([n,t]),Value:t}),m=e({Key:o([n,t]),Value:t,IsActive:r});export{s as a,m as b};
