import{Qc as t,Rc as n,Wc as o,Yc as r}from"./chunk-RXW5CQPZ.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
