define([
    'api'
], function (api) {
    return api.ember.getGradingConfiguration();
});
